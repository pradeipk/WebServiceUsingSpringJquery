package com.psl.sprint.configuration;

import java.util.List;
import java.util.TimerTask;
import org.joda.time.LocalDate;
import com.psl.sprint.model.SprintMaster;
import com.psl.sprint.service.SprintMasterService;

public class ScheduledTask extends TimerTask {
	SprintConfiguration sprintConfiguration;
	SprintMasterService sprintMasterService;

	public ScheduledTask() {

	}

	public ScheduledTask(SprintConfiguration sprintConfiguration,
			SprintMasterService sprintMasterService) {
		this.sprintConfiguration = sprintConfiguration;
		this.sprintMasterService = sprintMasterService;
	}

	public void run() {
		if (sprintConfiguration.getIsSprintShedularOn() != null
				&& sprintConfiguration.getIsSprintShedularOn()
						.equalsIgnoreCase("Y")) {
		try {
			LocalDate today = new LocalDate();
			List<SprintMaster> sprintMasters = sprintMasterService
					.getNonFrozenSprints(new LocalDate());
			if (sprintMasters != null && sprintMasters.size() > 0)
				for (SprintMaster sprintMaster : sprintMasters) {
					LocalDate tempDate = sprintMaster.getStartDate().plusDays(
							sprintConfiguration.getFreezDay());
					if (today.isAfter(tempDate)) {
						sprintMaster.setFreezed(1);
						sprintMasterService.updateEntity(sprintMaster);
					}
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
						
	}
	}
}