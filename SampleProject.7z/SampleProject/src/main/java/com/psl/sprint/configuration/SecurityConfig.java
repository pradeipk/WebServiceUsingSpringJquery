package com.psl.sprint.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.JdbcUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private DataSource dataSource;

	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder auth)	throws Exception {

		JdbcUserDetailsManagerConfigurer<AuthenticationManagerBuilder> authoritiesByUsernameQuery = auth
				.jdbcAuthentication()
				.dataSource(dataSource)
				.usersByUsernameQuery(
						"select USER_NAME, PASSWORD, ENABLED from tbl_resource where USER_NAME=?")
				.authoritiesByUsernameQuery(
						"select USER_NAME, ACCESS_LEVEL from tbl_access_level where USER_NAME=?");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
				.antMatchers("/", "/home")
				.permitAll()
				.antMatchers("/**/connector/list")
				.permitAll()
				.antMatchers("/**/connector/view-plans/*")
				.permitAll()
				.antMatchers("/**/connector/list/true")
				.access("hasRole('ROLE_ADMIN')")
				.antMatchers("/**/user/task")
				.access("hasRole('ROLE_DEV') or hasRole('ROLE_ADMIN') or hasRole('ROLE_LEAD') or hasRole('ROLE_MODULE')")
				.antMatchers("/**/user/task/Resources")
				.access("hasRole('ROLE_ADMIN') or hasRole('ROLE_LEAD') or hasRole('ROLE_MODULE')")
				.antMatchers("/**/estimates/main")
				.access("hasRole('ROLE_MODULE') or hasRole('ROLE_ADMIN') or hasRole('ROLE_LEAD')")
				.antMatchers("/**/sprint/main")
				.access("hasRole('ROLE_MODULE') or hasRole('ROLE_ADMIN') or hasRole('ROLE_LEAD')")
				.antMatchers("/**/sprintNew/main")
				.access("hasRole('ROLE_MODULE') or hasRole('ROLE_ADMIN') or hasRole('ROLE_LEAD')")
				.antMatchers("/**/connector/update_estimates/*")
				.access("hasRole('ROLE_ADMIN')")
				.antMatchers("/**/connector/**")
				.access("hasRole('ROLE_ADMIN') or hasRole('ROLE_LEAD')")
				.antMatchers("/**/user/admin/**")
				.access("hasRole('ROLE_ADMIN') or hasRole('ROLE_LEAD')")
				// .antMatchers("/",
				// "/home").access("hasRole('USER') or hasRole('ADMIN') or hasRole('DBA')")
				.and().formLogin().loginPage("/").failureUrl("/")
				.usernameParameter("ssoId").passwordParameter("password").and()
				.exceptionHandling().accessDeniedPage("/403");
		// .and().csrf();
	}
}