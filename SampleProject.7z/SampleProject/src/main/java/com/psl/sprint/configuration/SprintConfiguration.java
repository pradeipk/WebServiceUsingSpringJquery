package com.psl.sprint.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
@ComponentScan(basePackages = "com.psl.*")
@PropertySource(value = { "classpath:SprintConfiguration.properties" })
public class SprintConfiguration {

	@Value("${sprint.start.day}")
	private String startDay;

	@Value("${sprint.end.day}")
	private String endDay;

	@Value("${sprint.base.line}")
	private String baseLine;

	@Value("${sprint.default.freez.day}")
	private String freezDay;

	@Value("${sprint.sheduled.Time}")
	private String sheduledTime;

	@Value("${sprint.default.leave.day}")
	private String deafultLeaveDay;

	@Value("${sprint.display.count}")
	private String sprintDisplayCount;

	@Value("${sprint.summary.display.count}")
	private String sprintSuymmaryDisplayCount;

	@Value("${sprint.shedular.on}")
	private String isSprintShedularOn;

	public void setStartDay(String startDay) {
		this.startDay = startDay;
	}

	public void setEndDay(String endDay) {
		this.endDay = endDay;
	}

	public void setBaseLine(String baseLine) {
		this.baseLine = baseLine;
	}

	public void setFreezDay(String freezDay) {
		this.freezDay = freezDay;
	}

	public int getStartDay() {
		return Integer.parseInt(startDay);
	}

	public int getEndDay() {
		return Integer.parseInt(endDay);
	}

	public int getBaseLine() {
		return Integer.parseInt(baseLine);
	}

	public int getFreezDay() {
		return Integer.parseInt(freezDay);
	}

	public Long getSheduledTime() {
		return new Long(sheduledTime);
	}

	public int getDeafultLeaveDay() {
		return Integer.parseInt(deafultLeaveDay);
	}

	public int getSprintDisplayCount() {
		return Integer.parseInt(sprintDisplayCount);
	}

	public int getSprintSuymmaryDisplayCount() {
		return Integer.parseInt(sprintSuymmaryDisplayCount);
	}

	public String getIsSprintShedularOn() {
		return isSprintShedularOn.trim();
	}

	public void setIsSprintShedularOn(String isSprintShedularOn) {
		this.isSprintShedularOn = isSprintShedularOn;
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
