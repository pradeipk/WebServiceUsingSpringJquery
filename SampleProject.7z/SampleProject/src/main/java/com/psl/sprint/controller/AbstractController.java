package com.psl.sprint.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.psl.sprint.exception.MandatoryFieldMissingException;
import com.psl.sprint.util.SprintConstants;

@Controller
@RequestMapping
public class AbstractController extends SprintConstants {

	@ExceptionHandler(value = MandatoryFieldMissingException.class)
	public String handleCustomException(MandatoryFieldMissingException ex) {
		return "home";

	}

	@ExceptionHandler(value = Exception.class)
	public String handleAllException(Exception ex, ModelMap map) {
		map.addAttribute("error",
				"Oops something went wrong,please try after some time.");
		return "oops";
	}

}
