package com.psl.sprint.controller;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.psl.sprint.model.Resource;
import com.psl.sprint.service.UserService;

@Controller
@RequestMapping("/")
public class AppController {

	@Autowired
	MessageSource messageSource;

	@Autowired
	UserService userService;

	/*
	 * @RequestMapping(value = "/admin", method = RequestMethod.GET) public
	 * String adminPage(ModelMap model) {
	 * 
	 * model.addAttribute("title",
	 * "Spring Security Login Form - Database Authentication");
	 * model.addAttribute("message", "This page is for ROLE_ADMIN only!");
	 * model.addAttribute("admin"); return "home";
	 * 
	 * }
	 */

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage() {
		Authentication auth1 = SecurityContextHolder.getContext()
				.getAuthentication();
		return "login";
	}

	/*
	 * 
	 * 
	 */
	@RequestMapping(value = { "/", "/admin" }, method = RequestMethod.GET)
	public String homePage(ModelMap model, HttpServletRequest request) {
		Collection<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
		String remoteAddress = request.getHeader("X-FORWARDED-FOR");
		if (remoteAddress == null) {
			remoteAddress = request.getRemoteAddr();
		}
		String redirect = null;
		try {
			InetAddress inetAddress = InetAddress.getByName(remoteAddress);
			String computerName = inetAddress.getHostName();		
			Resource resource = userService.findByIP(computerName);
			if (resource != null) {
				String role = null;
				if (resource.getJobAssigned().equals("Testing")
						|| resource.getJobAssigned().equals("Development")) {
					role = "ROLE_DEV";
					redirect = "redirect:/user/task";
				} else if (resource.getJobAssigned().equals("Module_Development")) {
					role = "ROLE_MODULE";
					redirect = "redirect:/user/task";
				} else if (resource.getJobAssigned().equals("Lead_DEV") || resource.getJobAssigned().equals("Dual_DEV") || resource.getJobAssigned().equals("Lead_QA") || resource.getJobAssigned().equals("Dual_QA")) {
					role = "ROLE_LEAD";
					redirect = "redirect:/connector/listMaster/" + false;
				} else {
					role = "ROLE_ADMIN";
					redirect = "redirect:/connector/listMaster/" + false;
				}
				request.getSession().setAttribute("user", resource);
				request.getSession().setAttribute("hostname", computerName);
				grantedAuthorities.add(new SimpleGrantedAuthority(role));
				Authentication auth = new UsernamePasswordAuthenticationToken(
						computerName, null, grantedAuthorities);
				SecurityContextHolder.getContext().setAuthentication(auth);
			} else {
				model.addAttribute("username", computerName);
				return "403";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "oops";
		}
		return redirect;
	}

	private String getPrincipal() {
		String userName = null;
		Object principal = SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			userName = ((UserDetails) principal).getUsername();
		} else {
			userName = principal.toString();
		}
		return userName;
	}

	@RequestMapping(value = "/Access_Denied", method = RequestMethod.GET)
	public String accessDeniedPage(ModelMap model) {
		model.addAttribute("user", getPrincipal());
		return "accessDenied";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request,
			HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		if (auth != null) {
			new SecurityContextLogoutHandler().logout(request, response, auth);
		}
		return "logout";
	}

	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public String accesssDenied(ModelMap map) {
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		map.addAttribute("username", auth.getPrincipal());
		return "403";

	}

	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public String errorMessages(ModelMap map,
			@ModelAttribute("error") final String error) {
		map.put("error", error);
		return "home";
	}

}
