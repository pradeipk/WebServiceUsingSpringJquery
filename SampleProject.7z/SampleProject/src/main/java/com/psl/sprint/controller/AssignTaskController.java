package com.psl.sprint.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.psl.sprint.model.AssignTask;
import com.psl.sprint.model.AssignTaskDto;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.FunctionalRequrement;
import com.psl.sprint.model.Subtask;
import com.psl.sprint.service.AssignTaskService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.FRService;
import com.psl.sprint.service.SubTaskService;
import com.psl.sprint.util.GeneralUtility;

@Controller
@RequestMapping("/assign-task")
public class AssignTaskController {

	@Autowired
	AssignTaskService assignservice;
	@Autowired
	ConnectorService connectorService;
	@Autowired
	FRService frService;
	@Autowired
	SubTaskService taskservice;

	@Autowired
	MessageSource messageSource;

	List<Subtask> tasks = null;
	private static List<FunctionalRequrement> frequirements = null;
	private static List<Connector> allconnectors = null;
	private Map<String, Integer> reqMap = null;
	private Map<String, Integer> connMap = null;
	private Map<String, Integer> taskMap = null;

	@RequestMapping(value = { "/new" }, method = RequestMethod.POST)
	public String saveStoryPoint(AssignTaskDto dto,
			ModelMap model) throws Exception {

		AssignTask assignTask = new AssignTask();
		assignTask.setConnector_id(connMap.get(dto.getConnector()));
		assignTask.setRequirement_id(reqMap.get(dto.getRequirement()));
		assignTask.setSubtask_id(taskMap.get(dto.getSubtask()));

		/*if (result.hasErrors()) {
			return "connectorentry";
		}*/

		assignservice.saveAssignTask(assignTask);

		model.addAttribute("success", "Task Assigned for " + dto.getSubtask()
				+ " registered successfully");
		return "success";
	}

	@RequestMapping(value = { "/new" }, method = RequestMethod.GET)
	public String getStoryPoint(ModelMap model) throws Exception {

		// AssignTask assignTask = new AssignTask();
		AssignTaskDto dto = new AssignTaskDto();
		model.addAttribute("assignTask", dto);

		frequirements = frService.findAllFirstRequrement();
		allconnectors = connectorService.findAllConnector(null);
		reqMap = new HashMap<String, Integer>();
		connMap = new HashMap<String, Integer>();
		taskMap = new HashMap<String, Integer>();
		List<String> requirements = GeneralUtility.listAllRequirements(
				frequirements, reqMap);
		List<String> connectors = GeneralUtility.listAllConnectors(
				allconnectors, connMap);
		List<String> tasks = GeneralUtility.listAllTask(
				taskservice.findAllSubtask(), taskMap);
		model.addAttribute("connect", connectors);
		model.addAttribute("requirements", requirements);
		model.addAttribute("task", tasks);
		model.addAttribute("edit", false);
		return "assign_sub_task";
	}

	@RequestMapping(value = { "/list" }, method = RequestMethod.GET)
	public String getStoryPointList(ModelMap model) throws Exception {

		model.addAttribute("assigntasks", assignservice.findAllAssignTask());
		model.addAttribute("edit", false);
		return "show-story-point";
	}

}
