package com.psl.sprint.controller;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Blob;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.rowset.serial.SerialBlob;
import javax.validation.Valid;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRelation;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.node.ArrayNode;
import org.codehaus.jackson.node.ObjectNode;
import org.joda.time.LocalDate;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTColor;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHyperlink;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTRPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTText;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STUnderline;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.psl.sprint.dto.ResourceDTO;
import com.psl.sprint.dto.ResourceWrapper;
import com.psl.sprint.exception.RecordAllReadyExistsException;
import com.psl.sprint.model.AllocationDTO;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorBug;
import com.psl.sprint.model.ConnectorIssueList;
import com.psl.sprint.model.ConnectorLeadMapping;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.model.ConnectorPlannedCompletion;
import com.psl.sprint.model.EstimatedPlan;
import com.psl.sprint.model.EstimatesPDF;
import com.psl.sprint.model.IssueTrackerJiraMapping;
import com.psl.sprint.model.MasterTable;
import com.psl.sprint.model.Notes;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.model.Review;
import com.psl.sprint.model.ReviewPhase;
import com.psl.sprint.model.ReviewUI;
import com.psl.sprint.model.Task;
import com.psl.sprint.model.TaskEffortsByConnectorAndPhase;
import com.psl.sprint.model.TemporaryResults;
import com.psl.sprint.service.ConnectorBugService;
import com.psl.sprint.service.ConnectorIssueService;
import com.psl.sprint.service.ConnectorLeadMappingService;
import com.psl.sprint.service.ConnectorMasterService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.IssueTrackerJiraMappingService;
import com.psl.sprint.service.MasterService;
import com.psl.sprint.service.NotesService;
import com.psl.sprint.service.ResourceAllocationReportService;
import com.psl.sprint.service.TaskService;
import com.psl.sprint.service.UserService;
import com.psl.sprint.util.SprintConstants;

@Controller
@RequestMapping("/connector")
public class ConnectorController extends AbstractController {

	@Autowired
	private ConnectorService service;

	@Autowired
	private ConnectorMasterService connMasterService;

	@Autowired
	private ResourceAllocationReportService allocationReportService;

	@Autowired
	private UserService userService;

	@Autowired
	MessageSource messageSource;

	@Autowired
	private MasterService masterService;

	@Autowired
	private ResourceAllocationReportService reportService;

	@Autowired
	private TaskService taskService;

	@Autowired
	private ConnectorBugService connectorBugService;

	@Autowired
	private NotesService notesService;

	@Autowired
	private ConnectorMasterService connectorMasterService;

	@Autowired
	private ConnectorIssueService connectorIssueService;

	@Autowired
	private IssueTrackerJiraMappingService issueTrackerJiraMappingService;

	@Autowired
	private ConnectorLeadMappingService connectorLeadMappingService;

	@Autowired
	private ConnectorService connectorService;

	@RequestMapping(value = { "/admin/new" }, method = RequestMethod.POST)
	public String saveConnector(
			@ModelAttribute("connector") Connector connector, ModelMap model,
			HttpServletRequest request) throws Exception {
		try {
			boolean hasError = false;
			List<String> connectorType = new ArrayList<String>();
			if (request.getParameter("action") != null) {
				connectorType.add("Action");
			}
			if (request.getParameter("trigger") != null) {
				connectorType.add("Trigger");
			}
			if (request.getParameter("webhooks") != null) {
				connectorType.add("Webhooks");
			}
			// return "redirect:/connector/admin/new";
			if (connector.getName() == null || connector.getName().isEmpty()) {
				model.addAttribute("name_error", "Connector name required");
				hasError = true;
			} else {
				if (!service.findByConnectorName(connector.getName()).isEmpty()) {
					model.addAttribute("name_error", "Connector with name \""
							+ connector.getName() + "\" already exists");
					hasError = true;
				}
			}
			if (connector.getOwner() == null
					|| connector.getOwner().equals("NONE")) {
				model.addAttribute("owner_error", "Lead / Owner required");
				hasError = true;
			}
			if (connector.getPslSME() == null
					|| connector.getPslSME().equals("NONE")) {
				model.addAttribute("pslSME_error", "PSL SME required");
				hasError = true;
			}
			if (connector.getIbmSME() == null
					|| connector.getIbmSME().isEmpty()) {
				model.addAttribute("ibmSME_error", "IBM SME required");
				hasError = true;
			}
			if (hasError) {
				model.addAttribute("connector", connector);
				model.addAttribute("edit", false);
				model.addAttribute("sme", sme);
				model.addAttribute("lead", lead);
				return "create_connector";
			} else {
				ConnectorMaster connectorMaster = new ConnectorMaster();
				connectorMaster.setConnectorStatus(1);
				connectorMaster.setConnectorName(connector.getName());
				connectorMasterService.saveEntity(connectorMaster);
				if (connectorMaster.getId() != null) {
					connector.setConnectorParentId(connectorMaster.getId());
					for (String eachConnectorType : connectorType) {
						Connector tempConnector = new Connector();
						tempConnector.setIbmSME(connector.getIbmSME());
						tempConnector.setOwner(connector.getOwner());
						tempConnector.setPslSME(connector.getPslSME());
						tempConnector.setStartDate(connector.getStartDate());
						tempConnector.setConnectorParentId(connector
								.getConnectorParentId());
						Integer connType = 0;
						connector.setInitialPds(INITALS_PDS
								.get(eachConnectorType));
						if (eachConnectorType.equals("Action")) {
							connType = 1;
						} else if (eachConnectorType.equals("Trigger")) {
							connType = 2;
						} else {
							connType = 3;
						}
						connector.setIsExempted(new Byte((byte) 1));
						tempConnector.setName(connector.getName().trim() + " "
								+ eachConnectorType);
						tempConnector.setConnectorType(connType);
						tempConnector.setStatus("Open");
						service.saveConnector(tempConnector);
					}
				}
				return "redirect:/connector/listMaster/false";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "redirect:/connector/admin/new";
		}

	}

	@RequestMapping(value = { "/admin/edit/{connector1}" }, method = RequestMethod.POST)
	public String updateConnector(
			@ModelAttribute("connector") Connector connector, ModelMap model,
			@PathVariable Integer connector1, HttpServletRequest request)
			throws Exception {
		boolean hasError = false;
		if (connector.getOwner().equals("NONE")) {
			model.addAttribute("owner_error", "Lead / Owner required");
			hasError = true;
		}
		if (connector.getPslSME().equals("NONE")) {
			model.addAttribute("pslSME_error", "PSL SME required");
			hasError = true;
		}
		if (connector.getIbmSME().isEmpty()) {
			model.addAttribute("ibmSME_error", "IBM SME required");
			hasError = true;
		}
		if (!connector.getJiraId().equals("NONE")) {

			if (request.getParameter("tcsExecuted") != null
					&& request.getParameter("tcsExecuted").isEmpty()) {
				model.addAttribute("tcsExecuted_error",
						"No. of Test Cases Execution required");
				hasError = true;
			} else {
				model.addAttribute("tcsExecuted",
						request.getParameter("tcsExecuted"));
				try {
					Integer.parseInt(request.getParameter("tcsExecuted"));
				} catch (Exception e) {
					model.addAttribute("tcsExecuted_error",
							"No. of Test Cases Execution should be numeric");
				}
			}

			if (request.getParameter("tcsCreated") != null
					&& request.getParameter("tcsCreated").isEmpty()) {
				model.addAttribute("tcsCreated_error",
						"No. of Test Cases Created required");
				hasError = true;
			} else {
				model.addAttribute("tcsCreated",
						request.getParameter("tcsCreated"));
				try {
					Integer.parseInt(request.getParameter("tcsCreated"));
				} catch (Exception e) {
					model.addAttribute("tcsCreated_error",
							"No. of Test Cases Created should be numeric");
				}
			}

			if (request.getParameter("defectLeakage") != null
					&& request.getParameter("defectLeakage").isEmpty()) {
				model.addAttribute("defectLeakage_error",
						"Defect Leakage required");
				hasError = true;
			} else {
				model.addAttribute("defectLeakage",
						request.getParameter("defectLeakage"));
				try {
					Integer.parseInt(request.getParameter("defectLeakage"));
				} catch (Exception e) {
					model.addAttribute("defectLeakage_error",
							"Defect Leakage should be numeric");
				}
			}

			if (request.getParameter("velocity") != null
					&& request.getParameter("velocity").isEmpty()) {
				model.addAttribute("velocity_error", "Velocity required");
				hasError = true;
			} else {
				model.addAttribute("velocity", request.getParameter("velocity"));
				try {
					Integer.parseInt(request.getParameter("velocity"));
				} catch (Exception e) {
					model.addAttribute("velocity_error",
							"Velocity should be numeric");
				}
			}

			if (request.getParameter("synch") != null
					&& request.getParameter("synch").isEmpty()) {
				model.addAttribute("synch_error", "Please synchronize");
				hasError = true;
			}
			model.addAttribute("jiraid", connector.getJiraId());
		}
		if (!hasError) {
			Connector existing_connector = service.findById(connector1);
			existing_connector.setOwner(connector.getOwner());
			existing_connector.setPslSME(connector.getPslSME());
			existing_connector.setIbmSME(connector.getIbmSME());
			existing_connector.setStatus(connector.getStatus());
			if (request.getParameter("synch") != null
					&& request.getParameter("synch").equals("1")) {
				existing_connector.setJiraId(connector.getJiraId());
				ConnectorBug bug = new ConnectorBug();
				bug.setConnectorId(connector.getId());
				bug.setFixed(Integer.parseInt(request.getParameter("fixed")));
				bug.setDuplicate(Integer.parseInt(request
						.getParameter("duplicate")));
				bug.setNotABug(Integer.parseInt(request.getParameter("notABug")));
				bug.setInvalid(Integer.parseInt(request.getParameter("invalid")));
				bug.setTcsExecuted(Integer.parseInt(request
						.getParameter("tcsExecuted")));
				bug.setTcsCreated(Integer.parseInt(request
						.getParameter("tcsCreated")));
				bug.setTcsCreated(Integer.parseInt(request
						.getParameter("tcsCreated")));

				bug.setTcsCreated(Integer.parseInt(request
						.getParameter("tcsCreated")));

				connectorBugService.delete(connector.getId());
				connectorBugService.saveEntity(bug);
			} else {
				existing_connector.setJiraId(null);
			}
			service.updateConnector(existing_connector, null);
			return "redirect:/connector/listMaster/false";
		} else {
			model.addAttribute("connector", connector);
			model.addAttribute("sme", sme);
			model.addAttribute("lead", lead);
			model.addAttribute("visibilty", visibilty);
			model.addAttribute("edit", true);
			return "create_connector";
		}
	}

	@RequestMapping(value = { "/admin/edit/{connectorId}" }, method = RequestMethod.GET)
	public String editConnector(@PathVariable Integer connectorId,
			ModelMap model) throws Exception {
		Connector connector = service.findById(connectorId);
		model.addAttribute("connector", connector);
		model.addAttribute("connectorBug",
				connectorBugService.findByConnector(connectorId));
		model.addAttribute("sme", sme);
		model.addAttribute("lead", lead);
		model.addAttribute("visibilty", visibilty);
		model.addAttribute("edit", true);
		model.addAttribute("jiraid", "0");
		return "create_connector";
	}

	@RequestMapping(value = { "/admin/new" }, method = RequestMethod.GET)
	public String getConnector(ModelMap model,
			@ModelAttribute("error") final String error) {
		Connector connector = new Connector();
		connector.setStartDate(new LocalDate());
		model.addAttribute("connector", connector);
		model.addAttribute("edit", false);
		model.addAttribute("sme", sme);
		model.addAttribute("lead", lead);
		return "create_connector";
	}

	@RequestMapping(value = { "/assignLead" }, method = RequestMethod.GET)
	public String assignLead(ModelMap model,
			@ModelAttribute("error") final String error) throws Exception {
		ResourceWrapper resourceWrapper = new ResourceWrapper();
		List<Connector> list = service.findAllConnectors();
		List<Resource> listOFLeads = userService.findAllLeadsAndDuals();
		List<Resource> listOfQAAndLeads = new ArrayList<>();
		List<Resource> listOfDevAndLeads = new ArrayList<>();
		for (Resource r : listOFLeads) {
			if (r.getJobAssigned().equals("Lead_DEV")
					|| r.getJobAssigned().equals("Dual_DEV")) {
				listOfDevAndLeads.add(r);
			}
			if (r.getJobAssigned().equals("Lead_QA")
					|| r.getJobAssigned().equals("Dual_QA")) {
				listOfQAAndLeads.add(r);
			}
		}
		resourceWrapper.setResource(listOfDevAndLeads);
		resourceWrapper.setListOfQAAndLeads(listOfQAAndLeads);
		resourceWrapper.setListOfConnectors(list);
		model.addAttribute("connectors", resourceWrapper.getListOfConnectors());
		model.addAttribute("leadsAndDev", resourceWrapper.getResource());
		model.addAttribute("leadsAndQA", resourceWrapper.getListOfQAAndLeads());
		model.addAttribute("resourceWrapper", resourceWrapper);
		return "assign_lead";
	}

	@RequestMapping(value = { "/assignLead" }, method = RequestMethod.POST)
	public String saveUser(@Valid ResourceWrapper resourceWrapper,
			BindingResult result, ModelMap model) throws Exception {

		try {
			if (resourceWrapper.getConnectorId() == null) {
				model.addAttribute("connectorError", "Connector required");
			}
			if (resourceWrapper.getResourceId() == null
					|| resourceWrapper.getQAresourceId() == null) {
				model.addAttribute("leadError", "Lead required");
			}

			if (resourceWrapper.getConnectorId() == null
					|| resourceWrapper.getResourceId() == null
					|| resourceWrapper.getQAresourceId() == null) {
				model.addAttribute("connectors",
						resourceWrapper.getListOfConnectors());
				model.addAttribute("leadsAndDev", resourceWrapper.getResource());
				model.addAttribute("leadsAndQA",
						resourceWrapper.getListOfQAAndLeads());
				model.addAttribute("resourceWrapper", resourceWrapper);

				return "assign_lead";
			} else {
				List<ConnectorLeadMapping> mappingList = connectorLeadMappingService
						.findMapping();
				boolean flag = true;
				if (!mappingList.isEmpty()) {
					for (ConnectorLeadMapping c : mappingList) {
						if ((c.getConnector().getId() == resourceWrapper
								.getConnectorId())
								&& (c.getDevResource().getResourceId() == resourceWrapper
										.getResourceId())
								&& (c.getQaResource().getResourceId() == resourceWrapper
										.getQAresourceId())) {
							flag = false;
							break;
						}
					}
				}
				if (flag) {
					ConnectorLeadMapping connectorLeadMapping = new ConnectorLeadMapping();
					connectorLeadMapping.setDevResource(userService
							.findResourceByID(resourceWrapper.getResourceId()));
					connectorLeadMapping
							.setQaResource(userService
									.findResourceByID(resourceWrapper
											.getQAresourceId()));
					connectorLeadMapping.setConnector(service
							.findById(resourceWrapper.getConnectorId()));
					connectorLeadMapping.setAdmin("Others");
					connectorLeadMappingService
							.saveEntity(connectorLeadMapping);
					model.addAttribute("submitted",
							"Data submitted successfully");
					return "assign_lead";
				} else {
					model.addAttribute("duplicate_values",
							"Duplicate Values not allowed");
					return "assign_lead";
				}

			}

		} catch (RecordAllReadyExistsException e) {
			model.addAttribute("error", e.getMessage());
			return "redirect:/connector/assignLead";
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "redirect:/error";
		}
	}

	/*
	 * @RequestMapping(value = { "/list" }, method = RequestMethod.GET) public
	 * String getConnectorList(ModelMap model) throws Exception {
	 * 
	 * List<Connector> connectors = service.findAllConnector();
	 * model.addAttribute("connectors", connectors); model.addAttribute("edit",
	 * false); return "view_connector"; }
	 */

	@RequestMapping(value = { "/list/{connectorID}" }, method = RequestMethod.GET)
	public String getConnectorList(@PathVariable Integer connectorID,
			ModelMap model) throws Exception {
		List<Connector> connectors = service
				.findAllByConnectorParentId(connectorID.intValue());
		Map<Integer, Double> pds_dev = new HashMap<Integer, Double>();
		Map<Integer, Double> pds_qa = new HashMap<Integer, Double>();
		Map<Integer, String> internalpdf = new HashMap<Integer, String>();
		Map<Integer, String> externalpdf = new HashMap<Integer, String>();
		Map<Integer, Double> actualefforts_dev = new HashMap<Integer, Double>();
		Map<Integer, Double> actualefforts_qa = new HashMap<Integer, Double>();
		Map<Integer, Notes> allNotes = new HashMap<Integer, Notes>();
		List<Task> efforts_dev = taskService
				.getEffortsForAllConnectors("Development");
		for (Task task : efforts_dev) {
			actualefforts_dev.put(
					task.getConnectorId(),
					new BigDecimal(task.getHoursSpent() / 8).setScale(2,
							BigDecimal.ROUND_HALF_UP).doubleValue());
		}

		List<Task> efforts_qa = taskService
				.getEffortsForAllConnectors("Testing");
		for (Task task : efforts_qa) {
			actualefforts_qa.put(
					task.getConnectorId(),
					new BigDecimal(task.getHoursSpent() / 8).setScale(2,
							BigDecimal.ROUND_HALF_UP).doubleValue());
		}

		for (Connector connector : connectors) {
			double totalPDS_DEV = 0;
			double totalPDS_QA = 0;
			List<ResourceDTO> resourceDtos = service
					.findAllResourcesWithDateFlag(connector.getName());
			if (!resourceDtos.isEmpty()) {
				for (ResourceDTO resourceDto : resourceDtos) {
					if (resourceDto.getJobAssigned().equals("Development")
							|| resourceDto.getJobAssigned().equals("Dual_DEV")) {
						totalPDS_DEV += resourceDto.getPDs();
					} else if (resourceDto.getJobAssigned().equals("Testing")
							|| resourceDto.getJobAssigned().equals("Dual_QA")) {
						totalPDS_QA += resourceDto.getPDs();
					}
				}
				pds_dev.put(connector.getId(), new BigDecimal(totalPDS_DEV)
						.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
				pds_qa.put(connector.getId(), new BigDecimal(totalPDS_QA)
						.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
			}
		}
		List<EstimatesPDF> pdfs = service.findAll();
		for (Connector connector : connectors) {
			for (EstimatesPDF pdfFile : pdfs) {
				if (pdfFile.getConnectorId() == connector.getId()) {
					internalpdf.put(connector.getId(), pdfFile.getFileName());
					if (pdfFile.getFileNameExternal() != null) {
						externalpdf.put(connector.getId(),
								pdfFile.getFileNameExternal());
					}
					break;
				}
			}
		}
		@SuppressWarnings("unchecked")
		List<Notes> notes = (List<Notes>) notesService.findAll();
		for (Notes note : notes) {
			if (note != null) {
				allNotes.put(note.getConnectorId(), note);
			}
		}

		model.addAttribute("pds_dev", pds_dev);
		model.addAttribute("pds_qa", pds_qa);
		model.addAttribute("internalpdf", internalpdf);
		model.addAttribute("externalpdf", externalpdf);
		model.addAttribute("connectors", connectors);
		model.addAttribute("notes", allNotes);
		// model.addAttribute("edit", false);
		model.addAttribute("efforts_dev", actualefforts_dev);
		model.addAttribute("efforts_qa", actualefforts_qa);
		return "view_connector";
	}

	@RequestMapping(value = { "/effort_estimation" }, method = RequestMethod.GET)
	public String getEffortEstimation(ModelMap model) throws Exception {
		return "effort_estimation";
	}

	@RequestMapping(value = { "/phase/{connectorId}/{job}" }, method = RequestMethod.GET)
	public String getEffortsByConnector(@PathVariable Integer connectorId,
			@PathVariable String job, ModelMap model) throws Exception {
		List<Task> effortsByPhaseForConnector = taskService
				.getEffortsByConnector(connectorId, job);
		for (Task task : effortsByPhaseForConnector) {
			task.setHoursSpent(new BigDecimal(task.getHoursSpent() / 8)
					.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
		}
		model.addAttribute("effortsPhaseWise", effortsByPhaseForConnector);
		model.addAttribute("connectorId", connectorId);
		return "efforts_by_phase";
	}

	@ResponseBody
	@RequestMapping(value = { "/phase/{connectorId}/{phase}" }, method = RequestMethod.GET, produces = "application/json")
	public String getEffortsByConnectorAndPhase(
			@PathVariable Integer connectorId, @PathVariable String phase)
			throws Exception {
		List<TaskEffortsByConnectorAndPhase> effortsByConnectorAndPhase = taskService
				.getEffortsByConnectorAndPhase(connectorId, phase);
		StringBuffer buffer = new StringBuffer();
		buffer.append("{\"data\": [");
		for (TaskEffortsByConnectorAndPhase taskResourceConnector : effortsByConnectorAndPhase) {
			buffer.append("[");
			buffer.append("\"" + taskResourceConnector.getFirstName() + " "
					+ taskResourceConnector.getLastName() + "\",");
			buffer.append("\"" + taskResourceConnector.getTaskDate() + "\",");
			String description = taskResourceConnector.getDescription();
			if (description == null) {
				description = "";
			}
			description = description.replaceAll("\r\n", " ");
			description = description.replaceAll("\t", " ");
			buffer.append("\"" + description + "\",");
			buffer.append("\"" + taskResourceConnector.getHoursSpent() + "\"");
			buffer.append("],");
		}
		if (!effortsByConnectorAndPhase.isEmpty()) {
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]}");
		return buffer.toString();
	}

	@RequestMapping(value = { "/actual_effort_estimation" }, method = RequestMethod.GET)
	public String getActualEffortEstimation(ModelMap model) throws Exception {
		return "actual_effort_estimation";
	}

	@RequestMapping(value = { "/{connectorId}" }, method = RequestMethod.GET)
	public String closeConnector(@PathVariable Integer connectorId,
			ModelMap model) throws Exception {
		Connector connector = service.findById(connectorId);
		if (connector.getStatus().equals(OPEN)) {
			connector.setStatus(CLOSE);
			service.updateConnector(connector, null);
		} else if (connector.getStatus().equals(CLOSE)) {
			connector.setStatus(OPEN);
			service.updateConnector(connector, null);
		}
		model.addAttribute("edit", false);
		return "redirect:/connector/listMaster/" + true;
	}

	@RequestMapping(value = { "/view-plans/{connector}" }, method = RequestMethod.GET)
	public String getConnectorPlan(@PathVariable String connector,
			ModelMap model) throws Exception {

		model.addAttribute("dtoList", service.findAllPlans(connector));
		model.addAttribute("connector", connector);
		return "view-plan";

	}

	// an example of redirecting with data from one controller to another
	/**
	 * 
	 * @param connector
	 * @param model
	 * @param availableResource
	 * @param sDate
	 * @param eDate
	 * @param attributes
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = { "/view-resources/{connector}" }, method = RequestMethod.GET)
	public String findResourcesForConnector(
			@PathVariable String connector,
			ModelMap model,
			@ModelAttribute("availableResources") final ResourceWrapper availableResource,
			@ModelAttribute("startDate") final String sDate,
			@ModelAttribute("endDate") final String eDate,
			RedirectAttributes attributes) throws Exception {
		try {
			ResourceWrapper final_available_resource = findAvailableResource(availableResource);
			Connector connector_0 = service.findByConnectorName(connector).get(
					0);
			model.addAttribute("new_resources",
					final_available_resource.getAllocationDTOs());
			attributes.addFlashAttribute("connector", connector);

			List<ResourceDTO> resourceDtos = service
					.findAllResourcesWithDateFlag(connector);

			model.addAttribute("resources", resourceDtos);
			model.addAttribute("sDate", sDate);
			model.addAttribute("eDate", eDate);
			model.addAttribute("connector_id", connector_0.getId());
			if (!resourceDtos.isEmpty()) {
				double totalPDS = 0;
				for (ResourceDTO resourceDto : resourceDtos) {
					totalPDS += resourceDto.getPDs();
				}
				model.addAttribute("totalPDs", new BigDecimal(totalPDS)
						.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
			}
			return "view_assigned_resources";
		} catch (Exception e) {
			attributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/error";
		}

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = { "/availability/{start_date}/{end_date}/{connectorName}" }, method = RequestMethod.GET)
	public String findResourceAvailiblity(@PathVariable String start_date,
			@PathVariable String end_date, @PathVariable String connectorName,
			ModelMap model, RedirectAttributes attributes) throws Exception {

		List<ResourceDTO> resourceDTOs = (List<ResourceDTO>) userService
				.findAll(false, null);
		ResourceWrapper availableResources = new ResourceWrapper();
		Connector connector = service.findByConnectorName(connectorName).get(0);
		List<AllocationDTO> consolidatedList = new ArrayList<AllocationDTO>();

		for (ResourceDTO resourceDTO : resourceDTOs) {
			Map<Integer, Object> allocations = allocationReportService
					.findAvailableResource(resourceDTO.getResourceId(),
							start_date, end_date);
			List<AllocationDTO> dtos = (List<AllocationDTO>) allocations
					.get(-resourceDTO.getResourceId());
			if (dtos != null && !dtos.isEmpty()) {
				consolidatedList.addAll(dtos);
			}
		}

		availableResources.setAllocationDTOs(consolidatedList);
		model.addAttribute("resources",
				service.findAllResourcesWithDateFlag(connectorName));
		model.addAttribute("connector_id", connector.getId());
		attributes.addFlashAttribute("availableResources", availableResources);
		attributes.addFlashAttribute("startDate", start_date);
		attributes.addFlashAttribute("endDate", end_date);
		model.addAttribute("availableResources", availableResources);
		return "redirect:/connector/view-resources/" + connectorName;
	}

	/**
	 * 
	 * @param allocationId
	 * @param userId
	 * @param startDate
	 * @param endDate
	 * @param isCheck
	 * @param model
	 * @param redAttributes
	 * @return
	 * @throws Exception
	 * 
	 *             This controller redirects to edit allocation page and
	 *             verifies the availibity of band width
	 */
	@RequestMapping(value = { "/editAllocation/{allocationId}/{userId}/{startDate}/{endDate}/{isCheck}" }, method = RequestMethod.GET)
	public String EditAllocation(@PathVariable Integer allocationId,
			@PathVariable Integer userId, @PathVariable String startDate,
			@PathVariable String endDate, @PathVariable String isCheck,
			ModelMap model, RedirectAttributes redAttributes) throws Exception {

		try {
			ResourceAllocationLog existing_log = reportService
					.findById(allocationId);
			ResourceAllocationLog allocationLog = allocationReportService
					.findById(allocationId);
			LocalDate filter_startDate = new LocalDate(startDate);
			List<AllocationDTO> allocations_with_date_filter = new ArrayList<AllocationDTO>();

			Map<Integer, Object> allocations = allocationReportService
					.findAvailableResource(userId, startDate, endDate);
			/*
			 * This bandwidth is max of allocations for a range of time
			 * specified for a resource
			 */
			Double maxAllocationForSpecifiedDateRange = (Double) allocations
					.get(userId);

			if (maxAllocationForSpecifiedDateRange == null) {
				redAttributes.addFlashAttribute("error",
						"Error:Undefined Allocations");
				return "redirect:/connector/view-resources/"
						+ allocationLog.getConnectorName();
			}
			Double availableAllocation = 1 - maxAllocationForSpecifiedDateRange;
			LocalDate d = new LocalDate();// intialize your date to any date

			MasterTable masterTable = masterService
					.findUniqueRecordByName(FREEZE_TIME);
			LocalDate dateBefore = new LocalDate(d.minusDays(Integer
					.parseInt(masterTable.getValue())));
			boolean edit_flag = true;
			if (filter_startDate.isBefore(dateBefore)) {
				edit_flag = false;
			}

			// On check of Availibilty from edit allocation page isCheck will be
			// true
			if (isCheck.equals("isCheck")) {
				allocationLog.setStartDate(new LocalDate(startDate));
				allocationLog.setEndDate(new LocalDate(endDate));
				Double minima = allocationReportService
						.findMinimaOfAllAllocationsForAResourceForAConnectorForADateRange(
								existing_log.getConnectorName(), userId,
								startDate, endDate);
				availableAllocation = availableAllocation + minima;
			} else {

				/*
				 * Its own bandwidth is available so add this ;
				 */
				availableAllocation = availableAllocation
						+ existing_log.getBandwidthShare();
			}
			allocationLog.getConnectorName();

			model.addAttribute("allocation_edit", allocationLog);
			model.addAttribute("avail_alloctions",
					allocation_for_edit.get(availableAllocation * 100));
			model.addAttribute("allocations", allocations_with_date_filter);
			model.addAttribute("allocationId", allocationId);
			model.addAttribute("userId", userId);
			model.addAttribute("allow_edit", edit_flag);
			model.addAttribute("connector", allocationLog.getConnectorName());
			model.addAttribute("connectorId", allocationLog.getConnectorId());
			model.addAttribute("phaseType", SprintConstants.PHASE_TYPE);
			model.addAttribute("resourceName",
					((ResourceDTO) userService.findById(userId)).getFirstName());
			model.addAttribute("startDate", startDate);
			return "edit_allocation";
		} catch (Exception e) {
			e.printStackTrace();
			redAttributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/error";
		}
	}

	@RequestMapping(value = { "/newAllocation/{resourceId}/{connectorId}/{avaliable_bandwith}/{startDate}/{endDate}" }, method = RequestMethod.GET)
	public String alignNewResourceForConnector(
			@PathVariable Integer resourceId,
			@PathVariable Integer connectorId, @PathVariable String startDate,
			@PathVariable String endDate,
			@PathVariable Double avaliable_bandwith, ModelMap model,
			RedirectAttributes redAttributes) throws Exception {
		try {

			Resource res = new Resource();
			res.setResourceId(resourceId);
			Map<Integer, Object> allocations = allocationReportService
					.findAvailableResource(resourceId, startDate, endDate);
			allocations.get(resourceId);
			ResourceAllocationLog new_allocation = new ResourceAllocationLog();
			new_allocation.setStartDate(new LocalDate(startDate));
			new_allocation.setEndDate(new LocalDate(endDate));
			new_allocation.setConnectorId(connectorId);
			new_allocation.setConnectorName(service.findById(connectorId)
					.getName());
			model.addAttribute("allocation_edit", new_allocation);
			model.addAttribute("avail_alloctions",
					(allocation.get(avaliable_bandwith)));
			model.addAttribute("resourceId", resourceId);
			model.addAttribute("resourceName", ((ResourceDTO) userService
					.findById(resourceId)).getFirstName());
			model.addAttribute("startDate", startDate);
			model.addAttribute("endDate", endDate);
			model.addAttribute("avaliable_bandwith", avaliable_bandwith);
			model.addAttribute("phaseType", SprintConstants.PHASE_TYPE);
			if (avaliable_bandwith.equals(0.0d)) {
				model.addAttribute("flag", false);
			}

			return "create_allocation";
		} catch (Exception e) {
			redAttributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/error";
		}
	}

	@SuppressWarnings("unchecked")
	private ResourceWrapper findAvailableResource(
			ResourceWrapper availableResource) throws Exception {

		if (availableResource.getAllocationDTOs() == null
				|| availableResource.getAllocationDTOs().isEmpty()) {
			MasterTable masterTable = masterService
					.findUniqueRecordByName(FREEZE_TIME);
			LocalDate s_d = new LocalDate().minusDays(Integer
					.parseInt(masterTable.getValue()));
			LocalDate e_d = new LocalDate(s_d.plusDays(30));
			List<ResourceDTO> resourceDTOs = (List<ResourceDTO>) userService
					.findAll(false, null);
			List<AllocationDTO> consolidatedList = new ArrayList<AllocationDTO>();
			for (ResourceDTO resourceDTO : resourceDTOs) {
				if (resourceDTO.getJobAssigned().equals("Lead")
						|| resourceDTO.getJobAssigned().equals("Others")) {
					continue;
				}
				Map<Integer, Object> allocations = allocationReportService
						.findAvailableResource(resourceDTO.getResourceId(),
								s_d.toString(), e_d.toString());

				List<AllocationDTO> dtos = (List<AllocationDTO>) allocations
						.get(-resourceDTO.getResourceId());

				if (dtos != null && !dtos.isEmpty()) {
					consolidatedList.addAll(dtos);
				}
			}
			availableResource = new ResourceWrapper();
			availableResource.setAllocationDTOs(consolidatedList);
			return availableResource;
		} else {
			return availableResource;
		}

	}

	@RequestMapping(value = { "/upload_estimates/save" }, method = RequestMethod.POST)
	public String saveConnectorEstimates(
			@ModelAttribute("estimatedPlan") EstimatedPlan estimatedPlan,
			ModelMap map, RedirectAttributes attributes) throws Exception {
		try {
			boolean hasError = false;
			if (estimatedPlan.getAction().equals("Upload")) {
				if (estimatedPlan.getEstimatedPdf().getOriginalFilename()
						.isEmpty()) {
					map.addAttribute("estimatedPdf_error", "PDF file required");
					hasError = true;
				}
				if (estimatedPlan.getEstimatedPDS() == 0) {
					map.addAttribute("estimatedPDS_error",
							"Estimated PD's required");
					hasError = true;
				}
				if (estimatedPlan.getStoryPoints() == 0) {
					map.addAttribute("storyPoints_error",
							"Story points required");
					hasError = true;
				}
			} else if (estimatedPlan.getAction().equals("Update")) {
				if (estimatedPlan.getEstimatedPdfExternal()
						.getOriginalFilename().isEmpty()) {
					map.addAttribute("estimatedPdfExternal_error",
							"Estimated PDF file for external is required");
					hasError = true;
				}
				if (estimatedPlan.getEstimatedPDSExternal() == 0) {
					map.addAttribute("estimatedPDSExternal_error",
							"Estimated PD's for external is required");
					hasError = true;
				}
			}
			if (hasError) {
				Connector connector = service.findById(estimatedPlan
						.getConnectorId());
				if (estimatedPlan.getAction().equals("Upload")) {
					map.addAttribute("connectorName", connector.getName());
					map.addAttribute("estimatedPlan", estimatedPlan);
				} else if (estimatedPlan.getAction().equals("Update")) {
					EstimatesPDF pdf = service.findByConnectorId(estimatedPlan
							.getConnectorId());
					map.addAttribute("connectorName", connector.getName());
					EstimatedPlan plan = new EstimatedPlan();
					plan.setConnectorId(estimatedPlan.getConnectorId());
					plan.setEstimatedPDS(connector.getEstimatedPds());
					plan.setStoryPoints(connector.getStoryPoints());
					plan.setFileId(pdf.getId());
					plan.setCategory(connector.getCategory());
					plan.setAction("Update");
					map.addAttribute("estimatedPlan", plan);

				}
				return "estimates";

			} else {
				Connector connector = service.findById(estimatedPlan
						.getConnectorId());
				if (estimatedPlan.getAction().equals("Upload")) {
					connector.setStoryPoints(estimatedPlan.getStoryPoints());
					connector.setCategory(estimatedPlan.getCategory());
					connector.setEstimatedPds(estimatedPlan.getEstimatedPDS());
					service.updateConnector(connector);
					EstimatesPDF estimatedPdf = new EstimatesPDF();
					estimatedPdf.setConnectorId(estimatedPlan.getConnectorId());
					estimatedPdf.setContentType(estimatedPlan.getEstimatedPdf()
							.getContentType());
					estimatedPdf.setFileName(estimatedPlan.getEstimatedPdf()
							.getOriginalFilename());
					InputStream io = estimatedPlan.getEstimatedPdf()
							.getInputStream();
					byte[] data = new byte[io.available()];
					io.read(data, 0, data.length);
					estimatedPdf.setFileContent(new SerialBlob(data));
					service.save(estimatedPdf);
				} else {
					connector.setCategoryExternal(estimatedPlan
							.getCategoryExternal());
					connector.setEstimatedPdsExternal(estimatedPlan
							.getEstimatedPDSExternal());
					service.updateConnector(connector);

					EstimatesPDF estimatedPdf = service
							.findByConnectorId(estimatedPlan.getConnectorId());
					estimatedPdf.setContentTypeExternal(estimatedPlan
							.getEstimatedPdfExternal().getContentType());
					estimatedPdf.setFileNameExternal(estimatedPlan
							.getEstimatedPdfExternal().getOriginalFilename());
					InputStream io = estimatedPlan.getEstimatedPdfExternal()
							.getInputStream();
					byte[] data = new byte[io.available()];
					io.read(data, 0, data.length);
					estimatedPdf.setFileContentExternal(new SerialBlob(data));
					service.update(estimatedPdf);
				}
				return "redirect:/connector/listMaster/false";
			}
		} catch (Exception e) {
			e.printStackTrace();
			attributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/connector/listMaster/false";
		}

	}

	@RequestMapping(value = { "/upload_estimates/{connectorId}" }, method = RequestMethod.GET)
	public String showUpdateEstimatePage(@PathVariable Integer connectorId,
			ModelMap model) throws Exception {
		Connector connector = service.findById(connectorId);
		model.addAttribute("connectorName", connector.getName());
		EstimatedPlan plan = new EstimatedPlan();
		plan.setConnectorId(connectorId);
		plan.setAction("Upload");
		model.addAttribute("estimatedPlan", plan);
		return "estimates";
	}

	@RequestMapping(value = { "/add_notes/{connectorId}" }, method = RequestMethod.GET)
	public String showNotesPage(@PathVariable Integer connectorId,
			ModelMap model) throws Exception {
		Connector connector = service.findById(connectorId);
		model.addAttribute("connectorName", connector.getName());
		model.addAttribute("action", "Add");
		model.addAttribute("connectorId", connectorId);
		return "notes";
	}

	@RequestMapping(value = { "/view_notes/{connectorId}" }, method = RequestMethod.GET)
	public String viewNotesPage(@PathVariable Integer connectorId,
			ModelMap model) throws Exception {
		Connector connector = service.findById(connectorId);
		model.addAttribute("connectorName", connector.getName());
		model.addAttribute("action", "Update");
		model.addAttribute("notes", notesService.findByConnectorId(connectorId));
		return "notes";
	}

	@RequestMapping(value = { "/showEpic/{connectorParentId}" }, method = RequestMethod.GET)
	public String showEpic(@PathVariable Integer connectorParentId,
			ModelMap model) throws Exception {
		List<String> epicList = new ArrayList<String>();
		List<Connector> connectors = service
				.findAllByConnectorParentId(connectorParentId);
		for (Connector connector : connectors) {
			if (connector.getEpicLink() != null) {
				if (connector.getEpicLink().indexOf(", ") != -1) {
					String[] epicLinks = connector.getEpicLink().split(", ");
					for (String eachEpicLink : epicLinks) {
						epicList.add(eachEpicLink);
					}
				} else {
					epicList.add(connector.getEpicLink());
				}
			}
		}
		model.addAttribute("epicList", epicList);
		return "epicList";
	}

	@RequestMapping(value = { "/showIssue/{connectorParentId}" }, method = RequestMethod.GET)
	public String showIssue(@PathVariable Integer connectorParentId,
			ModelMap model) throws Exception {
		model.addAttribute("connectorIssueList", connectorIssueService
				.findAllConnectorParentId(connectorParentId, 0));
		return "connectorIssueList";
	}

	@ResponseBody
	@RequestMapping(value = { "/saveNotes" }, method = RequestMethod.POST, produces = "application/json")
	public String saveNotes(@ModelAttribute("notes") Notes notes, ModelMap model)
			throws Exception {
		try {
			notesService.saveEntity(notes);
			return new String("{\"status\": \"Success\"}");
		} catch (Exception e) {
			return new String("{\"status\": \"Failed\"}");
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/updateNotes" }, method = RequestMethod.POST, produces = "application/json")
	public String updateNotes(@ModelAttribute("notes") Notes notes,
			ModelMap model) throws Exception {
		try {
			notesService.updateEntity(notes);
			return new String("{\"status\": \"Success\"}");
		} catch (Exception e) {
			return new String("{\"status\": \"Failed\"}");
		}
	}

	@RequestMapping(value = { "/update_estimates/{connectorId}" }, method = RequestMethod.GET)
	public String showUploadEstimatePage(@PathVariable Integer connectorId,
			ModelMap model) throws Exception {
		Connector connector = service.findById(connectorId);
		EstimatesPDF pdf = service.findByConnectorId(connectorId);
		model.addAttribute("connectorName", connector.getName());
		EstimatedPlan plan = new EstimatedPlan();
		plan.setConnectorId(connectorId);
		plan.setEstimatedPDS(connector.getEstimatedPds());
		plan.setStoryPoints(connector.getStoryPoints());
		plan.setFileId(pdf.getId());
		plan.setCategory(connector.getCategory());
		if (connector.getEstimatedPdsExternal() != null) {
			plan.setEstimatedPDSExternal(connector.getEstimatedPdsExternal());
		}
		if (connector.getCategoryExternal() != null) {
			plan.setCategoryExternal(connector.getCategoryExternal());
		}
		plan.setAction("Update");
		model.addAttribute("estimatedPlan", plan);
		return "estimates";
	}

	@RequestMapping(value = { "/download/{source}/{fileName}.{extension}" }, method = RequestMethod.GET)
	public void downloadFile(@PathVariable String source,
			@PathVariable("fileName") String fileName,
			@PathVariable("extension") String extension,
			HttpServletResponse response) throws Exception {
		String fieldName = "fileName";
		if (source.equals("external")) {
			fieldName = "fileNameExternal";
		}
		EstimatesPDF pdf = service.findByFileName(fileName + "." + extension,
				fieldName);
		if (source.equals("external")) {
			response.setContentType(pdf.getContentTypeExternal());
			response.setHeader(
					"Content-Disposition",
					String.format("inline; filename=\""
							+ pdf.getFileNameExternal() + "\""));
			Blob blob = pdf.getFileContentExternal();
			FileCopyUtils.copy(blob.getBinaryStream(),
					response.getOutputStream());
			response.flushBuffer();
		} else {
			response.setContentType(pdf.getContentType());
			response.setHeader(
					"Content-Disposition",
					String.format("inline; filename=\"" + pdf.getFileName()
							+ "\""));
			Blob blob = pdf.getFileContent();
			FileCopyUtils.copy(blob.getBinaryStream(),
					response.getOutputStream());
			response.flushBuffer();
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/getAllProjectIdsFromJira" }, method = RequestMethod.GET, produces = "application/json")
	public String getAllProjectIdsFromJira() throws Exception {
		SSLContext sslContext = SSLContexts.custom()
				.loadTrustMaterial(null, new TrustStrategy() {

					@Override
					public boolean isTrusted(X509Certificate[] arg0, String arg1)
							throws CertificateException {
						return true;
					}

				}).useProtocol("TLS").build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
				sslContext);
		StringBuffer buffer = new StringBuffer();
		CloseableHttpClient httpClient = HttpClientBuilder.create()
				.setSSLSocketFactory(sslsf).build();
		HttpGet httpGet = new HttpGet(COMPONENT_GET_URL);
		httpGet.addHeader("User-Agent", USER_AGENT);
		httpGet.addHeader(
				"Authorization",
				"Basic "
						+ Base64.encodeBase64String((JIRA_USERNAME + ":" + JIRA_PASSWORD)
								.getBytes()));
		CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
		if (httpResponse.getStatusLine().getStatusCode() == 200) {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					httpResponse.getEntity().getContent()));
			String inputLine;
			while ((inputLine = reader.readLine()) != null) {
				buffer.append(inputLine);
			}
			reader.close();
			httpClient.close();
		}
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getBugDetails/{jira_component}" }, method = RequestMethod.GET, produces = "application/json")
	public String getBugDetails(@PathVariable String jira_component,
			HttpServletResponse response) throws Exception {
		SSLContext sslContext = SSLContexts.custom()
				.loadTrustMaterial(null, new TrustStrategy() {

					@Override
					public boolean isTrusted(X509Certificate[] arg0, String arg1)
							throws CertificateException {
						return true;
					}

				}).useProtocol("TLS").build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
				sslContext);
		StringBuffer buffer = new StringBuffer();
		CloseableHttpClient httpClient = HttpClientBuilder.create()
				.setSSLSocketFactory(sslsf).build();
		HttpGet httpGet = new HttpGet(RESOLUTION_GET_URL
				+ "jql="
				+ URLEncoder.encode(String.format(SprintConstants.JQL_QUERY,
						jira_component), "UTF-8"));
		httpGet.addHeader("User-Agent", USER_AGENT);
		httpGet.addHeader(
				"Authorization",
				"Basic "
						+ Base64.encodeBase64String((JIRA_USERNAME + ":" + JIRA_PASSWORD)
								.getBytes()));

		httpGet.addHeader("Content-type", "application/json");
		CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
		if (httpResponse.getStatusLine().getStatusCode() == 200) {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode jsonNode = mapper.readTree(httpResponse.getEntity()
					.getContent());
			Map<String, Integer> resolution = new HashMap<String, Integer>();
			resolution.put("fixed", 0);
			resolution.put("notABug", 0);
			resolution.put("invalid", 0);
			resolution.put("duplicate", 0);

			if (jsonNode != null) {
				ArrayNode jsonArray = (ArrayNode) jsonNode.get("issues");
				for (int i = 0; i < jsonArray.size(); i++) {
					ObjectNode objectNode = (ObjectNode) jsonArray.get(i);
					if (objectNode != null) {
						String key = objectNode.get("fields").get("resolution")
								.get("name").getTextValue();
						if ("Fixed".equals(key)) {
							resolution
									.put("fixed", resolution.get("fixed") + 1);
						} else if ("Not a Bug".equals(key)) {
							resolution.put("notABug",
									resolution.get("notABug") + 1);
						} else if ("Invalid".equals(key)) {
							resolution.put("invalid",
									resolution.get("invalid") + 1);
						} else if ("Duplicate".equals(key)) {
							resolution.put("duplicate",
									resolution.get("duplicate") + 1);
						}
					}
				}
			}
			buffer.append("{");
			for (Iterator<String> iterator = resolution.keySet().iterator(); iterator
					.hasNext();) {
				String key = iterator.next();
				buffer.append("\"" + key + "\":" + resolution.get(key) + ",");
			}
			buffer.deleteCharAt(buffer.length() - 1);
			buffer.append("}");
		}
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getConnectorPlannedData" }, method = RequestMethod.GET, produces = "application/json")
	public String getConnectorPlannedData(HttpServletRequest request)
			throws Exception {
		String comparisonType = request.getParameter("comparisonType");
		String fromDate = request.getParameter("fromDate");
		String toDate = request.getParameter("toDate");
		String monthYear = request.getParameter("monthYear");

		List<ConnectorPlannedCompletion> plannedCompletion = notesService
				.findPlannedConnectorByDateOrMonth(fromDate, toDate, monthYear,
						comparisonType);
		StringBuffer buffer = new StringBuffer();
		buffer.append("{\"data\": [");
		for (ConnectorPlannedCompletion plannedConnector : plannedCompletion) {
			buffer.append("[");
			buffer.append("\"" + plannedConnector.getConnectorId() + "\",");
			buffer.append("\"" + plannedConnector.getConnectorName() + "\",");
			buffer.append("\"" + plannedConnector.getPlannedCompletionDate()
					+ "\",");
			buffer.append("\"" + plannedConnector.getNotes() + "\"");
			buffer.append("],");
		}
		if (!plannedCompletion.isEmpty()) {
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]}");
		return buffer.toString();
	}

	// Added by Nilesh
	/*
	 * @RequestMapping(value = { "/listMaster" }, method = RequestMethod.GET)
	 * public String getConnectorMasterList(ModelMap model) throws Exception {
	 * 
	 * List<Connector> connectors = service.findAllConnector();
	 * model.addAttribute("connectors", connectors); model.addAttribute("edit",
	 * false); return "view_connecto_master"; }
	 */

	@RequestMapping(value = { "/listMaster/{edit}" }, method = RequestMethod.GET)
	public String getConnectorMasterList(@PathVariable Boolean edit,
			ModelMap model, HttpServletRequest request) throws Exception {

		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user"); // added by NN
		Map<String, Object> filter = null;
		if (!edit) {
			filter = new HashMap<String, Object>();
			filter.put("status", OPEN);
			filter.put("likequery", true);
			filter.put("connName", "office");
			filter.put("leadID", activeUserData.getResourceId()); // added by NN
		}
		List<ConnectorMaster> connectorsMaster = connMasterService
				.findAllConnector(filter);
		Map<Integer, Double> estimatedCustPDs = new HashMap<Integer, Double>();
		Map<Integer, Double> estimatedIntPDs = new HashMap<Integer, Double>();
		Map<Integer, String> connCategory = new HashMap<Integer, String>();
		Map<Integer, Double> allocatedConnPDs = new HashMap<Integer, Double>();
		Map<Integer, Double> connectorSPs = new HashMap<Integer, Double>();
		Map<Integer, String> hasEpic = new HashMap<Integer, String>();
		Map<Integer, String> hasIssue = new HashMap<Integer, String>();
		Map<Integer, String> pslSME = new HashMap<Integer, String>();
		Map<Integer, String> devLead = new HashMap<Integer, String>();
		Map<Integer, String> qaLead = new HashMap<Integer, String>();

		for (ConnectorMaster connectorsMasters : connectorsMaster) {
			double totalEstimatedCustPDS = 0;
			double totalEstimatedIntPDS = 0;
			double allocatedPDs = 0;
			double connSPs = 0;

			String connectorCategory = null;
			List<Connector> masterConnectors = service
					.findAllByConnectorParentId(connectorsMasters.getId());
			if (!masterConnectors.isEmpty()) {
				for (Connector masterConnector : masterConnectors) {

					List<Resource> resPSLSME = connectorLeadMappingService
							.findLeadsByRole("pslSME",
									masterConnector.getConnectorParentId());
					if (!resPSLSME.isEmpty()) {
						pslSME.put(masterConnector.getConnectorParentId(),
								resPSLSME.get(0).getFirstName());
					}

					List<Resource> resdevLead = connectorLeadMappingService
							.findLeadsByRole("devLead",
									masterConnector.getConnectorParentId());
					if (!resdevLead.isEmpty()) {
						devLead.put(masterConnector.getConnectorParentId(),
								resdevLead.get(0).getFirstName());
					}

					List<Resource> resqaLead = connectorLeadMappingService
							.findLeadsByRole("qaLead",
									masterConnector.getConnectorParentId());
					if (!resqaLead.isEmpty()) {
						qaLead.put(masterConnector.getConnectorParentId(),
								resqaLead.get(0).getFirstName());
					}

					if (masterConnector.getEpicLink() != null) {
						if (hasEpic.containsKey(masterConnector
								.getConnectorParentId())) {
							String links = hasEpic.get(masterConnector
									.getConnectorParentId())
									+ ","
									+ masterConnector.getEpicLink();
							hasEpic.put(masterConnector.getConnectorParentId(),
									links);
						} else {
							hasEpic.put(masterConnector.getConnectorParentId(),
									masterConnector.getEpicLink());
						}
					}
					List<ConnectorIssueList> findAllConnectorParentId = connectorIssueService
							.findAllConnectorParentId(
									masterConnector.getConnectorParentId(), 0);
					if (!findAllConnectorParentId.isEmpty()) {
						hasIssue.put(masterConnector.getConnectorParentId(),
								"IssuePresent");
					}

					if (masterConnector.getEstimatedPdsExternal() != null
							&& masterConnector.getEstimatedPdsExternalQa() != null) {
						totalEstimatedCustPDS += masterConnector
								.getEstimatedPdsExternal()
								+ masterConnector.getEstimatedPdsExternalQa();
					}
					if (masterConnector.getEstimatedPds() != null
							&& masterConnector.getEstimatedPdsQa() != null) {
						totalEstimatedIntPDS += masterConnector
								.getEstimatedPds()
								+ masterConnector.getEstimatedPdsQa();
					}

					if (masterConnector.getStoryPoints() != null
							&& masterConnector.getStoryPointsQa() != null) {
						connSPs += masterConnector.getStoryPoints()
								+ masterConnector.getStoryPointsQa();
					}

					List<ResourceDTO> resourceDtos = service
							.findAllResourcesWithDateFlag(masterConnector
									.getName());
					for (ResourceDTO resourceDto : resourceDtos) {
						allocatedPDs += resourceDto.getPDs();
					}
				}
			}
			estimatedCustPDs.put(connectorsMasters.getId(), new BigDecimal(
					totalEstimatedCustPDS)
					.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
			estimatedIntPDs.put(connectorsMasters.getId(), new BigDecimal(
					totalEstimatedIntPDS).setScale(2, BigDecimal.ROUND_HALF_UP)
					.doubleValue());

			allocatedConnPDs.put(connectorsMasters.getId(), new BigDecimal(
					allocatedPDs).setScale(2, BigDecimal.ROUND_HALF_UP)
					.doubleValue());

			connectorSPs.put(connectorsMasters.getId(), new BigDecimal(connSPs)
					.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue());
			if (totalEstimatedCustPDS <= 0) {
				connectorCategory = "TBD";
			} else if (totalEstimatedCustPDS > 0 && totalEstimatedCustPDS <= 30) {
				connectorCategory = "XS";
			} else if (totalEstimatedCustPDS > 30 && totalEstimatedCustPDS <= 60) {
				connectorCategory = "S";
			} else if (totalEstimatedCustPDS > 60 && totalEstimatedCustPDS <= 100) {
				connectorCategory = "M";
			} else if (totalEstimatedCustPDS > 100
					&& totalEstimatedCustPDS <= 140) {
				connectorCategory = "L";
			} else if (totalEstimatedCustPDS > 140
					&& totalEstimatedCustPDS <= 180) {
				connectorCategory = "XL";
			} else {
				connectorCategory = "Undefined";
			}

			connCategory.put(connectorsMasters.getId(), connectorCategory);
		}
		model.addAttribute("connectorsmater", connectorsMaster);
		model.addAttribute("estimatedCustPDs", estimatedCustPDs);
		model.addAttribute("estimatedIntPDs", estimatedIntPDs);
		model.addAttribute("connectorCategory", connCategory);
		model.addAttribute("allocatedConnPDs", allocatedConnPDs);
		model.addAttribute("connectorSPs", connectorSPs);
		model.addAttribute("epicLink", hasEpic);
		model.addAttribute("issue", hasIssue);
		model.addAttribute("pslSME", pslSME);
		model.addAttribute("devLead", devLead);
		model.addAttribute("qaLead", qaLead);

		return "view_connector_master";
	}

	@ResponseBody
	@RequestMapping(value = { "/searchLikeConnectors" }, method = RequestMethod.GET, produces = "application/json")
	public String searchLikeConnectors() throws Exception {
		List<Connector> connectors = service.findAllConnectorsWithNameLike();
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (Connector eachConnector : connectors) {
			buffer.append("{");
			buffer.append("\"connector_id\":" + eachConnector.getId() + ",");
			buffer.append("\"connector_name\": \"" + eachConnector.getName()
					+ "\"");
			buffer.append("},");
		}
		if (!connectors.isEmpty()) {
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]");
		return buffer.toString();
	}

	@RequestMapping(value = { "/getPDSDateWise" }, method = RequestMethod.GET)
	public @ResponseBody
	String getPDSDateWise(HttpServletRequest request) throws Exception {
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		StringBuffer buffer = new StringBuffer();
		buffer.append("{");
		buffer.append("\"data\" : [");
		List<TemporaryResults> findByStartDateAndEndDate = allocationReportService
				.findByStartDateAndEndDate(startDate, endDate, null);
		for (TemporaryResults result : findByStartDateAndEndDate) {
			buffer.append("[");
			buffer.append("\"" + result.getConnector_id() + "\", ");
			buffer.append("\"" + result.getConnector_name() + "\", ");
			buffer.append("\"" + result.getAdjust_day() + "\"");
			buffer.append("],");
		}
		if (!findByStartDateAndEndDate.isEmpty()) {
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]");
		buffer.append("}");
		return buffer.toString();
	}

	@RequestMapping(value = { "/createWordDoc" }, method = RequestMethod.GET)
	public void getWSR(HttpServletResponse response) throws Exception {
		OutputStream out = response.getOutputStream();

		List<ConnectorIssueList> findAllConnectorParentId = connectorIssueService
				.findAllConnectorParentId(null, 0);

		// Blank Document
		XWPFDocument document = new XWPFDocument();

		// create table
		XWPFTable table = document.createTable();

		// Create Header
		XWPFTableRow tableRowOne = table.getRow(0);

		XWPFParagraph p0 = tableRowOne.getCell(0).getParagraphs().get(0);
		XWPFRun r0 = p0.createRun();
		r0.setBold(true);
		r0.setText("Epic#");
		r0.setFontFamily("Calibri (Body)");
		r0.setTextPosition(100);

		XWPFParagraph p1 = tableRowOne.addNewTableCell().getParagraphs().get(0);
		XWPFRun r1 = p1.createRun();
		r1.setBold(true);
		r1.setText("Connector Name");
		r1.setFontFamily("Calibri (Body)");
		r1.setTextPosition(100);

		XWPFParagraph p2 = tableRowOne.addNewTableCell().getParagraphs().get(0);
		XWPFRun r2 = p2.createRun();
		r2.setBold(true);
		r2.setText("Blocker");
		r2.setFontFamily("Calibri (Body)");
		r2.setTextPosition(100);

		XWPFParagraph p3 = tableRowOne.addNewTableCell().getParagraphs().get(0);
		XWPFRun r3 = p3.createRun();
		r3.setBold(true);
		r3.setText("Description");
		r3.setFontFamily("Calibri (Body)");
		r3.setTextPosition(100);

		for (int j = 0; j < findAllConnectorParentId.size();) {
			ConnectorIssueList issueList = findAllConnectorParentId.get(j);
			Connector connector = service.findById(issueList.getConnectorId());
			// create second row
			XWPFTableRow tableRow = table.createRow();

			String epicLink = connector.getEpicLink();
			if (epicLink != null) {
				if (epicLink.indexOf(", ") != -1) {
					String[] epics = epicLink.split(", ");
					for (int i = 0; i < epics.length; i++) {
						String eachEpic = epics[i];
						boolean isValidURL = false;
						try {
							new URL(eachEpic);
							isValidURL = true;
						} catch (MalformedURLException malURLException) {
						}
						String epicId = eachEpic.substring(eachEpic
								.lastIndexOf("/") + 1);
						XWPFParagraph epicPara = tableRow.getCell(0)
								.getParagraphs().get(0);
						if (isValidURL) {
							String id = epicPara
									.getDocument()
									.getPackagePart()
									.addExternalRelationship(
											eachEpic,
											XWPFRelation.HYPERLINK
													.getRelation()).getId();
							// Append the link and bind it to the relationship
							CTHyperlink cLink = epicPara.getCTP()
									.addNewHyperlink();
							cLink.setId(id);
							// Create the linked text
							CTText ctText = CTText.Factory.newInstance();
							ctText.setStringValue(epicId);
							CTR ctr = CTR.Factory.newInstance();
							CTRPr rpr = ctr.addNewRPr();
							CTColor colour = CTColor.Factory.newInstance();
							colour.setVal("0000FF");
							rpr.setColor(colour);
							rpr.addNewU().setVal(STUnderline.SINGLE);
							ctr.setTArray(new CTText[] { ctText });
							// Insert the linked text into the link
							cLink.setRArray(new CTR[] { ctr });
						}
						if (i < (epics.length - 1)) {
							XWPFRun space = epicPara.createRun();
							space.setText(", ");
						}
					}
				} else {
					String epicId = epicLink.substring(epicLink
							.lastIndexOf("/") + 1);
					XWPFParagraph epicPara = tableRow.getCell(0)
							.getParagraphs().get(0);
					boolean isValidURL = false;
					try {
						new URL(epicLink);
						isValidURL = true;
					} catch (MalformedURLException malURLException) {
					}

					if (isValidURL) {
						String id = epicPara
								.getDocument()
								.getPackagePart()
								.addExternalRelationship(epicLink,
										XWPFRelation.HYPERLINK.getRelation())
								.getId();
						// Append the link and bind it to the relationship
						CTHyperlink cLink = epicPara.getCTP().addNewHyperlink();
						cLink.setId(id);
						// Create the linked text
						CTText ctText = CTText.Factory.newInstance();
						ctText.setStringValue(epicId);
						CTR ctr = CTR.Factory.newInstance();
						CTRPr rpr = ctr.addNewRPr();
						CTColor colour = CTColor.Factory.newInstance();
						colour.setVal("0000FF");
						rpr.setColor(colour);
						rpr.addNewU().setVal(STUnderline.SINGLE);
						ctr.setTArray(new CTText[] { ctText });
						// Insert the linked text into the link
						cLink.setRArray(new CTR[] { ctr });
					}
				}
			} else {
				tableRow.getCell(0).setText("No EPIC created");
			}
			tableRow.getCell(1).setText(issueList.getConnectorName());

			XWPFParagraph xwpfParagraph = tableRow.getCell(2).getParagraphs()
					.get(0); // setText(issueList.getIssueTitle() + "\n" +
			// issueList.getGitIssueLink());
			int k = j;
			while (j < findAllConnectorParentId.size()
					&& findAllConnectorParentId.get(k).getConnectorId() == issueList
							.getConnectorId()) {
				ConnectorIssueList temp = findAllConnectorParentId.get(k);
				XWPFRun space = xwpfParagraph.createRun();
				space.setText(temp.getIssueTitle() + " ");
				if (temp.getGitIssueLink() != null) {
					String issueId = temp.getGitIssueLink().substring(
							temp.getGitIssueLink().lastIndexOf("/") + 1);
					boolean isValidURL = false;
					try {
						new URL(temp.getGitIssueLink());
						isValidURL = true;
					} catch (MalformedURLException malURLException) {
					}
					if (isValidURL) {
						String id = xwpfParagraph

								.getDocument()
								.getPackagePart()
								.addExternalRelationship(
										temp.getGitIssueLink(),
										XWPFRelation.HYPERLINK.getRelation())
								.getId();
						// Append the link and bind it to the relationship
						CTHyperlink cLink = xwpfParagraph.getCTP()
								.addNewHyperlink();
						cLink.setId(id);
						// Create the linked text
						CTText ctText = CTText.Factory.newInstance();
						ctText.setStringValue(issueId);
						CTR ctr = CTR.Factory.newInstance();
						CTRPr rpr = ctr.addNewRPr();
						CTColor colour = CTColor.Factory.newInstance();
						colour.setVal("0000FF");
						rpr.setColor(colour);
						rpr.addNewU().setVal(STUnderline.SINGLE);
						ctr.setTArray(new CTText[] { ctText });
						// Insert the linked text into the link
						cLink.setRArray(new CTR[] { ctr });
					}
				}
				XWPFRun date = xwpfParagraph.createRun();
				date.setText(" (" + temp.getGitIssueDate().toString() + ")");
				xwpfParagraph.createRun().addBreak();
				k++;
				j = k;
			}
			tableRow.getCell(3).setText("");
		}

		response.setHeader("Content-Disposition",
				"attachment; filename=\"WSR.docx\"");
		response.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		document.write(out);
		response.flushBuffer();
		document.close();
	}

	@ResponseBody
	@RequestMapping(value = { "/getJiraIssueDetails" }, method = RequestMethod.GET, produces = "application/json")
	public String getJiraIssueDetails(HttpServletResponse response)
			throws Exception {
		String summary = null;
		String key = null;
		SSLContext sslContext = SSLContexts.custom()
				.loadTrustMaterial(null, new TrustStrategy() {

					@Override
					public boolean isTrusted(X509Certificate[] arg0, String arg1)
							throws CertificateException {
						return true;
					}

				}).useProtocol("TLS").build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
				sslContext);
		StringBuffer buffer = new StringBuffer();
		CloseableHttpClient httpClient = HttpClientBuilder.create()
				.setSSLSocketFactory(sslsf).build();
		HttpGet httpGet = new HttpGet(RESOLUTION_GET_URL
				+ "jql="
				+ URLEncoder.encode(SprintConstants.JQL_QUERY_FOR_L3SUPPORT,
						"UTF-8"));
		httpGet.addHeader("User-Agent", USER_AGENT);
		httpGet.addHeader(
				"Authorization",
				"Basic "
						+ Base64.encodeBase64String((JIRA_USERNAME + ":" + JIRA_PASSWORD)
								.getBytes()));

		httpGet.addHeader("Content-type", "application/json");
		CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
		if (httpResponse.getStatusLine().getStatusCode() == 200) {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode jsonNode = mapper.readTree(httpResponse.getEntity()
					.getContent());
			List<IssueTrackerJiraMapping> mappingList = issueTrackerJiraMappingService
					.findAll();
			if (jsonNode != null) {
				ArrayNode jsonArray = (ArrayNode) jsonNode.get("issues");
				HashMap<String, String> map = new HashMap<String, String>();
				buffer.append("[");
				for (int i = 0; i < jsonArray.size(); i++) {
					boolean unique = true;
					ObjectNode objectNode = (ObjectNode) jsonArray.get(i);
					if (objectNode != null) {
						summary = objectNode.get("fields").get("summary")
								.getTextValue();
						key = objectNode.get("key").toString();
						key = key.replace("\"", "");
					}

					String idStr = null;
					for (IssueTrackerJiraMapping issueTrackerJiraMapping : mappingList) {
						String jiraLink = issueTrackerJiraMapping
								.getJira_link();
						URI uri = new URI(jiraLink);
						String path = uri.getPath();
						idStr = path.substring(path.lastIndexOf('/') + 1);
						idStr = idStr.trim();

						if (idStr.equals(key)) {
							unique = false;
							break;

						}
					}
					if (unique) {
						map.put(key, summary);
					}

				}
				if (mappingList.isEmpty()) {
					buffer.append("{");
					buffer.append("\"summary\":\"" + summary + "\",");
					buffer.append("\"key\":\"" + key + "\" ");
					buffer.append("},");
				}

				else {

					for (String stringKey : map.keySet()) {
						buffer.append("{");
						buffer.append("\"summary\":\"" + map.get(stringKey)
								+ "\",");
						buffer.append("\"key\":\"" + stringKey + "\" ");
						buffer.append("},");

					}
				}

				if (!(jsonArray.isNull())) {
					buffer.deleteCharAt(buffer.length() - 1);
				}
				buffer.append("]");

			}
		}

		return buffer.toString();
	}

	@RequestMapping(value = { "/connectorReview" }, method = RequestMethod.GET)
	public String connectorReview(ModelMap model,
			@ModelAttribute("error") final String error) throws Exception {

		ResourceWrapper resourceWrapper = new ResourceWrapper();
		List<ConnectorMaster> list = service.findAllConnectorMaster();
		List<ReviewPhase> reviewPhaseList = service.getAllReviewPhases();
		resourceWrapper.setReviewPhaseList(reviewPhaseList);
		resourceWrapper.setListOfConnectorMaster(list);
		model.addAttribute("reviewPhaseList",
				resourceWrapper.getReviewPhaseList());
		model.addAttribute("connectors",
				resourceWrapper.getListOfConnectorMaster());
		model.addAttribute("reviewer", reviewer);
		model.addAttribute("reviewType", reviewType);
		model.addAttribute("severity", severity);
		model.addAttribute("resourceWrapper", resourceWrapper);
		model.addAttribute("edit", false);
		Review review = new Review();
		model.addAttribute("review", review);
		return "connector_review";
	}

	@RequestMapping(value = { "/connectorReview/edit/{reviewId}" }, method = RequestMethod.GET)
	public String editconnectorReview(@PathVariable Integer reviewId,
			ModelMap model) throws Exception {
		Review review = connectorService.findReviewById(reviewId);
		model.addAttribute("review", review);

		ResourceWrapper resourceWrapper = new ResourceWrapper();
		List<ConnectorMaster> list = service.findAllConnectorMaster();
		List<ReviewPhase> reviewPhaseList = service.getAllReviewPhases();
		resourceWrapper.setReviewPhaseList(reviewPhaseList);
		resourceWrapper.setListOfConnectorMaster(list);

		model.addAttribute("edit", true);
		model.addAttribute("reviewPhaseList",
				resourceWrapper.getReviewPhaseList());
		model.addAttribute("connectors",
				resourceWrapper.getListOfConnectorMaster());
		model.addAttribute("reviewer", reviewer);
		model.addAttribute("reviewType", reviewType);
		model.addAttribute("severity", severity);
		model.addAttribute("reviewComments", review.getReviewComments());
		model.addAttribute("resourceWrapper", resourceWrapper);
		return "connector_review";
	}

	@RequestMapping(value = { "/connectorReview" }, method = RequestMethod.POST)
	public String connectorReview(@ModelAttribute("review") Review review,
			ModelMap model, HttpServletRequest request) throws Exception {

		String reviewArray[] = request.getParameterValues("reviewComments");
		String severityArray[] = request.getParameterValues("severity");
		try {

			boolean hasError = false;
			// List<String> connectorType = new ArrayList<String>();

			Resource resource = (Resource) request.getSession().getAttribute(
					"user");
			review.setReviewer(resource.getFirstName());
			// service.saveReview(review);

			if (review.getConnectorMID() == null
					|| review.getConnectorMID().toString().equals("-1")) {
				model.addAttribute("connectorError", "Connector name required");
				hasError = true;
			}

			if (review.getId_review_phase() == null
					|| review.getId_review_phase().toString().equals("-1")) {
				model.addAttribute("phaseError", "Phase required");
				hasError = true;
			}

			if (review.getReviewType() == null
					|| review.getReviewType().equals("NONE")) {
				model.addAttribute("reviewTypeError", "Review Type required");
				hasError = true;
			}
			if (review.getSeverity() == null
					|| review.getSeverity().equals("NONE")) {
				model.addAttribute("severityError", "Severity required");
				hasError = true;
			}

			if (hasError) {

				model.addAttribute("review", review);
				model.addAttribute("edit", false);
				// --
				ResourceWrapper resourceWrapper = new ResourceWrapper();
				List<ConnectorMaster> list = service.findAllConnectorMaster();
				List<ReviewPhase> reviewPhaseList = service
						.getAllReviewPhases();
				resourceWrapper.setReviewPhaseList(reviewPhaseList);
				resourceWrapper.setListOfConnectorMaster(list);
				model.addAttribute("reviewPhaseList",
						resourceWrapper.getReviewPhaseList());
				model.addAttribute("connectors",
						resourceWrapper.getListOfConnectorMaster());
				model.addAttribute("reviewer", reviewer);
				model.addAttribute("reviewType", reviewType);
				model.addAttribute("severity", severity);
				model.addAttribute("resourceWrapper", resourceWrapper);

				return "connector_review";
			} else {
				for (int i = 0; i < reviewArray.length; i++) {

					Review reviewDB = new Review();
					reviewDB.setReviewer(review.getReviewer());
					reviewDB.setConnectorMID(review.getConnectorMID());
					reviewDB.setId_review_phase(review.getId_review_phase());
					reviewDB.setReviewType(review.getReviewType());
					reviewDB.setReviewComments(reviewArray[i]);
					reviewDB.setSeverity(severityArray[i]);

					connectorService.saveReview(reviewDB);
					reviewDB = null;
				}
				return "redirect:/connector/connectorReview";
				// return "redirect:/connector/listMaster/false";
			}
		} catch (Exception e) {
			e.printStackTrace();
			// return "redirect:/connector/admin/new";
		}
		return "redirect:/connector/connectorReview";

	}

	@RequestMapping(value = { "/admin/reviewPhase/new" }, method = RequestMethod.GET)
	public String getConnectorReviewPhase(ModelMap model,
			@ModelAttribute("error") final String error) {
		ReviewPhase phase = new ReviewPhase();
		model.addAttribute("phase", phase);
		model.addAttribute("edit", false);
		return "connector_review_phase";
	}

	@RequestMapping(value = { "/admin/reviewPhase/new" }, method = RequestMethod.POST)
	public String saveConnectorReviewPhase(
			@ModelAttribute("phase") ReviewPhase phase, ModelMap model,
			HttpServletRequest request) throws Exception {
		try {
			boolean hasError = false;

			if (phase.getReviewPhase() == null
					|| phase.getReviewPhase().isEmpty()) {
				model.addAttribute("reviewPhase_error", "REVIEW PHASE REQUIRED");
				hasError = true;
			}
			if (hasError) {
				model.addAttribute("phase", phase);
				model.addAttribute("edit", false);
				return "connector_review_phase";
			} else {
				connectorService.saveReviewPhase(phase);
				return "redirect:/connector/listMaster/false";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "redirect:/connector/admin/new";
		}

	}

	// REPORT
	@RequestMapping(value = { "/view-review_report/{edit}" }, method = RequestMethod.GET)
	public String findAllReviews(@PathVariable boolean edit, ModelMap model)
			throws Exception {
		try {
			model.addAttribute("reviews",
					connectorService.getAllReviews());
			return "view_reviews";
		} catch (Exception e) {
			return "view_reviews";
		}

	}

	@RequestMapping(value = { "/connectorReview/edit/{reviewId}" }, method = RequestMethod.POST)
	public String editconnectorReview(@ModelAttribute("review") Review review,
			ModelMap model, @PathVariable Integer reviewId,
			HttpServletRequest request) throws Exception {

		String reviewArray[] = request.getParameterValues("reviewComments");
		String severityArray[] = request.getParameterValues("severity");
		try {

			boolean hasError = false;
			Resource resource = (Resource) request.getSession().getAttribute(
					"user");
			review.setReviewer(resource.getFirstName());

			/*
			 * if (review.getConnectorMID() == null ||
			 * review.getConnectorMID().toString().equals("-1")) {
			 * model.addAttribute("connectorError", "Connector name required");
			 * hasError = true; }
			 * 
			 * if (review.getId_review_phase() == null ||
			 * review.getId_review_phase().toString().equals("-1")) {
			 * model.addAttribute("phaseError", "Phase required"); hasError =
			 * true; }
			 * 
			 * if (review.getReviewType() == null ||
			 * review.getReviewType().equals("NONE")) {
			 * model.addAttribute("reviewTypeError", "Review Type required");
			 * hasError = true; }
			 */

			if (review.getSeverity() == null
					|| review.getSeverity().equals("NONE")) {
				model.addAttribute("severityError", "Severity required");
				hasError = true;
			}

			if (hasError) {

				model.addAttribute("review", review);
				model.addAttribute("edit", false);
				// --
				ResourceWrapper resourceWrapper = new ResourceWrapper();
				List<ConnectorMaster> list = service.findAllConnectorMaster();
				List<ReviewPhase> reviewPhaseList = service
						.getAllReviewPhases();
				resourceWrapper.setReviewPhaseList(reviewPhaseList);
				resourceWrapper.setListOfConnectorMaster(list);
				model.addAttribute("reviewPhaseList",
						resourceWrapper.getReviewPhaseList());
				model.addAttribute("connectors",
						resourceWrapper.getListOfConnectorMaster());
				model.addAttribute("reviewer", reviewer);
				model.addAttribute("reviewType", reviewType);
				model.addAttribute("severity", severity);
				model.addAttribute("resourceWrapper", resourceWrapper);
				return "connector_review";
			} else {

				Review existing_review = connectorService
						.findReviewById(reviewId);

				model.addAttribute("review", review);
				existing_review.setReviewComments(reviewArray[0]);
				existing_review.setSeverity(severityArray[0]);
				connectorService.updateReview(existing_review);
			}
			return "redirect:/connector/connectorReview";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/connector/connectorReview";
	}

	@RequestMapping(value = { "/manageReviews/{edit}" }, method = RequestMethod.GET)
	public String getReview(@PathVariable boolean edit, ModelMap model)
			throws Exception {
		try {
			model.addAttribute("reviews",
					connectorService.getReview());
			return "manage_reviews";
		} catch (Exception e) {
			return "manage_reviews";
		}
	}

	@RequestMapping(value = { "/showReview/{connectorMID}" }, method = RequestMethod.GET)
	public String showReview(@PathVariable Integer connectorMID, ModelMap model)
			throws Exception {
		model.addAttribute("connectorReviewList",
				connectorService.getReviewForConnector(connectorMID));
		return "connectorReviewList";
	}
}