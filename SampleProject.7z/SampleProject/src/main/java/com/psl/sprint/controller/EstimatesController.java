package com.psl.sprint.controller;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.node.ArrayNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorComplexity;
import com.psl.sprint.model.ConnectorEstimationMapping;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.model.EffortsEstimationMaster;
import com.psl.sprint.model.EstimationHeaderQuestionConnector;
import com.psl.sprint.model.EstimationHeaders;
import com.psl.sprint.model.EstimationReport;
import com.psl.sprint.model.EstimationSubHeaders;
import com.psl.sprint.model.Questions;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.StoryPointsEstimationMaster;
import com.psl.sprint.service.ConnectorComplexityService;
import com.psl.sprint.service.ConnectorEstimationMappingService;
import com.psl.sprint.service.ConnectorMasterService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.EffortsEstimationMasterService;
import com.psl.sprint.service.EstimationHeadersService;
import com.psl.sprint.service.EstimationReportService;
import com.psl.sprint.service.EstimationSubHeadersService;
import com.psl.sprint.service.MasterService;
import com.psl.sprint.service.QuestionsService;
import com.psl.sprint.service.StoryPointsEstimationMasterService;
import com.psl.sprint.util.SprintConstants;

@Controller
@RequestMapping("/estimates")
public class EstimatesController extends AbstractController {

	@Autowired
	private EstimationHeadersService estimationHeadersService;

	@Autowired
	private EstimationSubHeadersService estimationSubHeadersService;

	@Autowired
	private QuestionsService questionsService;

	@Autowired
	private MasterService masterServiceImpl;

	@Autowired
	private EffortsEstimationMasterService effortsEstimationMasterService;

	@Autowired
	private StoryPointsEstimationMasterService storyPointsEstimationMasterService;

	@Autowired
	private ConnectorService service;

	@Autowired
	private ConnectorEstimationMappingService connectorEstimationMappingService;

	@Autowired
	private ConnectorMasterService connectorMasterService;

	@Autowired
	private ConnectorComplexityService connectorComplexityService;

	@Autowired
	private EstimationReportService estimationReportService;

	@RequestMapping(value = { "/main" }, method = RequestMethod.GET)
	public String getMainPage(ModelMap model) {
		return "connector_estimation";
	}

	@ResponseBody
	@RequestMapping(value = { "/getQuestionsForEstimates/{connectorType}" }, method = RequestMethod.GET, produces = "application/json")
	public String getQuestionsForEstimates(@PathVariable String connectorType,
			ModelMap model) throws Exception {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		List<EstimationHeaders> findByType = estimationHeadersService
				.findByType(connectorType, SprintConstants.TEMPLATE_VERSION);
		for (EstimationHeaders eachEstimationHeaders : findByType) {
			buffer.append("{");
			buffer.append("\"parameterName\": \""
					+ eachEstimationHeaders.getId() + ". "
					+ eachEstimationHeaders.getSDLCPhaseTask() + "\",");
			buffer.append("\"hid\": " + eachEstimationHeaders.getId() + ",");
			List<EstimationSubHeaders> findByHeaderId = estimationSubHeadersService
					.findByHeaderId(eachEstimationHeaders.getId());
			buffer.append("\"guidelines\": [");
			if (!findByHeaderId.isEmpty()) {
				for (EstimationSubHeaders eachEstimationSubHeaders : findByHeaderId) {
					List<Questions> findByHeaderIdAndSubHeaderId = questionsService
							.findByHeaderIdAndSubHeaderId(
									eachEstimationHeaders.getId(),
									eachEstimationSubHeaders.getId());
					buffer.append("{");
					if (!findByHeaderIdAndSubHeaderId.isEmpty()) {
						buffer.append("\"description\":\""
								+ ((eachEstimationSubHeaders.getADDINFO() == null) ? ""
										: eachEstimationSubHeaders.getADDINFO())
								+ "\",");
						buffer.append("\"question\":\""
								+ ((eachEstimationSubHeaders.getQDesc() == null) ? ""
										: eachEstimationSubHeaders.getQDesc())
								+ "\",");
						buffer.append("\"shid\": "
								+ eachEstimationSubHeaders.getId() + ",");
						buffer.append("\"options\": [");
						for (Questions eachQuestion : findByHeaderIdAndSubHeaderId) {
							buffer.append("{");
							if (eachQuestion.getOptions() != null
									&& eachQuestion.getComplexity() != null) {
								buffer.append("\"qid\": "
										+ eachQuestion.getId() + ",");
								buffer.append("\"option\": \""
										+ eachQuestion.getOptions() + "\",");
								buffer.append("\"value\": "
										+ eachQuestion.getComplexity() + "");
							} else {
								buffer.append("\"qid\": "
										+ eachQuestion.getId());
							}
							buffer.append("},");
						}
						if (!findByHeaderIdAndSubHeaderId.isEmpty()) {
							buffer.deleteCharAt(buffer.length() - 1);
						}
						buffer.append("]");
					}
					buffer.append("},");
				}
				buffer.deleteCharAt(buffer.length() - 1);
			} else {
				buffer.append("{}");
			}
			buffer.append("]");
			buffer.append("},");
		}

		if (!findByType.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getDisabled/{connectorType}" }, method = RequestMethod.GET, produces = "application/json")
	public String getDisabled(@PathVariable String connectorType, ModelMap model)
			throws Exception {
		String type = null;
		if (connectorType.equals("Outbound"))
			type = "disabled_outbound";
		else if (connectorType.equals("Polling"))
			type = "disabled_polling";
		else
			type = "disabled_webhooks";
		return new String(Base64.decode(masterServiceImpl
				.findUniqueRecordByName(type).getValue().getBytes()));
	}

	@ResponseBody
	@RequestMapping(value = { "/getConnectorMaster" }, method = RequestMethod.GET, produces = "application/json")
	public String getConnectorMaster(ModelMap model,HttpServletRequest request) throws Exception {
		
		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user"); // added by NN
		Map<String, Object> filter = null;
		filter = new HashMap<String, Object>();
		filter.put("leadID", activeUserData.getResourceId()); // added by NN
		
		
		List<ConnectorMaster> findAll = (List<ConnectorMaster>) connectorMasterService.findAllConnector(filter);
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (ConnectorMaster connectorMaster : findAll) {
			buffer.append("{");
			buffer.append("\"name\":\"" + connectorMaster.getConnectorName()
					+ "\",");
			buffer.append("\"id\":" + connectorMaster.getId());
			buffer.append("},");
		}
		if (!findAll.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getConnectorByMasterId/{connectorMasterId}" }, method = RequestMethod.GET, produces = "application/json")
	public String getConnectorByMasterId(
			@PathVariable Integer connectorMasterId, ModelMap model)
			throws Exception {
		List<Connector> findAllByConnectorParentId = service
				.findAllByConnectorParentId(connectorMasterId);
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (Connector connector : findAllByConnectorParentId) {
			buffer.append("{");
			buffer.append("\"connector_id\":" + connector.getId() + ", ");
			buffer.append("\"connectorType\":\"" + connector.getConnectorType()
					+ "\",");
			buffer.append("\"connectorName\":\"" + connector.getName() + "\",");
			buffer.append("\"category\":\""
					+ ((connector.getCategory() == null) ? "" : connector
							.getCategory()) + "\"");
			buffer.append("},");
		}
		if (!findAllByConnectorParentId.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getSummary/{connectorMasterId}" }, method = RequestMethod.GET, produces = "application/json")
	public String getSummary(@PathVariable Integer connectorMasterId,
			ModelMap model) throws Exception {
		List<Connector> findAllByConnectorParentId = service
				.findAllByConnectorParentId(connectorMasterId);
		ConnectorMaster connectorMaster = (ConnectorMaster) connectorMasterService
				.findById(connectorMasterId);
		StringBuffer buffer = new StringBuffer();
		buffer.append("{");
		buffer.append("\"connector_master_name\":\""
				+ connectorMaster.getConnectorName() + "\",");
		buffer.append("\"sub_connector\" : [");
		for (Connector connector : findAllByConnectorParentId) {
			buffer.append("{");
			buffer.append("\"connector_name\": \"" + connector.getName().trim()
					+ "\",");
			buffer.append("\"connector_category\": \""
					+ ((connector.getCategory() == null) ? "" : connector
							.getCategory()) + "\",");
			buffer.append("\"story_points_dev\": " + connector.getStoryPoints()
					+ ",");
			buffer.append("\"pd_dev\":" + connector.getEstimatedPds() + ",");
			buffer.append("\"story_points_qa\": "
					+ connector.getStoryPointsQa() + ",");
			buffer.append("\"qa_dev\":" + connector.getEstimatedPdsQa() + ",");
			buffer.append("\"connectorType\":" + connector.getConnectorType());
			buffer.append("},");
		}
		if (!findAllByConnectorParentId.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");
		buffer.append("}");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/saveEstimates" }, method = RequestMethod.POST, produces = "application/json")
	public String saveEstimates(HttpServletRequest request, ModelMap model)
			throws Exception {
		String json = request.getParameter("json");
		String connectorType = request.getParameter("connectorType");
		if (json != null && connectorType != null) {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode actualObj = mapper.readTree(json);
			Integer connectorId = actualObj.get("connector_id").asInt();
			Connector connector = service.findById(connectorId);
			Integer parentId = connector.getConnectorParentId();
			String version = masterServiceImpl.findUniqueRecordByName(
					"template_version").getValue();
			List<EffortsEstimationMaster> findEffortsByVersionAndType = effortsEstimationMasterService
					.findByVersionAndType(version, connectorType);
			List<StoryPointsEstimationMaster> findStoryPointsByVersionAndType = storyPointsEstimationMasterService
					.findByVersionAndType(version, connectorType);
			connectorEstimationMappingService.deleteByConnectorId(connectorId);
			Double dev_share_pds = 0.0;
			Double qa_share_pds = 0.0;
			Double dev_share_sps = 0.0;
			Double qa_share_sps = 0.0;

			ArrayNode estimations = (ArrayNode) actualObj.get("estimations");
			for (int i = 0; i < estimations.size(); i++) {
				JsonNode eachNode = estimations.get(i);
				Integer hid = eachNode.get("hid").asInt();
				String type = null;
				Double complex = eachNode.get("complex").asDouble();
				if (eachNode.get("type") != null) {
					type = eachNode.get("type").getTextValue();
				}
				ArrayNode shids = (ArrayNode) eachNode.get("shids");
				Double pds = null;
				String description = null;
				if (type != null && type.equals("INPUT")) {
					pds = eachNode.get("pds").asDouble();
					description = eachNode.get("description")
							.getTextValue();
				}
				for (int ii = 0; ii < shids.size(); ii++) {
					JsonNode eachshid = shids.get(ii);
					Integer shid = null;
					if (eachshid.get("shid") != null)
						shid = eachshid.get("shid").asInt();
					Integer qid = null;
					if (eachshid.get("qid") != null)
						qid = eachshid.get("qid").asInt();
					if (shid != null && qid != null) {
						ConnectorEstimationMapping connectorMapping = new ConnectorEstimationMapping();
						connectorMapping.setConnectorId(connectorId);
						connectorMapping.setHid(hid);
						connectorMapping.setShid(shid);
						connectorMapping.setQid(qid);
						connectorMapping.setPds(pds);
						connectorMapping.setMessage(description);
						// delete and then insert in
						// connectorEstimationMappingService
						connectorEstimationMappingService
								.saveEntity(connectorMapping);
					}
				}
				Double temp_devShare_pds = 0.0;
				Double temp_qaShare_pds = 0.0;
				Double temp_devShare_sps = 0.0;
				Double temp_qaShare_sps = 0.0;
				EffortsEstimationMaster efforts = findEffortsByHid(
						findEffortsByVersionAndType, hid);
				StoryPointsEstimationMaster storyPoints = findStoryPointsByHid(
						findStoryPointsByVersionAndType, hid);
				if (type != null && type.equals("INPUT")) {
					dev_share_pds += (pds * efforts.getDevShare()) / 100;
					qa_share_pds += (pds * efforts.getQaShare()) / 100;
				} else {
					if (complex == 0) {
						temp_devShare_pds = (efforts.getTiny() * efforts
								.getDevShare()) / 100;
						temp_qaShare_pds = (efforts.getTiny() * efforts
								.getQaShare()) / 100;
						temp_devShare_sps = (storyPoints.getTiny() * efforts
								.getDevShare()) / 100;
						temp_qaShare_sps = (storyPoints.getTiny() * efforts
								.getQaShare()) / 100;
					} else if (complex == 1) {
						temp_devShare_pds = (efforts.getSimple() * efforts
								.getDevShare()) / 100;
						temp_qaShare_pds = (efforts.getSimple() * efforts
								.getQaShare()) / 100;
						temp_devShare_sps = (storyPoints.getSimple() * efforts
								.getDevShare()) / 100;
						temp_qaShare_sps = (storyPoints.getSimple() * efforts
								.getQaShare()) / 100;
					} else if (complex == 2) {
						temp_devShare_pds = (efforts.getMedium() * efforts
								.getDevShare()) / 100;
						temp_qaShare_pds = (efforts.getMedium() * efforts
								.getQaShare()) / 100;
						temp_devShare_sps = (storyPoints.getMedium() * efforts
								.getDevShare()) / 100;
						temp_qaShare_sps = (storyPoints.getMedium() * efforts
								.getQaShare()) / 100;
					} else if (complex == 3) {
						temp_devShare_pds = (efforts.getComplex() * efforts
								.getDevShare()) / 100;
						temp_qaShare_pds = (efforts.getComplex() * efforts
								.getQaShare()) / 100;
						temp_devShare_sps = (storyPoints.getComplex() * efforts
								.getDevShare()) / 100;
						temp_qaShare_sps = (storyPoints.getComplex() * efforts
								.getQaShare()) / 100;
					}
					dev_share_pds += temp_devShare_pds;
					qa_share_pds += temp_qaShare_pds;
					dev_share_sps += temp_devShare_sps;
					qa_share_sps += temp_qaShare_sps;
				}
				ConnectorComplexity connectorComplexity = new ConnectorComplexity();
				connectorComplexity.setComplexity(temp_devShare_sps
						+ temp_qaShare_sps);
				connectorComplexity.setPds(temp_devShare_pds
						+ temp_qaShare_pds);
				connectorComplexity.sethId(hid);
				connectorComplexity.setConnectorId(connectorId);
				connectorComplexityService.saveEntity(connectorComplexity);	
			}
			Double deduction = null;
			if (connectorType.equals("Outbound"))
				deduction = new Double(masterServiceImpl
						.findUniqueRecordByName("outbound_deduction")
						.getValue());
			else if (connectorType.equals("Polling"))
				deduction = new Double(masterServiceImpl
						.findUniqueRecordByName("polling_deduction").getValue());
			else
				deduction = new Double(masterServiceImpl
						.findUniqueRecordByName("webhooks_deduction")
						.getValue());
			Double total_pds_internal = dev_share_pds
					- (dev_share_pds * deduction);
			String category_internal = null;
			if (total_pds_internal > 0 && total_pds_internal < 31) {
				category_internal = "X-Small";
			} else if (total_pds_internal > 31 && total_pds_internal < 61) {
				category_internal = "Small";
			} else if (total_pds_internal > 61 && total_pds_internal < 101) {
				category_internal = "Medium";
			} else if (total_pds_internal > 101 && total_pds_internal < 141) {
				category_internal = "Large";
			} else if (total_pds_internal > 141 && total_pds_internal <= 180) {
				category_internal = "X-Large";
			}

			String category_external = null;
			if (dev_share_pds > 0 && dev_share_pds < 31) {
				category_external = "X-Small";
			} else if (dev_share_pds > 31 && dev_share_pds < 61) {
				category_external = "Small";
			} else if (dev_share_pds > 61 && dev_share_pds < 101) {
				category_external = "Medium";
			} else if (dev_share_pds > 101 && dev_share_pds < 141) {
				category_external = "Large";
			} else if (dev_share_pds > 141 && dev_share_pds <= 180) {
				category_external = "X-Large";
			}

			connector.setCategory(category_internal);
			connector.setStoryPoints(new Double(dev_share_sps).intValue());
			connector.setStoryPointsQa(new Double(qa_share_sps).intValue());
			connector.setEstimatedPds(new BigDecimal(dev_share_pds
					- (dev_share_pds * deduction)).setScale(0,
					BigDecimal.ROUND_HALF_UP).doubleValue());
			connector.setCategoryExternal(category_external);
			connector.setEstimatedPdsExternal(new BigDecimal(dev_share_pds)
					.setScale(0, BigDecimal.ROUND_HALF_UP).doubleValue());
			connector.setEstimatedPdsQa(new BigDecimal(qa_share_pds
					- (qa_share_pds * deduction)).setScale(0,
					BigDecimal.ROUND_HALF_UP).doubleValue());
			connector.setEstimatedPdsExternalQa(new BigDecimal(qa_share_pds)
					.setScale(0, BigDecimal.ROUND_HALF_UP).doubleValue());
			service.updateConnector(connector);
			/*
			 * List<Connector> findAllByConnectorParentId =
			 * service.findAllByConnectorParentId(parentId); boolean closeMaster
			 * = true; for (Connector c : findAllByConnectorParentId) { if
			 * (c.getCategory() == null) { closeMaster = false; } } if
			 * (closeMaster) { ConnectorMaster master =
			 * (ConnectorMaster)connectorMasterService.findById(parentId);
			 * master.setConnectorStatus(new Integer(0));
			 * connectorMasterService.updateEntity(master); }
			 */
			return "{\"message\": \"Estimation for " + connector.getName()
					+ " inserted successfully\"}";
		} else {
			return "{\"message\": \"Failure\"}";
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/estimationHeaderQuestionConnector/{connectorId}" }, method = RequestMethod.GET, produces = "application/json")
	public String getEstimationHeaderQuestionConnector(
			@PathVariable Integer connectorId) throws Exception {
		List<EstimationHeaderQuestionConnector> findEstimationHeaderQuestionConnectorByConnectorId = connectorEstimationMappingService
				.findEstimationHeaderQuestionConnectorByConnectorId(connectorId);
		StringBuffer buffer = new StringBuffer();
		buffer.append("{\"data\": [");
		for (EstimationHeaderQuestionConnector eachHeaderQuestion : findEstimationHeaderQuestionConnectorByConnectorId) {
			buffer.append("[");
			buffer.append("\"" + eachHeaderQuestion.getHid() + "\",");
			buffer.append("\"" + eachHeaderQuestion.getHeader() + "\",");
			buffer.append("\"" + eachHeaderQuestion.getDescription() + "\",");
			buffer.append("\"" + eachHeaderQuestion.getOptionSelected() + "\"");
			buffer.append("],");
		}
		if (!findEstimationHeaderQuestionConnectorByConnectorId.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]}");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/estimationHeaderQuestionConnectorByType/{connectorId}/{connectorType}" }, method = RequestMethod.GET, produces = "application/json")
	public String getEstimationHeaderQuestionConnectorByType(
			@PathVariable("connectorId") Integer connectorId,
			@PathVariable("connectorType") String connectorType)
			throws Exception {
		List<EstimationHeaderQuestionConnector> findEstimationHeaderQuestionConnectorByConnectorIdAndType = connectorEstimationMappingService
				.findEstimationHeaderQuestionConnectorByConnectorIdAndType(
						connectorId, connectorType);
		StringBuffer buffer = new StringBuffer();
		buffer.append("{\"data\": [");
		for (EstimationHeaderQuestionConnector eachHeaderQuestion : findEstimationHeaderQuestionConnectorByConnectorIdAndType) {
			buffer.append("[");
			buffer.append("\"" + eachHeaderQuestion.getHid() + "\",");
			buffer.append("\"" + eachHeaderQuestion.getHeader() + "\",");
			buffer.append("\"" + eachHeaderQuestion.getDescription() + "\",");
			buffer.append("\"" + eachHeaderQuestion.getOptionSelected() + "\",");
			buffer.append("\"" + eachHeaderQuestion.getPds() + "\"");
			buffer.append("],");

		}
		if (!findEstimationHeaderQuestionConnectorByConnectorIdAndType
				.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]}");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/saveEstimationReport" }, method = RequestMethod.POST, produces = "application/json")
	public void saveEstimationReport(HttpServletRequest request)
			throws Exception {
		String json = request.getParameter("json");
		int connectorId = 0;
		int connectorTypeInt = 0;
		if (json != null) {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode actualObj = mapper.readTree(json);
			Integer connectorMasterId = actualObj.get("connector_master_id")
					.asInt();
			String status = actualObj.get("status").asText();
			String remark = actualObj.get("remark").asText();
			String connectorType = actualObj.get("connector_type").asText();
			if (connectorType.equalsIgnoreCase("Outbound")) {
				connectorTypeInt = 1;
			} else if (connectorType.equalsIgnoreCase("Polling")) {
				connectorTypeInt = 2;
			} else {
				connectorTypeInt = 3;
			}

			List<Connector> listOFConnector = service
					.findAllByConnectorParentId(connectorMasterId);
			for (Connector c : listOFConnector) {
				if (c.getConnectorType() == connectorTypeInt) {
					connectorId = c.getId();
				}
			}
			java.sql.Date date = new java.sql.Date(Calendar.getInstance()
					.getTime().getTime());

			EstimationReport estimationReport = new EstimationReport();
			estimationReport.setConnector_id(connectorId);
			estimationReport.setStatus(status);
			estimationReport.setRemark(remark);
			estimationReport.setCreatedDate(date);
			estimationReportService.saveEntity(estimationReport);
			connectorEstimationMappingService.deleteByConnectorId(connectorId);
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/getConnectorByMasterIdAndType/{connectorMasterId}/{connectorType}" }, method = RequestMethod.GET, produces = "application/json")
	public String getConnectorByMasterId(
			@PathVariable("connectorMasterId") Integer connectorMasterId,
			@PathVariable("connectorType") String connectorType)
			throws Exception {
		int connectorTypeInt = 0;
		double totalPds;
		if (connectorType.equalsIgnoreCase("Outbound")) {
			connectorTypeInt = 1;
		} else if (connectorType.equalsIgnoreCase("Polling")) {
			connectorTypeInt = 2;
		} else {
			connectorTypeInt = 3;
		}

		List<Connector> listOFConnector = service
				.findAllByConnectorParentId(connectorMasterId);
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (Connector c : listOFConnector) {
			if (c.getConnectorType() == connectorTypeInt) {
				if (c.getEstimatedPds() != null && c.getEstimatedPdsQa() != null) 
					totalPds = c.getEstimatedPds() + c.getEstimatedPdsQa();
				else 
					totalPds = 0;
				buffer.append("{");
				buffer.append("\"category\":\"" + c.getCategory() + "\",");
				buffer.append("\"totalPds\":" + totalPds);
				buffer.append("},");
			}
		}
		if (!listOFConnector.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");
		return buffer.toString();
	}

	private EffortsEstimationMaster findEffortsByHid(
			List<EffortsEstimationMaster> findEffortsByVersionAndType,
			Integer hid) {
		EffortsEstimationMaster efforts = null;
		for (EffortsEstimationMaster eachEfforts : findEffortsByVersionAndType) {
			if (eachEfforts.getHid().equals(hid)) {
				efforts = eachEfforts;
				break;
			}
		}
		return efforts;
	}

	private StoryPointsEstimationMaster findStoryPointsByHid(
			List<StoryPointsEstimationMaster> findStoryPointsByVersionAndType,
			Integer hid) {
		StoryPointsEstimationMaster storyPoint = null;
		for (StoryPointsEstimationMaster eachStoryPoints : findStoryPointsByVersionAndType) {
			if (eachStoryPoints.getHid().equals(hid)) {
				storyPoint = eachStoryPoints;
				break;
			}
		}
		return storyPoint;
	}

}