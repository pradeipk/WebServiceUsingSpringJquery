package com.psl.sprint.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.psl.sprint.exception.MultipleRecordExists;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.FunctionalRequrement;
import com.psl.sprint.model.MatrixDTO;
import com.psl.sprint.model.RequirementDTO;
import com.psl.sprint.model.Subtask;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.FRService;
import com.psl.sprint.service.SubTaskService;

@Controller
@RequestMapping("/fr")
public class FRController extends AbstractController {

	@Autowired
	FRService service;
	@Autowired
	ConnectorService connectorService;

	@Autowired
	SubTaskService taskService;

	@Autowired
	MessageSource messageSource;

	@RequestMapping(value = { "/{connectorName}/new" }, method = RequestMethod.POST)
	public String saveFR(RequirementDTO requirementDTO, ModelMap model, @PathVariable String connectorName, RedirectAttributes attributes)
			throws Exception {
		try {
			Connector connector = new Connector();
			connector.setName(connectorName);
			connectorService.updateConnector(connector, requirementDTO);
			attributes.addFlashAttribute("success", "Requirement Added:" + requirementDTO.getRequirementName());
			return "redirect:/fr/Cassandra/new";

		}catch (MultipleRecordExists e) {
			attributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/fr/Cassandra/new";
		} catch (Exception e) {
			model.addAttribute("success", e.getMessage());
			return "success";
		}
	}

	@RequestMapping(value = { "/{connector}/new" }, method = RequestMethod.GET)
	public String getFR(@PathVariable String connector, ModelMap model) throws Exception {

		MatrixDTO matrix = null;

		List<MatrixDTO> matirxsDTOs = new ArrayList<MatrixDTO>();
		List<Subtask> subTasks = taskService.findAllSubtask();

		for (Subtask task : subTasks) {
			matrix = new MatrixDTO();
			matrix.setTaskName(task.getSubtask());
			matrix.setTask_id(task.getTaskId());
			matirxsDTOs.add(matrix);
		}

		RequirementDTO dto = new RequirementDTO();
		dto.setMatrix(matirxsDTOs);
		model.addAttribute("matirxs", dto);
		model.addAttribute("featuresImpacted", featuresImpacted);
		model.addAttribute("complexity", complexity);
		model.addAttribute("tasks", subTasks);
		model.addAttribute("resource_assigned", resource_assigned);
		model.addAttribute("edit", false);
		return "create_fr";
	}

	@RequestMapping(value = { "/list" }, method = RequestMethod.GET)
	public String getAllFR(ModelMap model) throws Exception {

		List<FunctionalRequrement> requirement = service.findAllFirstRequrement();
		model.addAttribute("requirement", requirement);
		model.addAttribute("edit", false);
		return "view_fr";
	}
	
	@RequestMapping(value = { "/edit/{requirementId}" }, method = RequestMethod.POST)
	public String modifyFR(RequirementDTO requirementDTO, ModelMap model, @PathVariable Integer requirementId, RedirectAttributes attributes)
			throws Exception {
		try {
			
			service.updateFirstRequrement(requirementDTO);
			attributes.addFlashAttribute("success", "Requirement Updated:" + requirementDTO.getRequirementName());
			return "redirect:/fr/Cassandra/new";

		}catch (MultipleRecordExists e) {
			attributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/fr/Cassandra/new";
		} catch (Exception e) {
			model.addAttribute("success", e.getMessage());
			return "success";
		}
	}
	
	@RequestMapping(value = { "/edit/{requirementId}" }, method = RequestMethod.GET)
	public String editFR( @PathVariable Integer requirementId,ModelMap model) throws Exception {
		try {
			
		
		FunctionalRequrement requirement = service.findById(requirementId);	
		List<MatrixDTO> matirxs = service.findAllTasksForARequirement(requirementId);
		RequirementDTO dto = new RequirementDTO();
		dto.setRequirementId(requirementId);
		dto.setRequirementName(requirement.getRequirement());
		dto.setRequirementId(requirement.getId());
		requirement.getConnector().getName();
		String temp  = requirement.getUniqueId().replace(requirement.getConnector().getName(), "");
		dto.setUniqueName(temp);
		dto.setMatrix(matirxs);
		model.addAttribute("matirxs", dto);
		model.addAttribute("featuresImpacted", featuresImpacted);
		model.addAttribute("complexity", complexity);
		model.addAttribute("tasks", taskService.findAllSubtask());
		model.addAttribute("resource_assigned", resource_assigned);
		model.addAttribute("edit", true);
		return "create_fr";
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
