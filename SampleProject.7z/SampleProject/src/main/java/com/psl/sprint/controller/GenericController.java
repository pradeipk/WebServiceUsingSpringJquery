package com.psl.sprint.controller;

public interface GenericController {
	
	
}
