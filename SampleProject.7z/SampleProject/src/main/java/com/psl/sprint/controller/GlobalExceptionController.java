package com.psl.sprint.controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.psl.sprint.exception.MandatoryFieldMissingException;

@ControllerAdvice
public class GlobalExceptionController {

	@ExceptionHandler(value=MandatoryFieldMissingException.class)
	public ModelAndView handleCustomException(MandatoryFieldMissingException ex) {

		ModelAndView model = new ModelAndView("error/generic_error");
	//	model.addObject("errCode", ex.getErrCode());
		//model.addObject("errMsg", ex.getErrMsg());

		return model;

	}

	/*@ExceptionHandler(value=Exception.class)
	public ModelAndView handleAllException(Exception ex) {

		ModelAndView model = new ModelAndView("error/generic_error");
		model.addObject("errMsg", "this is Exception.class");

		return model;

	}*/
	
	@ExceptionHandler(value=Exception.class)
	public String handleAllException(Exception ex , ModelMap map) {
		map.addAttribute("error", "Oops something went wrong,please try after some time.");		
		return "oops";
	}
	
}