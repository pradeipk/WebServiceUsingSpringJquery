package com.psl.sprint.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.psl.sprint.model.ConnectorIssue;
import com.psl.sprint.model.IssueTracker;
import com.psl.sprint.model.IssueTrackerJiraMapping;
import com.psl.sprint.service.ConnectorIssueService;
import com.psl.sprint.service.ConnectorMasterService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.IssueTrackerJiraMappingService;
import com.psl.sprint.service.IssueTrackerService;
import com.psl.sprint.service.UserService;

@Controller
@RequestMapping("/issue")
public class IssueController extends AbstractController {
	@Autowired
	private UserService userService;

	@Autowired
	private ConnectorService connectorService;

	@Autowired
	private ConnectorMasterService connectorMasterService;

	@Autowired
	private IssueTrackerService issueTrackerService;

	@Autowired
	private ConnectorIssueService connectorIssueService;

	@Autowired
	private IssueTrackerJiraMappingService issueTrackerJiraMappingService;


	@RequestMapping(value = { "/issue/{id}" }, method = RequestMethod.GET)
	public String findIssue(@PathVariable Integer id) {
		return null;
	}

	@RequestMapping(value = { "/createIssue" }, method = RequestMethod.POST)
	public String saveIssue(
			@ModelAttribute("issue") IssueTracker issueTracker, ModelMap model,
			HttpServletRequest request) throws Exception {
		boolean hasError = false;
		if (issueTracker.getIssueTitle() == null || issueTracker.getIssueTitle().isEmpty()) {
			model.addAttribute("issueTitle_error", "Issue Title required");
			hasError = true;
		} 

		if (issueTracker.getIssueReason() == null) {
			model.addAttribute("issueReason_error", "Select Issue Reason");
			hasError = true;
		}

		if (issueTracker.getGitIssueDate() == null) {
			model.addAttribute("gitIssueDate_error", "Select GIT Issue Date");
			hasError = true;
		}

		if (issueTracker.getStatus() == null) {
			model.addAttribute("issueStatus_error", "Select Issue Status");
			hasError = true;
		}

		if (issueTracker.getGitIssueLink() == null || issueTracker.getGitIssueLink().isEmpty()) {
			model.addAttribute("gitIssueLink_error", "GIT Issue Link required");
			hasError = true;
		}
		if (issueTracker.getEffortEstimation() == null && issueTracker.getIssueReason()==1) {
			model.addAttribute("effortEstimationError", "Effort Estimation required");
			hasError = true;
		}

		if (hasError) {
			model.addAttribute("issue", issueTracker);
			return "create_issue";
		} 
		else{		
			issueTracker.setStartDate(new LocalDate());
			issueTrackerService.saveIssue(issueTracker);
			model.addAttribute("issue", issueTracker);
			return "create_issue";
			//return "redirect:/issue/getIssueList/" + ((issueTracker.getIssueReason() == 0)? true:false);
		}
	}

	@RequestMapping(value = { "/createIssue" }, method = RequestMethod.GET)
	public String getIssues(ModelMap model) {
		IssueTracker issueTracker = new IssueTracker();
		model.addAttribute("issueStatus", ISSUE_STATUS);
		model.addAttribute("issue", issueTracker);
		return "create_issue";
	}

	@RequestMapping(value = { "/getIssueSelect" }, method = RequestMethod.GET)
	public String getIssueSelect(ModelMap model) {
		return "view_issues_select";
	}

	@RequestMapping(value = { "/getIssueList/{edit}" }, method = RequestMethod.GET)
	public String getIssuesList(@PathVariable Boolean edit, HttpServletRequest request, ModelMap model)
			throws Exception {
		Map<String, Object> filter = new HashMap<String, Object>();
		//Previous code
		if (!edit) {			
			//Enhancements
			filter.put("issueReason", 1);
		}
		if (edit) {			
			//Rework
			filter.put("issueReason", 0);
		}
		filter.put("status", request.getParameter("issueStatus"));

		List<IssueTracker> issueTracker = issueTrackerService.findAllIssues(filter);
		model.addAttribute("issuetracker", issueTracker);
		return "view_issues";
	}

	@RequestMapping(value = { "/updateIssue/{issueID}" }, method = RequestMethod.GET)
	public String updateGetIssue(@PathVariable Integer issueID, ModelMap model)
			throws Exception {
		IssueTracker itracker = issueTrackerService.findById(issueID);
		model.addAttribute("issue", itracker);
		model.addAttribute("issueStatus", ISSUE_STATUS);
		return "update_issue";
	}

	@RequestMapping(value = { "/updateIssue/{issueID}" }, method = RequestMethod.POST)
	public String updatePostIssue(
			@ModelAttribute("issue") IssueTracker issueTracker, ModelMap model,
			HttpServletRequest request) throws Exception {

		boolean hasError = false;
		if (issueTracker.getIssueTitle() == null || issueTracker.getIssueTitle().isEmpty()) {
			model.addAttribute("issueTitle_error", "Issue Title required");
			hasError = true;
		} 

		if (issueTracker.getIssueReason()== null) {
			model.addAttribute("issueReason_error", "Select Issue Reason");
			hasError = true;
		}

		if (issueTracker.getGitIssueDate() == null) {
			model.addAttribute("gitIssueDate_error", "Select GIT Issue Date");
			hasError = true;
		}

		if (issueTracker.getGitIssueLink() == null || issueTracker.getGitIssueLink().isEmpty()) {
			model.addAttribute("gitIssueLink_error", "GIT Issue Link required");
			hasError = true;
		}

		if (hasError) {
			model.addAttribute("issue", issueTracker);
			return "update_issue";
		} 
		else{		
			issueTrackerService.updateIssue(issueTracker);			
			return "redirect:/issue/getIssueList/" + ((issueTracker.getIssueReason() == 0)? true:false);
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/assignConnector" }, method = RequestMethod.GET, produces = "application/json")
	public String assignConnector(HttpServletRequest request) throws Exception {
		String response = "";
		if (request.getParameter("connectorIds") != null && request.getParameter("issueId") != null) {
			String connectorIds[] = request.getParameter("connectorIds").split(",");
			Integer issueId = Integer.parseInt(request.getParameter("issueId"));
			for (String eachConnectorId : connectorIds) {
				ConnectorIssue connectorIssue = new ConnectorIssue();
				connectorIssue.setConnectorId(Integer.parseInt(eachConnectorId));
				connectorIssue.setIssueId(issueId);
				connectorIssueService.saveConnector(connectorIssue);
			}
			response = "{ \"message\" : \"Issue mapped to connector successfully.\", \"status\":1 }";

		} else {
			response = "{ \"message\" : \"Unable to map issue.\", \"status\":0 }";
		}
		return response;
	}

	@RequestMapping(value = { "/viewMapIssueToJira" }, method = RequestMethod.GET)
	public String viewMapIssueToJira(ModelMap model) {
		return "map_issue_to_jira";
	}

	@ResponseBody
	@RequestMapping(value = { "/mapIssueToJira" }, method = RequestMethod.GET,produces="application/json")
	public String mapIssueToJira(HttpServletRequest request,ModelMap model) throws Exception{
		StringBuffer buffer = new StringBuffer();
		Map<String, Object> filter = new HashMap<String, Object>();
		filter.put("issueReason", 2);
		filter.put("status", request.getParameter("issueStatus"));
		List<IssueTracker> issueTrackerList = issueTrackerService.findAllIssues(filter);
		List<IssueTrackerJiraMapping> mappingList=issueTrackerJiraMappingService.findAll();
		buffer.append("[");
		if(mappingList.isEmpty()){
			if(!issueTrackerList.isEmpty()){
				for (IssueTracker issueTrackerObj : issueTrackerList) {
					buffer.append("{");
					buffer.append("\"title\":\"" + issueTrackerObj.getIssueTitle()
							+ "\",");
					buffer.append("\"id\":" + issueTrackerObj.getIssueID());
					buffer.append("},");
				}

			}
		}
		else{

			HashMap<Integer, String> map=new HashMap<Integer, String>();

			if(!issueTrackerList.isEmpty()){
				for (IssueTracker issueTrackerObj : issueTrackerList) {
					 boolean unique = true;
					for(IssueTrackerJiraMapping issueTrackerJiraMapping:mappingList){
						if(issueTrackerJiraMapping.getIssuetracker_id()==issueTrackerObj.getIssueID()){
							unique = false;
				            break;
							

						}
					}
					 if(unique){
						 map.put(issueTrackerObj.getIssueID(), issueTrackerObj.getIssueTitle());
				}
			}
				for(Integer issueId:map.keySet()){
					buffer.append("{");
					buffer.append("\"title\":\"" + map.get(issueId)
							+ "\",");
					buffer.append("\"id\":" + issueId);
					buffer.append("},");
				}
			

		}
		}
		if (!issueTrackerList.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");

		return buffer.toString();
	}
	@ResponseBody
	@RequestMapping(value = { "/saveIssueTrackerJiraMapping" }, method = RequestMethod.POST)
	public void saveIssueTrackerJiraMapping(HttpServletRequest request) throws Exception{
		String json = request.getParameter("json");
		if (json != null ) {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode actualObj = mapper.readTree(json);
			Integer issueTrackerId=actualObj.get("issuetracker_id").asInt();
			String jiraLink=actualObj.get("jira_link").asText();
			IssueTrackerJiraMapping issueTrackerJiraMapping=new IssueTrackerJiraMapping();
			issueTrackerJiraMapping.setIssuetracker_id(issueTrackerId);
			issueTrackerJiraMapping.setJira_link(jiraLink);
			issueTrackerJiraMappingService.saveIssueTrackerJiraMapping(issueTrackerJiraMapping);

		}

	}

}