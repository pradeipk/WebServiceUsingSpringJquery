package com.psl.sprint.controller;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.psl.sprint.dto.ReportDTO;
import com.psl.sprint.model.SprintSummary;
import com.psl.sprint.model.TaskEffortsByConnector;
import com.psl.sprint.model.TemporaryResults;
import com.psl.sprint.service.ConnectorBugService;
import com.psl.sprint.service.ConnectorMasterService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.LeaveService;
import com.psl.sprint.service.MasterService;
import com.psl.sprint.service.NotesService;
import com.psl.sprint.service.ResourceAllocationReportService;
import com.psl.sprint.service.SprintItemService;
import com.psl.sprint.service.TaskService;
import com.psl.sprint.service.UserService;
import com.psl.sprint.util.GeneralUtility;

@Controller
@RequestMapping("/metrics")
public class PMetricsController extends AbstractController {

	@Autowired
	private ConnectorService service;

	@Autowired
	private ConnectorMasterService connMasterService;

	@Autowired
	private ResourceAllocationReportService allocationReportService;

	@Autowired
	private UserService userService;

	@Autowired
	MessageSource messageSource;

	@Autowired
	private MasterService masterService;

	@Autowired
	private ResourceAllocationReportService reportService;

	@Autowired
	private TaskService taskService;

	@Autowired
	private ConnectorBugService connectorBugService;

	@Autowired
	private NotesService notesService;

	@Autowired
	private LeaveService leaveService;

	@Autowired
	private ConnectorMasterService connectorMasterService;

	@Autowired
	private SprintItemService sprintItemService;

	@RequestMapping(value = { "/report" }, method = RequestMethod.GET)
	public String getResourceAllocationReport(Model model) {
		model.addAttribute("ReportDTO", new ReportDTO());
		return "metrics_report";
	}

	@ResponseBody
	@RequestMapping(value = { "/getQAProd" }, method = RequestMethod.GET, produces = "application/json")
	public String getEffortsByDateAndOrConnector(HttpServletRequest request)
			throws Exception {
		String comparisonType = request.getParameter("comparisonType");
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		String monthYear = request.getParameter("monthYear");
		String phaseName = request.getParameter("phaseName");// "TcCreation";
																// //TcExecution,TcCreation
		// startDate="2016-12-01";
		// endDate="2016-12-31";

		List<TaskEffortsByConnector> effortsForPhaseByConnector = taskService
				.getEffortsByDateAndPhase(startDate, endDate, phaseName,
						monthYear, comparisonType);

		Double pdsConsumed = 0.00;
		Integer tcs = 0;

		for (TaskEffortsByConnector taskResourceConnector : effortsForPhaseByConnector) {
			Double pds = taskResourceConnector.getNoOfHours();
			if (pds != null)
				pdsConsumed += (pds / 8);
			if (phaseName.equalsIgnoreCase("TcExecution"))
				tcs += taskResourceConnector.getTcsExecuted();
			if (phaseName.equalsIgnoreCase("TcCreation"))
				tcs += taskResourceConnector.getTcsCreated();
		}
		if (startDate == null)
			startDate = "NA";
		if (endDate == null)
			endDate = "NA";
		if (monthYear == null)
			monthYear = "NA";

		pdsConsumed = new BigDecimal(pdsConsumed).setScale(1,
				BigDecimal.ROUND_HALF_UP).doubleValue();

		StringBuffer buffer = new StringBuffer();
		buffer.append("{\"data\": [");
		buffer.append("[");
		buffer.append("\"" + startDate + "\",");
		buffer.append("\"" + endDate + "\",");
		buffer.append("\"" + monthYear + "\",");
		buffer.append("\"" + pdsConsumed + "\",");
		buffer.append("\"" + tcs + "\",");
		buffer.append("\"" + (int) (tcs / pdsConsumed) + "\"");
		buffer.append("]");
		buffer.append("]}");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getConnectorStoryPointsSprintWise" }, method = RequestMethod.GET, produces = "application/json")
	public String getConnectorStoryPointsSprintWise(HttpServletRequest request)
			throws Exception {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		String startDate = null;
		String endDate = null;
		if (request.getParameter("comparisonType") != null) {
			if (request.getParameter("comparisonType").equals("MONTH")) {
				String monthYear = request.getParameter("monthYear");
				String[] monthYearArray = monthYear.split("-");
				startDate = monthYear + "-01";
				endDate = GeneralUtility.getLastDayOfMonth(
						Integer.parseInt(monthYearArray[1]),
						Integer.parseInt(monthYearArray[0]));
			} else {
				startDate = request.getParameter("startDate");
				endDate = request.getParameter("endDate");
			}
			if (startDate != null && endDate != null) {
				List<SprintSummary> connectorStoryPointsSprintWise = sprintItemService
						.getConnectorStoryPointsSprintWise(startDate, endDate);
				String connectorName = "";
				for (int i = 0; i < connectorStoryPointsSprintWise.size(); i++) {
					SprintSummary summary = connectorStoryPointsSprintWise
							.get(i);
					if (!connectorName.equals(summary.getConnectorName())) {
						connectorName = summary.getConnectorName();
						buffer.append("{");
						buffer.append("\"connector_name\" : \""
								+ summary.getConnectorName() + "\",");
					}
					Double pds = 0d;
					List<TemporaryResults> findByStartDateAndEndDate = allocationReportService
							.findByStartDateAndEndDate(summary.getStartDate()
									.toString(), summary.getEndDate()
									.toString(), summary.getConnectorName());
					for (TemporaryResults result : findByStartDateAndEndDate) {
						pds += result.getAdjust_day();
					}
					summary.setEfforts(pds);
					System.out.println("Sprint No: " + summary.getSprintNo());
					if (summary.getSprintNo() != null) {
						buffer.append("\"sprint_" + summary.getSprintNo()
								+ "\" : {");
						buffer.append("\"sprint_no\" : "
								+ summary.getSprintNo() + ",");
					} else {
						buffer.append("\"sprint_"
								+ summary.getStartDate().toString()
										.substring(8) + "\" : {");
						buffer.append("\"sprint_no\" : \""
								+ summary.getStartDate().toString()
										.substring(8) + "\"" + ",");
					}
					buffer.append("\"story_points\" : "
							+ summary.getStoryPoints() + ",");
					LocalDate start_Date = new LocalDate(summary.getStartDate());
					LocalDate end_Date = new LocalDate(summary.getEndDate());
					LocalDate tempDate = start_Date;
					int daysCount = 0;
					int daysDifference = Days.daysBetween(start_Date, end_Date)
							.getDays() + 1;
					for (int ii = 0; ii <= daysDifference; ii++) {
						if (!(tempDate.getDayOfWeek() == 6 || tempDate
								.getDayOfWeek() == 7)) {
							if (!leaveService.isPublicLeave(tempDate)) {
								daysCount++;
							}
						}
						tempDate = tempDate.plusDays(1);
					}
					buffer.append("\"total_days\" : " + daysCount + ",");

					if (summary.getEfforts() != null)
						buffer.append("\"efforts\" : "
								+ new BigDecimal(summary.getEfforts())
										.setScale(2, BigDecimal.ROUND_HALF_UP)
										.doubleValue());
					else
						buffer.append("\"efforts\" : 0");
					buffer.append("},");
					if ((i + 1) < connectorStoryPointsSprintWise.size()
							&& !connectorName
									.equals(connectorStoryPointsSprintWise.get(
											i + 1).getConnectorName())) {
						buffer.deleteCharAt(buffer.length() - 1);
						buffer.append("},");
					}
				}
				if (!connectorStoryPointsSprintWise.isEmpty()) {
					buffer.deleteCharAt(buffer.length() - 1);
					buffer.append("}");
				}
			}
		}
		buffer.append("]");
		System.out.println(buffer.toString());
		return buffer.toString();
	}
}