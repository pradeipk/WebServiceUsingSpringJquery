package com.psl.sprint.controller;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.model.EstimationHeaderConnector;
import com.psl.sprint.model.SprintItem;
import com.psl.sprint.model.SprintItemStatus;
import com.psl.sprint.model.SprintMaster;
import com.psl.sprint.model.SprintSummary;
import com.psl.sprint.service.ConnectorEstimationMappingService;
import com.psl.sprint.service.ConnectorMasterService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.EffortsEstimationMasterService;
import com.psl.sprint.service.EstimationHeadersService;
import com.psl.sprint.service.EstimationSubHeadersService;
import com.psl.sprint.service.MasterService;
import com.psl.sprint.service.QuestionsService;
import com.psl.sprint.service.SprintItemService;
import com.psl.sprint.service.SprintItemStatusService;
import com.psl.sprint.service.SprintMasterService;
import com.psl.sprint.service.StoryPointsEstimationMasterService;

@Controller
@RequestMapping("/sprint")
public class SprintController extends AbstractController {

	@Autowired
	private EstimationHeadersService estimationHeadersService;

	@Autowired
	private EstimationSubHeadersService estimationSubHeadersService;

	@Autowired
	private QuestionsService questionsService;

	@Autowired
	private MasterService masterServiceImpl;

	@Autowired
	private EffortsEstimationMasterService effortsEstimationMasterService;

	@Autowired
	private StoryPointsEstimationMasterService storyPointsEstimationMasterService;

	@Autowired
	private ConnectorService service;

	@Autowired
	private ConnectorEstimationMappingService connectorEstimationMappingService;

	@Autowired
	private ConnectorMasterService connectorMasterService;

	@Autowired
	private SprintMasterService sprintMasterService;

	@Autowired
	private SprintItemService sprintItemService;
	
	@Autowired
	private SprintItemStatusService sprintItemStatusService;


	@RequestMapping(value = { "/main" }, method = RequestMethod.GET)
	public String getMainPage(ModelMap model) {
		return "connector_sprint";
	}

	@ResponseBody
	@RequestMapping(value = { "/getConnectorMaster" }, method = RequestMethod.GET, produces = "application/json")
	public String getConnectorMaster(ModelMap model) throws Exception {
		List<ConnectorMaster> findAll = (List<ConnectorMaster>) connectorMasterService
				.findAll();
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (ConnectorMaster connectorMaster : findAll) {
			buffer.append("{");
			buffer.append("\"name\":\"" + connectorMaster.getConnectorName()
					+ "\",");
			buffer.append("\"id\":" + connectorMaster.getId());
			buffer.append("},");
		}
		if (!findAll.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/findEstimationHeaderConnectorByConnectorIdAndType/{connectorParentId}" }, method = RequestMethod.GET, produces = "application/json")
	public String findEstimationHeaderConnectorByConnectorIdAndType(
			@PathVariable Integer connectorParentId) throws Exception {
		StringBuffer buffer = new StringBuffer();
		buffer.append("{");
		List<SprintMaster> findByConnectorMasterId = sprintMasterService
				.findByConnectorMasterId(connectorParentId);
		buffer.append("\"persisted\": {");
		if (!findByConnectorMasterId.isEmpty()) {
			for (SprintMaster eachSprint : findByConnectorMasterId) {
				buffer.append("\"" + eachSprint.getSprintNo()
						+ "_start_date\": \"" + eachSprint.getStartDate()
						+ "\",");
				buffer.append("\"" + eachSprint.getSprintNo()
						+ "_end_date\": \"" + eachSprint.getEndDate() + "\",");
				buffer.append("\"" + eachSprint.getSprintNo()
						+ "_sprint_id\": " + eachSprint.getId() + ",");
				buffer.append("\"" + eachSprint.getSprintNo() + "\": {");
				List<SprintItem> findBySprintMasterId = sprintItemService
						.findBySprintMasterId(eachSprint.getId());
				for (SprintItem eachSprintItem : findBySprintMasterId) {
					buffer.append("\"" + eachSprintItem.gethId() + "\": {");
					buffer.append("\"sprint_item_id\": "
							+ eachSprintItem.getId() + ",");
					buffer.append("\"comment\": \""
							+ ((eachSprintItem.getComment() == null)? "" : eachSprintItem.getComment())  + "\",");
					buffer.append("\"input\": \""
							+ eachSprintItem.getPercentageCompletion() + "\"");
					buffer.append("},");
				}
				if (!findBySprintMasterId.isEmpty()) {
					buffer.deleteCharAt(buffer.length() - 1);
				}
				buffer.append("},");
			}
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("}, ");

		List<Connector> findAllByConnectorParentId = service
				.findAllByConnectorParentId(connectorParentId);
		buffer.append("\"master\" : [");
		for (Connector connector : findAllByConnectorParentId) {
			buffer.append("{");
			buffer.append("\"name\":\"" + connector.getName() + "\", ");
			buffer.append("\"connector_id\":" + connector.getId() + ", ");
			String connectorType = null;
			if (connector.getConnectorType() == 1)
				connectorType = "Outbound";
			else if (connector.getConnectorType() == 2)
				connectorType = "Polling";
			else
				connectorType = "Webhooks";
			buffer.append("\"connectorType\":\"" + connectorType + "\", ");
			List<EstimationHeaderConnector> findEstimationHeaderConnectorByConnectorIdAndType = connectorEstimationMappingService
					.findEstimationHeaderConnectorByConnectorIdAndType(
							connector.getId(), connectorType);
			buffer.append("\"headers\" : [");
			if (!findEstimationHeaderConnectorByConnectorIdAndType.isEmpty()) {
				for (EstimationHeaderConnector eachEstimationHeader : findEstimationHeaderConnectorByConnectorIdAndType) {
					buffer.append("{");
					buffer.append("\"hid\":" + eachEstimationHeader.getHid()
							+ ", ");
					buffer.append("\"header\":\""
							+ eachEstimationHeader.getHeader() + "\"");
					buffer.append("},");
				}
				buffer.deleteCharAt(buffer.length() - 1);
			}
			buffer.append("]");
			buffer.append("},");
		}
		if (!findAllByConnectorParentId.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");
		buffer.append("}");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/saveSprint" }, method = RequestMethod.POST, produces = "application/json")
	public String saveSprint(HttpServletRequest request, ModelMap model)
			throws Exception {
		Map<String, String> params = new ConcurrentHashMap<String, String>();
		for (Enumeration<String> parameterNames = request.getParameterNames(); parameterNames
				.hasMoreElements();) {
			String key = parameterNames.nextElement();
			params.put(key, request.getParameter(key));
		}
		Map<String, Object> parsedParams = groupRequest(params);
		SprintMaster sprintMaster = new SprintMaster();
		sprintMaster.setConnectorMasterId(Integer
				.parseInt((String) parsedParams.get("parent_id")));
		LocalDate startDate = new LocalDate(
				(String) parsedParams.get("start_date"));
		sprintMaster.setStartDate(startDate);
		LocalDate endDate = new LocalDate((String) parsedParams.get("end_date"));
		sprintMaster.setEndDate(endDate);
		sprintMaster.setSprintNo(Integer.parseInt((String) parsedParams
				.get("sprint")));
		List<Map<String, String>> sprint_items = (List<Map<String, String>>) parsedParams
				.get("sprint_items");
		boolean canInsert = true;
		List<Object> listSprintItems = new ArrayList<Object>();
		for (Map<String, String> eachMap : sprint_items) {
			SprintItem sprintItem = new SprintItem();
			for (Map.Entry<String, String> entry : eachMap.entrySet()) {
				String key = entry.getKey();
				if (key.equals("comment"))
					sprintItem.setComment(eachMap.get(key));
				else if (key.equals("connector_id"))
					sprintItem
							.setConnectorId(Integer.parseInt(eachMap.get(key)));
				else if (key.equals("input"))
					sprintItem.setPercentageCompletion(Double.parseDouble(eachMap
							.get(key)));
				else if (key.equals("hid"))
					sprintItem.sethId(Integer.parseInt(eachMap.get(key)));

			}
			Double totalPercentageCompletionByConnectorIdAndHid = sprintItemService
					.getTotalPercentageCompletionByConnectorIdAndHid(
							sprintItem.getConnectorId(), sprintItem.gethId());
			if (totalPercentageCompletionByConnectorIdAndHid != null) {
				if ((totalPercentageCompletionByConnectorIdAndHid + sprintItem
						.getPercentageCompletion()) > 100) {
					canInsert = false;
					listSprintItems.add("hid_" + sprintItem.gethId()
							+ "=Please check other sprint for this connector");
				} else {
					listSprintItems.add(sprintItem);
				}
			} else {
				listSprintItems.add(sprintItem);
			}
		}
		if (canInsert) {
			sprintMasterService.saveEntity(sprintMaster);
			if (sprintMaster.getId() != null) {
				for (Object eachItem : listSprintItems) {
					if (eachItem instanceof SprintItem) {
						SprintItem tempSprintItem = (SprintItem) eachItem;
						tempSprintItem.setSprintId(sprintMaster.getId());
						sprintItemService.saveEntity(tempSprintItem);
					}
				}
			}
			return "{\"message\": \"Sprint saved / updated successfully.\", \"status\": true}";
		} else {
			StringBuffer buffer = new StringBuffer();
			buffer.append("{\"status\": false,");
			buffer.append("\"error\": {");
			for (Object eachItem : listSprintItems) {
				if (eachItem instanceof String) {
					String[] item = ((String) eachItem).split("=");
					buffer.append("\"" + item[0] + "\": \"" + item[1] + "\",");
				}
			}
			if (!listSprintItems.isEmpty())
				buffer.deleteCharAt(buffer.length() - 1);
			buffer.append("}");
			buffer.append("}");
			return buffer.toString();
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/updateSprint/{sprintId}" }, method = RequestMethod.POST, produces = "application/json")
	public String updateSprint(@PathVariable Integer sprintId,
			HttpServletRequest request, ModelMap model) throws Exception {
		Map<String, String> params = new ConcurrentHashMap<String, String>();
		for (Enumeration<String> parameterNames = request.getParameterNames(); parameterNames
				.hasMoreElements();) {
			String key = parameterNames.nextElement();
			params.put(key, request.getParameter(key));
		}
		Map<String, Object> parsedParams = groupRequest(params);
		SprintMaster sprintMaster = (SprintMaster) sprintMasterService
				.findById(sprintId);
		LocalDate startDate = new LocalDate(
				(String) parsedParams.get("start_date"));
		sprintMaster.setStartDate(startDate);
		LocalDate endDate = new LocalDate((String) parsedParams.get("end_date"));
		sprintMaster.setEndDate(endDate);
		List<Map<String, String>> sprint_items = (List<Map<String, String>>) parsedParams
				.get("sprint_items");
		boolean canInsert = true;
		List<Object> listSprintItems = new ArrayList<Object>();
		List<SprintItem> deleteIds = new ArrayList<SprintItem>();
		for (Map<String, String> eachMap : sprint_items) {
			SprintItem sprintItem = new SprintItem();
			for (Map.Entry<String, String> entry : eachMap.entrySet()) {
				String key = entry.getKey();
				if (key.equals("comment"))
					sprintItem.setComment(eachMap.get(key));
				else if (key.equals("connector_id"))
					sprintItem
							.setConnectorId(Integer.parseInt(eachMap.get(key)));
				else if (key.equals("input"))
					sprintItem.setPercentageCompletion(Double.parseDouble(eachMap
							.get(key)));
				else if (key.equals("hid"))
					sprintItem.sethId(Integer.parseInt(eachMap.get(key)));
				else if (key.equals("sprint_item_id")) {
					sprintItem.setId(Integer.parseInt(eachMap.get(key)));
				}
			}
			if (sprintItem.getId() != null) {
				SprintItem tempSprintItem = (SprintItem) sprintItemService
						.findById(sprintItem.getId());
				Double totalPercentageCompletionByConnectorIdAndHid = sprintItemService
						.getTotalPercentageCompletionByConnectorIdAndHid(
								sprintItem.getConnectorId(),
								sprintItem.gethId());
				if (totalPercentageCompletionByConnectorIdAndHid != null) {
					totalPercentageCompletionByConnectorIdAndHid = totalPercentageCompletionByConnectorIdAndHid
							- tempSprintItem.getPercentageCompletion();
					if (sprintItem.getPercentageCompletion() == null && sprintItem.getId() != null) {
						deleteIds.add(sprintItem);
					} else if ((totalPercentageCompletionByConnectorIdAndHid + sprintItem
							.getPercentageCompletion()) > 100) {
						canInsert = false;
						listSprintItems
								.add("hid_"
										+ sprintItem.gethId()
										+ "=Please check other sprint for this connector");
					} else {
						listSprintItems.add(sprintItem);
					}
				}
			} else {
				listSprintItems.add(sprintItem);
			}
		}
		if (canInsert) {
			sprintMasterService.updateEntity(sprintMaster);
			if (sprintMaster.getId() != null) {
				for (Object eachItem : listSprintItems) {
					if (eachItem instanceof SprintItem) {
						SprintItem tempSprintItems = (SprintItem) eachItem;
						tempSprintItems.setSprintId(sprintMaster.getId());
						if (tempSprintItems.getId() == null)
							sprintItemService.saveEntity(tempSprintItems);
						else
							sprintItemService.updateEntity(tempSprintItems);
					}
				}
				for (SprintItem tempItem : deleteIds) {
					sprintItemService.deleteEntity(tempItem);
				}
			}
			return "{\"message\": \"Sprint saved / updated successfully.\", \"status\": true}";
		} else {
			StringBuffer buffer = new StringBuffer();
			buffer.append("{\"status\": false,");
			buffer.append("\"error\": {");
			for (Object eachItem : listSprintItems) {
				if (eachItem instanceof String) {
					String[] item = ((String) eachItem).split("=");
					buffer.append("\"" + item[0] + "\": \"" + item[1] + "\",");
				}
			}
			if (!listSprintItems.isEmpty())
				buffer.deleteCharAt(buffer.length() - 1);
			buffer.append("}");
			buffer.append("}");
			return buffer.toString();
		}
	}

	private boolean listSprintItemsExists(SprintItem tempItem,
			List<Object> listSprintItems) {
		boolean returnValue = false;
		for (Object o : listSprintItems) {
			if (o instanceof SprintItem) {
				SprintItem si = (SprintItem)o;
				if (si.getId() == tempItem.getId()) {
					returnValue = true;
					break;
				}
			}
		}
		return returnValue;
	}

	@ResponseBody
	@RequestMapping(value = { "/getSprintSummary/{connectorMasterId}" }, method = RequestMethod.GET, produces = "application/json")
	public String getSprintSummary(@PathVariable Integer connectorMasterId)
			throws Exception {
		List<Connector> findAllByConnectorParentId = service
				.findAllByConnectorParentId(connectorMasterId);
		Integer[] connectorIds = new Integer[findAllByConnectorParentId.size()];
		for (int i = 0; i < findAllByConnectorParentId.size(); i++) {
			connectorIds[i] = findAllByConnectorParentId.get(i).getId();
		}
		List<SprintSummary> sprintSummary = sprintItemService
				.getSprintSummary(connectorIds);
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (SprintSummary eachSprintSummary : sprintSummary) {
			buffer.append("{");
			buffer.append("\"id\":" + eachSprintSummary.getId() + ", ");
			buffer.append("\"connector_id\":"
					+ eachSprintSummary.getConnectorId() + ", ");
			buffer.append("\"connector_name\": \""
					+ eachSprintSummary.getConnectorName() + "\", ");
			buffer.append("\"connector_type\":"
					+ eachSprintSummary.getConnectorType() + ", ");
			buffer.append("\"hid\":" + eachSprintSummary.getHid() + ", ");
			buffer.append("\"sprint_no\":" + eachSprintSummary.getSprintNo()
					+ ", ");
			buffer.append("\"header\": \""
					+ eachSprintSummary.getSDLCPhaseTask() + "\", ");
			buffer.append("\"start_date\": \""
					+ eachSprintSummary.getStartDate() + "\", ");
			buffer.append("\"end_date\": \"" + eachSprintSummary.getEndDate()
					+ "\", ");
			buffer.append("\"percentage_completion\": "
					+ eachSprintSummary.getPercentageCompletion() + ", ");
			buffer.append("\"storypoints\": "
					+ eachSprintSummary.getStoryPoints() + ", ");
			SprintItemStatus sprintItemStatus = sprintItemStatusService.findBySprintItemId(eachSprintSummary.getId());
			String status = "";
			if (sprintItemStatus != null && sprintItemStatus.getStatus() != null) {
				status = sprintItemStatus.getStatus();
			}
			buffer.append("\"status\": \"" + status + "\"");
			buffer.append("},");
		}
		if (!sprintSummary.isEmpty())
			buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/changeStatus" }, method = RequestMethod.POST, produces = "application/json")
	public String changeStatus(HttpServletRequest request, ModelMap model)
			throws Exception {
		Integer id = Integer.parseInt(request.getParameter("id"));
		String status = request.getParameter("status");
		SprintItemStatus sprintItemStatus = sprintItemStatusService.findBySprintItemId(id);
		if (sprintItemStatus == null) {
			sprintItemStatus = new SprintItemStatus();
			sprintItemStatus.setSprintItemDate(new LocalDate());
			sprintItemStatus.setSprintItemId(id);
			sprintItemStatus.setStatus(status);
			sprintItemStatusService.saveEntity(sprintItemStatus);
			return "{ \"message\": \"Status saved successfully\"}";
		} else {
			sprintItemStatus.setSprintItemDate(new LocalDate());
			sprintItemStatus.setStatus(status);
			sprintItemStatusService.updateEntity(sprintItemStatus);
			return "{ \"message\": \"Status updated successfully\"}";
		}
	}

	private Map<String, Object> groupRequest(Map<String, String> params)
			throws Exception {
		Integer connectorParentId = new Integer(params.get("parent_id"));
		Integer sprintNo = new Integer(params.get("sprint"));
		Map<String, Object> parsedParams = new ConcurrentHashMap<String, Object>();
		parsedParams.put("parent_id", Integer.toString(connectorParentId));
		parsedParams.put("sprint", Integer.toString(sprintNo));
		List<Map<String, String>> sprint_items = new ArrayList<Map<String, String>>();
		parsedParams.put("sprint_items", sprint_items);
		getTopLevelData(params, parsedParams);
		List<Connector> findAllByConnectorParentId = service
				.findAllByConnectorParentId(connectorParentId);
		for (Connector connector : findAllByConnectorParentId) {
			String connectorType = null;
			if (connector.getConnectorType() == 1)
				connectorType = "Outbound";
			else if (connector.getConnectorType() == 2)
				connectorType = "Polling";
			else
				connectorType = "Webhooks";
			List<EstimationHeaderConnector> findEstimationHeaderConnectorByConnectorIdAndType = connectorEstimationMappingService
					.findEstimationHeaderConnectorByConnectorIdAndType(
							connector.getId(), connectorType);
			for (EstimationHeaderConnector eachEstimationHeader : findEstimationHeaderConnectorByConnectorIdAndType) {
				Map<String, String> tempItems = getSprintItems(sprint_items,
						eachEstimationHeader.getHid(), connector.getId(),
						params, (String) parsedParams.get("sprint"));
				if (tempItems.size() > 0)
					sprint_items.add(tempItems);
			}
		}
		return parsedParams;
	}

	private Map<String, String> getSprintItems(
			List<Map<String, String>> sprint_items, Integer hid,
			Integer connector_id, Map<String, String> params, String sprintNo) {
		Map<String, String> items = new ConcurrentHashMap<String, String>();
		for (Map.Entry<String, String> entry : params.entrySet()) {
			String key = entry.getKey();
			if (key.equals(sprintNo + "_" + connector_id + "_input_" + hid)) {
				items.put("connector_id", Integer.toString(connector_id));
				items.put("hid", Integer.toString(hid));
				items.put("input", params.get(key));
			} else if (key.equals(sprintNo + "_" + connector_id + "_comment_"
					+ hid)) {
				items.put("connector_id", Integer.toString(connector_id));
				items.put("hid", Integer.toString(hid));
				items.put("comment", params.get(key));
			} else if (key.startsWith(sprintNo + "_" + connector_id
					+ "_sprint_item_" + hid + "_")) {
				items.put("sprint_item_id", params.get(key));
				items.put("hid", Integer.toString(hid));
				items.put("connector_id", Integer.toString(connector_id));
			}
		}
		return items;
	}

	private void getTopLevelData(Map<String, String> params,
			Map<String, Object> parsedParams) {
		for (Map.Entry<String, String> entry : params.entrySet()) {
			String key = entry.getKey();
			if (key.endsWith("start")) {
				parsedParams.put("start_date", params.get(key));
			}
			if (key.endsWith("end")) {
				parsedParams.put("end_date", params.get(key));
			}
		}
	}

}