package com.psl.sprint.controller;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.psl.sprint.configuration.SprintConfiguration;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorLeadMapping;
import com.psl.sprint.model.EstimationHeaderConnector;
import com.psl.sprint.model.EstimationHeaders;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.SprintItem;
import com.psl.sprint.model.SprintItemStatus;
import com.psl.sprint.model.SprintMaster;
import com.psl.sprint.model.SprintSummary;
import com.psl.sprint.model.TemporaryResults;
import com.psl.sprint.service.ConnectorEstimationMappingService;
import com.psl.sprint.service.ConnectorLeadMappingService;
import com.psl.sprint.service.ConnectorMasterService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.EffortsEstimationMasterService;
import com.psl.sprint.service.EstimationHeadersService;
import com.psl.sprint.service.EstimationSubHeadersService;
import com.psl.sprint.service.LeaveService;
import com.psl.sprint.service.MasterService;
import com.psl.sprint.service.QuestionsService;
import com.psl.sprint.service.ResourceAllocationReportService;
import com.psl.sprint.service.SprintItemService;
import com.psl.sprint.service.SprintItemStatusService;
import com.psl.sprint.service.SprintMasterService;
import com.psl.sprint.service.StoryPointsEstimationMasterService;
import com.psl.sprint.service.UserService;

@Controller
@RequestMapping("/sprintNew")
public class SprintControllerNew extends AbstractController {

	@Autowired
	private EstimationHeadersService estimationHeadersService;

	@Autowired
	private EstimationSubHeadersService estimationSubHeadersService;

	@Autowired
	private QuestionsService questionsService;

	@Autowired
	private MasterService masterServiceImpl;

	@Autowired
	private EffortsEstimationMasterService effortsEstimationMasterService;

	@Autowired
	private StoryPointsEstimationMasterService storyPointsEstimationMasterService;

	@Autowired
	private ConnectorService service;

	@Autowired
	private ConnectorEstimationMappingService connectorEstimationMappingService;

	@Autowired
	private ConnectorMasterService connectorMasterService;

	@Autowired
	private SprintMasterService sprintMasterService;

	@Autowired
	private SprintItemService sprintItemService;

	@Autowired
	private SprintItemStatusService sprintItemStatusService;

	@Autowired
	private LeaveService leaveService;

	@Autowired
	private ConnectorLeadMappingService connectorLeadMappingService;

	@Autowired
	private SprintConfiguration sprintConfiguration;

	@Autowired
	private UserService userService;
	@Autowired
	private ResourceAllocationReportService resourceAllocationReportService;

	@RequestMapping(value = { "/main" }, method = RequestMethod.GET)
	public String getMainPage(ModelMap model) {
		// return "connector_sprint_new";
		return "connector_sprint_new";
	}

	@ResponseBody
	@RequestMapping(value = { "/getCurrentSprintForUser" }, method = RequestMethod.GET, produces = "application/json")
	public String getCurrentSprintForUser(HttpServletRequest request,
			ModelMap model) throws Exception {
		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");
		if (activeUserData == null) {
			return "{\"reload\":1}";
		}
		if (activeUserData.getJobAssigned().equalsIgnoreCase("others")) {
			return getCurrentSprintForOtherResource();
		} else if (activeUserData.getJobAssigned().equalsIgnoreCase("Lead_QA")
				|| activeUserData.getJobAssigned().equalsIgnoreCase("Dual_QA")) {
			return getCurrentSprintForQaResource(activeUserData);
		} else if (activeUserData.getJobAssigned().equalsIgnoreCase("Lead_DEV")
				|| activeUserData.getJobAssigned().equalsIgnoreCase("Dual_DEV")) {
			return getCurrentSprintForDevResource(activeUserData);
		} else {
			return "[ ]";
		}

	}

	@ResponseBody
	@RequestMapping(value = { "/getAllEstimatedConnectorForUser" }, method = RequestMethod.GET, produces = "application/json")
	public String getAllEstimatedConnectorForUser(HttpServletRequest request,
			ModelMap model) throws Exception {

		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");

		List<ConnectorLeadMapping> connectorLeadMappings = getValidRecourcesForSprint(activeUserData);
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		if (connectorLeadMappings != null && connectorLeadMappings.size() > 0) {
			for (ConnectorLeadMapping connectorLeadMapping : connectorLeadMappings) {
				buffer.append("{");
				buffer.append("\"name\":\""
						+ connectorLeadMapping.getConnector().getName() + "\",");
				buffer.append("\"leadId\":\"" + connectorLeadMapping.getId()
						+ "\",");
				buffer.append("\"id\":"
						+ connectorLeadMapping.getConnector().getId());
				buffer.append("},");
			}
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]");

		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/findEstimationHeaderConnectorByUserAndType/{connectorLeadId}/{sprintId}" }, method = RequestMethod.GET, produces = "application/json")
	public String findEstimationHeaderConnectorByUserAndType(
			HttpServletRequest request, @PathVariable Integer connectorLeadId,
			@PathVariable Integer sprintId) throws Exception {
		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");
		String userName = activeUserData.getFirstName().toUpperCase();

		ConnectorLeadMapping connectorLeadMapping = connectorLeadMappingService
				.findById(connectorLeadId);
		Connector connector = connectorLeadMapping.getConnector();
		int defaultHid = 0;
		String connectorType = null;
		if (connector.getConnectorType() == 1) {
			connectorType = "Outbound";
			defaultHid = 2;
		} else if (connector.getConnectorType() == 2) {
			connectorType = "Polling";
			defaultHid = 27;
		} else {
			connectorType = "Webhooks";
			defaultHid = 38;
		}

		List<EstimationHeaderConnector> findEstimationHeaderConnectorByConnectorIdAndType = connectorEstimationMappingService
				.findEstimationHeaderConnectorByConnectorIdAndType(
						connector.getId(), connectorType);

		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		buffer.append("{");
		buffer.append("\"headers\" : [");
		if (findEstimationHeaderConnectorByConnectorIdAndType != null
				&& findEstimationHeaderConnectorByConnectorIdAndType.size() > 0
				&& !findEstimationHeaderConnectorByConnectorIdAndType.isEmpty()) {

			for (EstimationHeaderConnector eachEstimationHeader : findEstimationHeaderConnectorByConnectorIdAndType) {

				List<SprintItem> extingheaderdata = sprintItemService
						.findByConnectorIdAndHidByOwner(connector.getId(),
								eachEstimationHeader.getHid(), sprintId);
				if (!(extingheaderdata != null && extingheaderdata.size() > 0)) {
					buffer.append("{");
					buffer.append("\"hid\":" + eachEstimationHeader.getHid()
							+ ", ");
					buffer.append("\"header\":\""
							+ eachEstimationHeader.getHeader() + "\"");
					buffer.append("},");
				}
			}
			buffer.deleteCharAt(buffer.length() - 1);

		} else {
			if (connector.getInitialPds() <= 20) {
				EstimationHeaders estimationHeader = (EstimationHeaders) estimationHeadersService
						.findById(defaultHid);
				buffer.append("{");
				buffer.append("\"hid\":" + estimationHeader.getId() + ", ");
				buffer.append("\"header\":\""
						+ estimationHeader.getSDLCPhaseTask() + "\"");
				buffer.append("}");
			}

		}
		buffer.append("]");
		buffer.append("}");
		buffer.append("]");

		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/findsprintItem/{connectorId}/{hid}" }, method = RequestMethod.GET, produces = "application/json")
	public String findsprintItem(HttpServletRequest request,
			@PathVariable Integer connectorId, @PathVariable Integer hid)
			throws Exception {
		StringBuffer buffer = new StringBuffer();

		List<SprintItem> comments = sprintItemService.findByConnectorIdAndHid(
				connectorId, hid);
		String comment = " No comment found";
		for (SprintItem commen : comments) {
			if (commen.getComment() != null) {
				comment += commen.getComment() + "  ";
			}
		}

		buffer.append("[");
		buffer.append("{");
		buffer.append("\"comment\":" + "\"" + comment + "\"" + ", ");
		Double percentage = 0.0;
		Double totalPercentageCompletionByConnectorIdAndHid = sprintItemService
				.getTotalPercentageCompletionByConnectorIdAndHid(connectorId,
						hid);
		if (totalPercentageCompletionByConnectorIdAndHid != null) {
			percentage = totalPercentageCompletionByConnectorIdAndHid;
		}
		buffer.append("\"percentage\":" + percentage// " \"\" "
		);
		buffer.append("}");
		buffer.append("]");
		return buffer.toString();

	}

	@ResponseBody
	@RequestMapping(value = { "/saveSprint" }, method = RequestMethod.POST, produces = "application/json")
	public String saveSprint(HttpServletRequest request, ModelMap model)
			throws Exception {
		boolean saved = false;
		Map<String, String> params = new ConcurrentHashMap<String, String>();
		for (Enumeration<String> parameterNames = request.getParameterNames(); parameterNames
				.hasMoreElements();) {
			String key = parameterNames.nextElement();
			params.put(key, request.getParameter(key));
		}
		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");
		String userName = activeUserData.getFirstName().toUpperCase();
		Integer connectorMasterId = Integer.parseInt(params.get("parent_id"));
		Integer sprintMasterId = CreateSprintMasterRecord(params, userName,
				connectorMasterId, activeUserData);

		List<ConnectorLeadMapping> connectorLeadMappings = connectorLeadMappingService
				.findByConnectorIdAndUser(connectorMasterId,
						activeUserData.getResourceId());
		ConnectorLeadMapping connectorLeadMapping = null;
		if (connectorLeadMappings != null && connectorLeadMappings.size() > 0) {
			connectorLeadMapping = connectorLeadMappings.get(0);
		}
		int totalleft = 0;
		Double totpercentage = 0.0;

		String comments = params.get("commentsBox");
		String percentage = params.get("newpercentage");
		String hidString = params.get("choosedHeaders");
		int hid = Integer.parseInt(hidString.trim());
		Double percent = 0.0;
		if (percentage != null) {
			percent = Double.parseDouble(percentage.trim());
		}

		if (sprintMasterId != null) {

			createSprintItems(comments, hid, percent, connectorMasterId,
					sprintMasterId, connectorLeadMapping, activeUserData);

			saved = true;
		}
		Double totalPercentageCompletionByConnectorIdAndHid = sprintItemService
				.getTotalPercentageCompletionByConnectorIdAndHid(
						connectorMasterId, hid);
		if (totalPercentageCompletionByConnectorIdAndHid != null) {
			totpercentage = totalPercentageCompletionByConnectorIdAndHid;
		}

		totalleft = (int) (100 - (totpercentage));

		if (saved) {

			return "{ \"totpercentageold\":"
					+ totpercentage
					+ ",  \"totalpercentleft\":"
					+ totalleft
					+ ",    \"message\": \"Sprint saved successfully.\", \"status\": true}";
		} else {
			StringBuffer buffer = new StringBuffer();
			buffer.append("{\"status\": false,");
			buffer.append("\"totpercentageold\":"
					+ totpercentage
					+ ",  \"totalpercentleft\":"
					+ totalleft
					+ ", \"error\": {\"message\": \"Sprint  Could Not Saved Please Verify Inputs.\", \"status\": false}");

			buffer.append("}");
			return buffer.toString();
		}

	}

	@ResponseBody
	@RequestMapping(value = { "/updatesprint" }, method = RequestMethod.POST, produces = "application/json")
	public String updatesprint(HttpServletRequest request, ModelMap model)
			throws Exception {

		Map<String, String> params = new ConcurrentHashMap<String, String>();
		for (Enumeration<String> parameterNames = request.getParameterNames(); parameterNames
				.hasMoreElements();) {
			String key = parameterNames.nextElement();
			params.put(key, request.getParameter(key));
		}
		Integer connectorId = Integer.parseInt(params.get("connectorid"));
		Integer hid = Integer.parseInt(params.get("hid"));
		boolean saved = false;
		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");
		String userName = activeUserData.getFirstName().toUpperCase();
		String comments = params.get("comments");
		Double percentage = Double.parseDouble(params.get("percetage"));
		Integer sprintId = Integer.parseInt(params.get("idSprintId"));

		SprintItem sprintItems = sprintItemService.findBySprintidnadHid(
				sprintId, hid);
		if (sprintItems != null) {
			sprintItems.setComment(comments);
			double tempper = (sprintItems.getPercentageCompletion() + percentage);
			percentage = tempper;
			sprintItems.setPercentageCompletion(percentage);
			sprintItemService.updateEntity(sprintItems);
			saved = true;
		}
		Double totpercentage = 0.0;
		Double totalPercentageCompletionByConnectorIdAndHid = sprintItemService
				.getTotalPercentageCompletionByConnectorIdAndHid(connectorId,
						hid);
		if (totalPercentageCompletionByConnectorIdAndHid != null) {
			totpercentage = totalPercentageCompletionByConnectorIdAndHid;
		}
		int totalleft = (int) (100 - (totpercentage));
		if (saved) {
			return "{ \"totpercentageold\":"
					+ totpercentage
					+ ",  \"totalpercentleft\":"
					+ totalleft
					+ ",    \"message\": \"Sprint updated  successfully.\", \"status\": true}";

		} else {
			return "{ \"totpercentageold\":"
					+ totpercentage
					+ ",  \"totalpercentleft\":"
					+ totalleft
					+ ",    \"message\": \"Sprint  Could Not Updated, Please Verify Inputs.\", \"status\": false}";

		}

	}

	@ResponseBody
	@RequestMapping(value = { "/deleteSprint" }, method = RequestMethod.POST, produces = "application/json")
	public String deleteSprint(HttpServletRequest request, ModelMap model)
			throws Exception {

		Map<String, String> params = new ConcurrentHashMap<String, String>();
		for (Enumeration<String> parameterNames = request.getParameterNames(); parameterNames
				.hasMoreElements();) {
			String key = parameterNames.nextElement();
			params.put(key, request.getParameter(key));
		}

		Integer connectorId = Integer.parseInt(params.get("connectorid"));
		Integer hid = Integer.parseInt(params.get("hid"));
		Integer sprintId = Integer.parseInt(params.get("idSprintId"));

		boolean saved = false;
		List<SprintItem> sprintItems = sprintItemService
				.findByConnectorIdAndHidByOwner(connectorId, hid, sprintId);

		if (sprintItems != null) {
			sprintItemService.deleteEntity(sprintItems.get(0));
			saved = true;
		}

		if (saved) {

			return "{\"message\": \"Sprint Deleted  successfully.\", \"status\": true}";
		} else {
			return "{\"message\": \"Could not Delete Sprint .\", \"status\": false}";
		}

	}

	@ResponseBody
	@RequestMapping(value = { "/getAllSprint" }, method = RequestMethod.GET, produces = "application/json")
	public String getAllSprint(HttpServletRequest request) throws Exception {

		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");

		if (activeUserData.getJobAssigned().equalsIgnoreCase("others")) {
			return getSprintSummaryForOthers();
		} else if (activeUserData.getJobAssigned().equalsIgnoreCase("Lead_QA")
				|| activeUserData.getJobAssigned().equalsIgnoreCase("Dual_QA")) {
			return getSprintSummaryForQA(activeUserData.getResourceId());
		} else if (activeUserData.getJobAssigned().equalsIgnoreCase("Lead_DEV")
				|| activeUserData.getJobAssigned().equalsIgnoreCase("Dual_DEV")) {
			return getSprintSummaryForDev(activeUserData.getResourceId());
		} else {
			return "[ ]";
		}
	}

	public Map<String, Set<Integer>> getresourcesData(boolean isQA, Integer qaId)
			throws Exception {
		Map<String, Set<Integer>> dev_qa_ids = new HashMap<String, Set<Integer>>();
		List<ConnectorLeadMapping> allresources = connectorLeadMappingService
				.findMapping();
		Set<Integer> dev = new HashSet<Integer>();
		Set<Integer> qa = new HashSet<Integer>();
		if (!isQA) {
			for (ConnectorLeadMapping resource : allresources) {
				dev.add(resource.getDevResource().getResourceId());
				qa.add(resource.getQaResource().getResourceId());
			}
		} else {
			for (ConnectorLeadMapping resource : allresources) {
				if (resource.getQaResource().getResourceId() == qaId) {
					dev.add(resource.getDevResource().getResourceId());
					qa.add(resource.getQaResource().getResourceId());
				}

			}
		}
		dev_qa_ids.put("DEV", dev);
		dev_qa_ids.put("QA", qa);
		return dev_qa_ids;

	}

	public String getmasterDataForSummary(
			Map<String, List<SprintMaster>> allMasters, String userType)
			throws Exception {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (Map.Entry<String, List<SprintMaster>> userSprintData : allMasters
				.entrySet()) {

			List<SprintMaster> sprints = userSprintData.getValue();
			buffer.append("{");
			buffer.append("\"owner\":" + "\""
					+ sprints.get(0).getResource().getFirstName() + " "
					+ sprints.get(0).getResource().getLastName() + "\"" + ", ");
			buffer.append("\"userType\":" + "\"" + userType + "\"" + ", ");

			if (sprints != null && sprints.size() > 0) {
				buffer.append("\"sprints\":");
				buffer.append("[");
				for (SprintMaster sprintdates : sprints) {

					buffer.append("{");
					buffer.append("\"startDate\":" + "\""
							+ sprintdates.getStartDate() + "\"" + ", ");
					buffer.append("\"endDate\":" + "\""
							+ sprintdates.getEndDate() + "\"");
					buffer.append(",");
					/*
					 * buffer.append("\"startDate\":" + "\"" +
					 * sprintdates.getStartDate() + "\"" + ", ");
					 * buffer.append("\"createdby\":" + "\"" +
					 * sprintdates.getResource().getResourceId() + "\"" + ", ");
					 * buffer.append("\"owner\":" + "\"" +
					 * sprintdates.getResource().getFirstName() + " " +
					 * sprintdates.getResource().getLastName() + "\"" + ", ");
					 * buffer.append("\"Sprintid\":" + "\"" +
					 * sprintdates.getId() + "\"" + ", ");
					 * buffer.append("\"userType\":" + "\"" + userType + "\"" +
					 * ", "); buffer.append("\"endDate\":" + "\"" +
					 * sprintdates.getEndDate() + "\""); buffer.append("},");
					 */
					displaySummary(sprintdates, buffer);
					buffer.append("} ,");
				}
				buffer.deleteCharAt(buffer.length() - 1);
				buffer.append("]");
				buffer.append(",");
			}
			buffer.deleteCharAt(buffer.length() - 1);
			buffer.append("}");
			buffer.append(",");
		}
		buffer.deleteCharAt(buffer.length() - 1);
		// buffer.append("}");
		buffer.append("]");
		return buffer.toString();

	}

	public String getsprintSummaryrecords(Set<Integer> creadtedByids)
			throws Exception {

		// List<SprintMaster> allMasters = new LinkedList();
		Map<String, List<SprintMaster>> allMasters = new TreeMap<String, List<SprintMaster>>();

		for (Integer creadtedByid : creadtedByids) {
			List<SprintMaster> masters = getSprintMasterForUser(creadtedByid);
			if (masters != null && masters.size() > 0) {
				// allMasters.addAll(masters);
				allMasters.put(masters.get(0).getResource().getFirstName(),
						masters);
			}

		}

		return getmasterDataForSummary(allMasters, "Others");
	}

	public String getSprintSummaryForOthers() throws Exception {
		Map<String, Set<Integer>> dev_qa_ids = getresourcesData(false, null);
		Set<Integer> creadtedByids = dev_qa_ids.get("DEV");
		return getsprintSummaryrecords(creadtedByids);
	}

	public String getSprintSummaryForQA(Integer qaId) throws Exception {
		Map<String, Set<Integer>> dev_qa_ids = getresourcesData(true, qaId);
		Set<Integer> creadtedByids = dev_qa_ids.get("DEV");
		return getsprintSummaryrecords(creadtedByids);

	}

	public String getSprintSummaryForDev(Integer devId) throws Exception {
		List<ConnectorLeadMapping> allresources = connectorLeadMappingService
				.findMappingForRecource(devId, null, false, false);

		Set<Integer> creadtedByids = new HashSet<>();
		if (allresources != null && allresources.size() > 0) {
			for (ConnectorLeadMapping allresource : allresources) {
				creadtedByids.add(allresource.getDevResource().getResourceId());
			}
		}

		return getsprintSummaryrecords(creadtedByids);
	}

	public StringBuffer displaySummary(SprintMaster masters, StringBuffer buffer)
			throws Exception {
		// StringBuffer buffer = new StringBuffer();
		// buffer.append("[");
		// buffer.append("{");
		// buffer.append("\"startdate\":" + masters + ", ");
		buffer.append("\"summarys\" : [");
		List<SprintSummary> sprintSummary = sprintItemService
				.getSprintSummary(masters.getId());
		if (sprintSummary != null && sprintSummary.size() > 0) {

			for (SprintSummary eachSprintSummary : sprintSummary) {

				ConnectorLeadMapping connectorLeadMapping = connectorLeadMappingService
						.findById(eachSprintSummary.getLeadMapping());

				buffer.append("{");
				buffer.append("\"id\":" + eachSprintSummary.getId() + ", ");
				buffer.append("\"connector_id\":"
						+ eachSprintSummary.getConnectorId() + ", ");
				buffer.append("\"connector_name\": \""
						+ eachSprintSummary.getConnectorName() + "\", ");
				buffer.append("\"connector_type\":"
						+ eachSprintSummary.getConnectorType() + ", ");

				buffer.append("\"owner\":" + " \""
						+ connectorLeadMapping.getDevResource().getFirstName()
						+ "  ,  "
						+ connectorLeadMapping.getQaResource().getFirstName()
						+ "\" " + ", ");
				buffer.append("\"hid\":" + eachSprintSummary.getHid() + ", ");
				buffer.append("\"sprint_no\":"
						+ eachSprintSummary.getSprintNo() + ", ");
				buffer.append("\"header\": \""
						+ eachSprintSummary.getSDLCPhaseTask() + "\", ");
				buffer.append("\"start_date\": \""
						+ eachSprintSummary.getStartDate() + "\", ");
				buffer.append("\"end_date\": \""
						+ eachSprintSummary.getEndDate() + "\", ");
				buffer.append("\"percentage_completion\": "
						+ eachSprintSummary.getPercentageCompletion() + ", ");
				buffer.append("\"storypoints\": "
						+ eachSprintSummary.getStoryPoints() + ", ");
				SprintItemStatus sprintItemStatus = sprintItemStatusService
						.findBySprintItemId(eachSprintSummary.getId());
				String status = "";
				if (sprintItemStatus != null
						&& sprintItemStatus.getStatus() != null) {
					status = sprintItemStatus.getStatus();
				}
				buffer.append("\"status\": \"" + status + "\"");
				buffer.append("},");

			}
			buffer.deleteCharAt(buffer.length() - 1);

		}

		buffer.append("]");
		// buffer.append("}");
		// buffer.append("]");
		return buffer;
		// return buffer.toString();
	}

	public List<SprintMaster> getSprintMasterForUser(Integer creadedBy)
			throws Exception {

		int rowLimit = sprintConfiguration.getSprintSuymmaryDisplayCount();
		int isfrozen = 1;
		List<SprintMaster> userRecords = sprintMasterService
				.getMasterSprintsforUser(creadedBy, isfrozen, rowLimit);
		return userRecords;
	}

	public String getCurrentSprintForQaResource(Resource activeUserData)
			throws Exception {
		List<ConnectorLeadMapping> allDevData = getValidRecourcesForSprint(activeUserData);
		Set<Integer> devIds = new TreeSet<>();
		for (ConnectorLeadMapping DevData : allDevData) {
			devIds.add(DevData.getDevResource().getResourceId());
		}
		LinkedList<SprintMaster> nonFrozedSprints = new LinkedList<>();
		StringBuffer buffer = new StringBuffer();
		for (Integer devId : devIds) {
			List<SprintMaster> existingNonFrozenSprints = sprintMasterService
					.getExistingSprintsForUser(devId, 0);
			if (existingNonFrozenSprints != null
					&& existingNonFrozenSprints.size() > 0) {
				nonFrozedSprints.addAll(existingNonFrozenSprints);
			}
		}

		if (nonFrozedSprints != null && nonFrozedSprints.size() > 0) {
			return displaySprintOverUI(nonFrozedSprints);

		} else {
			return "[]";
		}
	}

	public String getCurrentSprintForDevResource(Resource activeUserData)
			throws Exception {
		int sprintcout = sprintConfiguration.getSprintDisplayCount();
		int leftSprintCount = 0;
		LinkedList<SprintMaster> nonFrozedSprints = new LinkedList<>();
		LocalDate newSprintEndDate = null;
		LocalDate newSprintStartDate = null;

		List<SprintMaster> existingNonFrozenSprints = sprintMasterService
				.getExistingSprintsForUser(activeUserData.getResourceId(), 0);
		if (existingNonFrozenSprints != null) {
			nonFrozedSprints.addAll(existingNonFrozenSprints);
		}

		if (nonFrozedSprints != null && nonFrozedSprints.size() > 0
				&& nonFrozedSprints.size() < sprintcout) {
			leftSprintCount = sprintcout - nonFrozedSprints.size();

			SprintMaster lastnonFrozenSprint = sprintMasterService
					.getLastSprintDateForUser(activeUserData.getResourceId(),
							0, true);
			if (lastnonFrozenSprint != null) {
				newSprintEndDate = lastnonFrozenSprint.getEndDate();
			} else {
				newSprintEndDate = new LocalDate()
						.minusDays(sprintConfiguration.getStartDay());
			}
			createLeftSprints(leftSprintCount, nonFrozedSprints,
					newSprintEndDate, activeUserData);

		}

		else {
			leftSprintCount = sprintcout - nonFrozedSprints.size();

			SprintMaster lastFrozenSprint = sprintMasterService
					.getLastSprintDateForUser(activeUserData.getResourceId(),
							1, true);
			if (lastFrozenSprint != null) {
				newSprintEndDate = lastFrozenSprint.getEndDate();
			} else {
				newSprintEndDate = new LocalDate()
						.minusDays(sprintConfiguration.getStartDay());
			}
			createLeftSprints(leftSprintCount, nonFrozedSprints,
					newSprintEndDate, activeUserData);

		}
		return displaySprintOverUI(nonFrozedSprints);

	}

	public String getCurrentSprintForOtherResource() {
		return "[]";
	}

	private String displaySprintOverUI(LinkedList<SprintMaster> nonFrozedSprints) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		for (SprintMaster nonFrozedSprint : nonFrozedSprints) {
			buffer.append("{");
			buffer.append("\"newSprintStartDate\":\""
					+ nonFrozedSprint.getStartDate() + "\",");
			buffer.append("\"newSprintEndDate\":\""
					+ nonFrozedSprint.getEndDate() + "\",");
			buffer.append("\"owner\":\""
					+ nonFrozedSprint.getResource().getFirstName() + " "
					+ nonFrozedSprint.getResource().getLastName() + "\",");

			buffer.append("\"id\":\"" + nonFrozedSprint.getId());
			buffer.append("\"},");

		}

		buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");

		return buffer.toString();

	}

	private void createLeftSprints(int leftSprintCount,
			LinkedList<SprintMaster> nonFrozedSprints,
			LocalDate newSprintEndDate, Resource activeUserData)
			throws Exception {
		LocalDate newSprintStartDate = null;
		for (int i = 0; i < leftSprintCount; i++) {
			newSprintStartDate = newSprintEndDate.plusDays(sprintConfiguration
					.getStartDay());
			newSprintEndDate = newSprintStartDate.plusDays(sprintConfiguration
					.getEndDay());
			SprintMaster sprintMaster = new SprintMaster();
			sprintMaster.setEndDate(newSprintEndDate);
			sprintMaster.setStartDate(newSprintStartDate);
			sprintMaster.setFreezed(0);
			sprintMaster.setResource(activeUserData);
			int sprintId = sprintMasterService
					.saveSprintMasterRecords(sprintMaster);
			sprintMaster.setId(sprintId);
			nonFrozedSprints.add(sprintMaster);

		}
	}

	private List<ConnectorLeadMapping> getValidRecourcesForSprint(
			Resource activeUserData) throws Exception {
		Boolean isQa = false;
		if ((activeUserData.getJobAssigned().equals("Lead_QA") || activeUserData
				.getJobAssigned().equals("Dual_QA"))) {
			isQa = true;
		}
		return connectorLeadMappingService.findMappingForRecource(
				activeUserData.getResourceId(),
				activeUserData.getJobAssigned(), false, isQa);
	}

	private java.lang.String getConnectorIdsForUser(
			List<ConnectorLeadMapping> connectorLeadMappings) {
		StringBuffer ids = new StringBuffer();

		for (ConnectorLeadMapping comMap : connectorLeadMappings) {
			ids.append(comMap.getId() + "  ,");
		}

		ids.deleteCharAt(ids.length() - 1);

		return ids.toString();
	}

	private List<Object[]> getRecoursedata(Resource activeUserData,
			List<ConnectorLeadMapping> connectorLeadMappings) throws Exception {

		// ids=getConnectorIdsForUser(connectorLeadMappings);

		List<Object[]> sprintIds = sprintMasterService
				.getSprintrecource(getConnectorIdsForUser(connectorLeadMappings));
		if (sprintIds != null && sprintIds.size() > 0) {
			return sprintIds;
		} else {
			return null;
		}

	}

	private Integer[] CreateAndCondition(Resource activeUserData)
			throws Exception {
		List<ConnectorLeadMapping> connectorLeadMappings = getValidRecourcesForSprint(activeUserData);
		if (connectorLeadMappings != null && connectorLeadMappings.size() > 0) {
			List<Object[]> recources = getRecoursedata(activeUserData,
					connectorLeadMappings);

			Integer ids[];
			if (recources != null) {
				ids = new Integer[recources.size()];

				int i = 0;
				for (Object[] sprintId : recources) {
					String id = sprintId[0].toString();
					if (id != null) {
						ids[i] = new Integer(id);
					}
					i++;

				}
				return ids;

			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/freezSprintByDate" }, method = RequestMethod.POST, produces = "application/json")
	public String freezSprintByDate(HttpServletRequest request, ModelMap model)
			throws Exception {

		Map<String, String> params = new ConcurrentHashMap<String, String>();
		for (Enumeration<String> parameterNames = request.getParameterNames(); parameterNames
				.hasMoreElements();) {
			String key = parameterNames.nextElement();
			params.put(key, request.getParameter(key));
		}

		Integer idSprintId = Integer.parseInt(params.get("idSprintId"));

		StringBuffer buffer = new StringBuffer();
		SprintMaster sprintMaster = (SprintMaster) sprintMasterService
				.findById(idSprintId);

		if (sprintMaster != null) {

			sprintMaster.setFreezed(new Integer(1));
			sprintMasterService.updateEntity(sprintMaster);
			// sprintMasterService.deleteMapping(sprintMaster.getId());

			return "{\"message\": \"Sprint  FreeZed successfully.\", \"status\": true}";
		} else {
			return "{\"message\": \" Sprint could not  FreeZed successfully.\", \"status\": false}";
		}
	}

	private Integer CreateSprintMasterRecord(Map<String, String> params,
			String userName, Integer connectorMasterId, Resource activeUserData)
			throws Exception {
		LocalDate startDate = new LocalDate(params.get("sprint_start"));
		LocalDate endDate = new LocalDate(params.get("sprint_endDate"));
		Integer freez = Integer.parseInt(params.get("freez"));
		Integer idSprintId = Integer.parseInt(params.get("idSprintId"));
		/*
		 * List<SprintMaster> sprintMastes = sprintMasterService
		 * .findByStartDateEndDateAndowner(startDate, endDate,
		 * CreateAndCondition(activeUserData));
		 */
		Integer sprintMasterId = null;
		SprintMaster sprintMaster = (SprintMaster) sprintMasterService
				.findById(idSprintId);
		if (sprintMaster == null) {
			sprintMaster = new SprintMaster();

			sprintMaster.setStartDate(startDate);
			sprintMaster.setEndDate(endDate);

			sprintMaster.setFreezed(new Integer(freez));
			sprintMasterId = sprintMasterService
					.saveSprintMasterRecords(sprintMaster);
		}

		return sprintMaster.getId();

	}

	private void createSprintItems(String comments, Integer hid,
			Double percent, Integer connectorMasterId, Integer sprintMasterId,
			ConnectorLeadMapping user, Resource activeuser) throws Exception {

		SprintItem sprintItem = new SprintItem();
		sprintItem.setComment(comments);
		sprintItem.setConnectorId(connectorMasterId);
		sprintItem.sethId(hid);
		sprintItem.setPercentageCompletion(percent);
		sprintItem.setResource(activeuser);
		sprintItem.setUser(user);
		sprintItem.setSprintId(sprintMasterId);
		sprintItemService.saveEntity(sprintItem);

	}

	@ResponseBody
	@RequestMapping(value = { "/CurrentSprintByDate/{startdate}/{enddate}/{idSprintId}" }, method = RequestMethod.GET, produces = "application/json")
	public String CurrentSprintByDate(HttpServletRequest request,
			@PathVariable String startdate, @PathVariable String enddate,
			@PathVariable String idSprintId) throws Exception {

		LocalDate startdatetemp = new LocalDate(startdate);

		LocalDate enddateTemp = new LocalDate(enddate);
		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");
		String userName = activeUserData.getFirstName().toUpperCase();
		StringBuffer buffer = new StringBuffer();

		Integer idSprintIds[] = new Integer[1];// declaration and instantiation
		idSprintIds[0] = new Integer(idSprintId);// initialization
		List<SprintMaster> sprintMastes = sprintMasterService
				.findByStartDateEndDateAndowner(startdatetemp, enddateTemp,
						idSprintIds);

		buffer.append("[");
		if (sprintMastes != null && sprintMastes.size() > 0) {
			for (SprintMaster sprintMaster : sprintMastes) {
				List<SprintItem> SprintItems = sprintItemService
						.findBySprintMasterId(sprintMaster.getId());
				for (SprintItem sprintItem : SprintItems) {
					buffer.append("{");
					buffer.append("\"masterId\":" + sprintMaster.getId()// " \"\" "
							+ ", ");
					EstimationHeaders headerinfo = (EstimationHeaders) (estimationHeadersService
							.findById(sprintItem.gethId()));
					Connector connectorInfo = service.findById(sprintItem
							.getConnectorId());

					Double totpercentage = 0.0;
					Double totalPercentageCompletionByConnectorIdAndHid = sprintItemService
							.getTotalPercentageCompletionByConnectorIdAndHid(
									sprintItem.getConnectorId(),
									headerinfo.getId());
					if (totalPercentageCompletionByConnectorIdAndHid != null) {
						totpercentage = totalPercentageCompletionByConnectorIdAndHid;
					}
					buffer.append("\"totpercentage\":" + totpercentage// " \"\" "
							+ ", ");

					buffer.append("\"id\":\"" + sprintItem.getConnectorId()
							+ "\",");
					buffer.append("\"name\":\"" + connectorInfo.getName()
							+ "\",");
					buffer.append("\"header\":\""
							+ headerinfo.getSDLCPhaseTask() + "\",");
					buffer.append("\"hid\":\"" + headerinfo.getId() + "\",");
					buffer.append("\"comment\":\"" + sprintItem.getComment()
							+ "\",");
					buffer.append("\"percentage\":\""
							+ sprintItem.getPercentageCompletion() + "\"");

					buffer.append("},");
				}

				if (SprintItems != null && SprintItems.size() > 0) {
					buffer.deleteCharAt(buffer.length() - 1);
				}

			}

		}

		buffer.append("]");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/olderSprintByDate/{startdate}/{enddate}" }, method = RequestMethod.GET)
	public String olderSprintByDate(HttpServletRequest request,
			@PathVariable String startdate, @PathVariable String enddate)
			throws Exception {

		LocalDate startdatetemp = new LocalDate(startdate);

		LocalDate enddateTemp = new LocalDate(enddate);
		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");
		String userName = activeUserData.getFirstName().toUpperCase();
		StringBuffer buffer = new StringBuffer();
		List<SprintMaster> sprintMastes = sprintMasterService
				.findByStartDateEndDateAndowner(startdatetemp, enddateTemp,
						CreateAndCondition(activeUserData));
		buffer.append("{");
		buffer.append("\"data\" : [");
		for (SprintMaster sprintMaster : sprintMastes) {
			List<SprintItem> SprintItems = sprintItemService
					.findBySprintMasterId(sprintMaster.getId());
			for (SprintItem sprintItem : SprintItems) {
				buffer.append("[");

				EstimationHeaders headerinfo = (EstimationHeaders) (estimationHeadersService
						.findById(sprintItem.gethId()));
				Connector connectorInfo = service.findById(sprintItem
						.getConnectorId());

				buffer.append("\"" + connectorInfo.getName() + "\",");
				buffer.append("\"" + headerinfo.getSDLCPhaseTask() + "\",");
				buffer.append("\"" + sprintItem.getComment() + "\",");
				buffer.append("\"" + sprintItem.getPercentageCompletion()
						+ "\"");

				buffer.append("],");
			}

			if (SprintItems != null && SprintItems.size() > 0) {
				buffer.deleteCharAt(buffer.length() - 1);
			}

		}

		buffer.append("]");
		buffer.append("}");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/changeStatus" }, method = RequestMethod.POST, produces = "application/json")
	public String changeStatus(HttpServletRequest request, ModelMap model)
			throws Exception {
		Integer id = Integer.parseInt(request.getParameter("id"));
		String status = request.getParameter("status");
		SprintItemStatus sprintItemStatus = sprintItemStatusService
				.findBySprintItemId(id);
		SprintItem sprintItems = (SprintItem) sprintItemService.findById(id);
		if (sprintItemStatus == null) {
			sprintItemStatus = new SprintItemStatus();
			sprintItemStatus.setSprintItemDate(new LocalDate());
			sprintItemStatus.setSprintItemId(id);
			sprintItemStatus.setStatus(status);
			sprintItemStatusService.saveEntity(sprintItemStatus);
			if (sprintItems != null) {
				double percentage = 0;
				if (status.equals("25% Completed")) {
					percentage = 25.00;
				} else if (status.equals("50% Completed")) {
					percentage = 50.00;
				} else if (status.equals("75% Completed")) {
					percentage = 75.00;
				} else if (status.equals("Re-planned for next sprints")) {
					percentage = 0;
				}
				sprintItems.setPercentageCompletion(percentage);
				sprintItemService.updateEntity(sprintItems);
			}
			return "{ \"message\": \"Status saved successfully\"}";
		} else {
			sprintItemStatus.setSprintItemDate(new LocalDate());
			sprintItemStatus.setStatus(status);
			sprintItemStatusService.updateEntity(sprintItemStatus);
			if (sprintItems != null) {
				double percentage = 0;
				if (status.equals("25% Completed")) {
					percentage = 25.00;
				} else if (status.equals("50% Completed")) {
					percentage = 50.00;
				} else if (status.equals("75% Completed")) {
					percentage = 75.00;
				} else if (status.equals("Re-planned for next sprints")) {
					percentage = 0;
				}
				sprintItems.setPercentageCompletion(percentage);
				sprintItemService.updateEntity(sprintItems);
			}
			return "{ \"message\": \"Status updated successfully\"}";
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/getSprintReport/{startdate}/{enddate}" }, method = RequestMethod.GET, produces = "application/json")
	public String getSprintReport(HttpServletRequest request,
			@PathVariable String startdate, @PathVariable String enddate)
			throws Exception {

		List<Object[]> reports = sprintMasterService.getReportForAlertUser(
				new LocalDate(startdate), new LocalDate(enddate));
		List<TemporaryResults> findByStartDateAndEndDate = resourceAllocationReportService
				.findByStartDateAndEndDate(startdate, enddate, null);

		int totaolefforts = 0;
		for (TemporaryResults result : findByStartDateAndEndDate) {

			totaolefforts += result.getAdjust_day();

		}

		StringBuffer buffer = new StringBuffer();
		buffer.append("[");
		if (reports != null && reports.size() > 0) {
			for (Object[] report : reports) {
				buffer.append("{");
				buffer.append("\"connectorName\": " + "\""
						+ report[0].toString() + "\"" + ", ");
				// buffer.append("\"efforts\": "+ totolWorkingDays + ", ");
				buffer.append("\"efforts\": " + totaolefforts + ", ");
				Double storypoints = new Double(report[1].toString());
				Double productivity = new Double(0.0);
				if (storypoints > 0 && totaolefforts > 0) {
					Double tempeffords = (double) (totaolefforts / 21);
					if (tempeffords > 0) {
						productivity = storypoints / tempeffords;
					}
				}

				buffer.append("\"storypoints\": " + storypoints + ", ");
				buffer.append("\"productivity\": " + productivity + ", ");
				buffer.append("\"velocity\": " + 0);
				buffer.append("},");
			}
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]");

		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getSprintSummary/{startdate}/{enddate}/{createdby}" }, method = RequestMethod.GET, produces = "application/json")
	public String getSprintSummary(HttpServletRequest request,
			@PathVariable String startdate, @PathVariable String enddate,
			@PathVariable String createdby) throws Exception {
		Resource activeUserData = (Resource) request.getSession().getAttribute(
				"user");
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");

		List<SprintSummary> sprintSummary = sprintItemService.getSprintSummary(
				new LocalDate(startdate), new LocalDate(enddate), createdby);
		if (sprintSummary != null && sprintSummary.size() > 0) {

			for (SprintSummary eachSprintSummary : sprintSummary) {

				ConnectorLeadMapping connectorLeadMapping = connectorLeadMappingService
						.findById(eachSprintSummary.getLeadMapping());

				if (connectorLeadMapping.getDevResource().getResourceId() == activeUserData
						.getResourceId()
						|| connectorLeadMapping.getQaResource().getResourceId() == activeUserData
								.getResourceId()
						|| connectorLeadMapping.getAdmin().equalsIgnoreCase(
								activeUserData.getJobAssigned())) {

					buffer.append("{");
					buffer.append("\"id\":" + eachSprintSummary.getId() + ", ");
					buffer.append("\"connector_id\":"
							+ eachSprintSummary.getConnectorId() + ", ");
					buffer.append("\"connector_name\": \""
							+ eachSprintSummary.getConnectorName() + "\", ");
					buffer.append("\"connector_type\":"
							+ eachSprintSummary.getConnectorType() + ", ");

					buffer.append("\"owner\":"
							+ " \""
							+ connectorLeadMapping.getDevResource()
									.getFirstName()
							+ "  ,  "
							+ connectorLeadMapping.getQaResource()
									.getFirstName() + "\" " + ", ");
					buffer.append("\"hid\":" + eachSprintSummary.getHid()
							+ ", ");
					buffer.append("\"sprint_no\":"
							+ eachSprintSummary.getSprintNo() + ", ");
					buffer.append("\"header\": \""
							+ eachSprintSummary.getSDLCPhaseTask() + "\", ");
					buffer.append("\"start_date\": \""
							+ eachSprintSummary.getStartDate() + "\", ");
					buffer.append("\"end_date\": \""
							+ eachSprintSummary.getEndDate() + "\", ");
					buffer.append("\"percentage_completion\": "
							+ eachSprintSummary.getPercentageCompletion()
							+ ", ");
					buffer.append("\"storypoints\": "
							+ eachSprintSummary.getStoryPoints() + ", ");
					SprintItemStatus sprintItemStatus = sprintItemStatusService
							.findBySprintItemId(eachSprintSummary.getId());
					String status = "";
					if (sprintItemStatus != null
							&& sprintItemStatus.getStatus() != null) {
						status = sprintItemStatus.getStatus();
					}
					buffer.append("\"status\": \"" + status + "\"");
					buffer.append("},");

				}
			}

		}

		buffer.deleteCharAt(buffer.length() - 1);
		buffer.append("]");

		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getSprintSummary/{sprintId}" }, method = RequestMethod.GET, produces = "application/json")
	public String getSprintSummary(HttpServletRequest request,
			@PathVariable Integer sprintId) throws Exception {
		SprintMaster masters = (SprintMaster) sprintMasterService
				.findById(sprintId);
		return displaySummary(masters, new StringBuffer()).toString();
		// return "[]";

	}
}