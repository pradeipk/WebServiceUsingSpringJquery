package com.psl.sprint.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.psl.sprint.model.Subtask;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.FRService;
import com.psl.sprint.service.SubTaskService;

@Controller
@RequestMapping("/story-point")
public class SubTaskController extends AbstractController {

	@Autowired
	SubTaskService service;
	@Autowired
	ConnectorService connectorService;
	@Autowired
	FRService frService;

	@Autowired
	MessageSource messageSource;

	@RequestMapping(value = { "/new" }, method = RequestMethod.POST)
	public String saveStoryPoint(@Valid Subtask subtask, BindingResult result, ModelMap model,RedirectAttributes attributes) throws Exception {
		if (result.hasErrors()) {
			return "create_task";
		}
		Subtask task = service.findByName(subtask.getSubtask());
		if(task!=null){
			attributes.addFlashAttribute("message", "Task: "+subtask.getSubtask() +", Already Exists");
			return "redirect:/story-point/new";
		}
		service.saveSubtask(subtask);
		attributes.addFlashAttribute("message", "Task: "+subtask.getSubtask() +", created successfully");
		return "redirect:/story-point/new";
	}

	@RequestMapping(value = { "/edit/{taskId}" }, method = RequestMethod.POST)
	public String updateSubTask(@Valid Subtask subtask, BindingResult result, ModelMap model,@PathVariable Integer taskId) throws Exception {

		if (result.hasErrors()) {
			return "redirect:/edit/+list";
		}
		Subtask existing_subTask = service.findById(taskId);
		existing_subTask.setSubtask(subtask.getSubtask());
		service.updateSubtask(subtask);
		model.addAttribute("success", subtask.getSubtask() + ": Updated Successfully");
		return "redirect:/story-point/list";
	}

	@RequestMapping(value = { "/new" }, method = RequestMethod.GET)
	public String getStoryPoint(ModelMap model) throws Exception {

		Subtask subtask = new Subtask();
		model.addAttribute("task", subtask);
		model.addAttribute("cycle", cycle);
		model.addAttribute("edit", false);
		return "create_task";
	}

	@RequestMapping(value = { "/edit/{taskId}" }, method = RequestMethod.GET)
	public String getSubtaskForEdit(@PathVariable Integer taskId, ModelMap model) throws Exception {

		Subtask subtask = service.findById(taskId);
		model.addAttribute("task", subtask);
		model.addAttribute("dropdown", complexity);
		model.addAttribute("impact", featuresImpacted);
		model.addAttribute("cycle", cycle);
		model.addAttribute("edit", true);
		return "create_task";
	}

	@RequestMapping(value = { "/delete/{taskId}" }, method = RequestMethod.GET)
	public String deleteSubtask(@PathVariable Integer taskId, ModelMap model) throws Exception {

		service.deleteSubtask(taskId);
		model.addAttribute("success", "Record was deleted successfully");
		return "redirect:/story-point/list";
	}

	@RequestMapping(value = { "/list" }, method = RequestMethod.GET)
	public String getStoryPointList(ModelMap model) throws Exception {

		model.addAttribute("subtasks", service.findAllSubtask());
		model.addAttribute("edit", false);
		return "view_task";
	}

}
