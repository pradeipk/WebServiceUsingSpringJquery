package com.psl.sprint.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang.ArrayUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.psl.sprint.dto.ReportDTO;
import com.psl.sprint.dto.ResourceDTO;
import com.psl.sprint.exception.RecordAllReadyExistsException;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorDto;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.model.Leave;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.model.SprintMaster;
import com.psl.sprint.model.Task;
import com.psl.sprint.model.TaskEffortsByConnector;
import com.psl.sprint.model.TemporaryResults;
import com.psl.sprint.service.ConnectorMasterService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.LeaveService;
import com.psl.sprint.service.ResourceAllocationReportService;
import com.psl.sprint.service.SprintItemService;
import com.psl.sprint.service.SprintMasterService;
import com.psl.sprint.service.TaskService;
import com.psl.sprint.service.UserService;
import com.psl.sprint.util.GeneralUtility;
import com.psl.sprint.util.SprintConstants;

@Controller
@RequestMapping("/user")
public class UserController extends AbstractController {

	@Autowired
	private ConnectorService service;

	@Autowired
	private UserService userService;

	@Autowired
	private ConnectorService connectorService;

	@Autowired
	private ResourceAllocationReportService resourceAllocationReportService;

	@Autowired
	private LeaveService leaveService;

	@Autowired
	private TaskService taskService;

	@Autowired
	private SprintItemService sprintItemService;

	@Autowired
	private SprintMasterService sprintMasterService;

	@Autowired
	private ConnectorMasterService connectorMasterService;

	@RequestMapping(value = { "/admin/{id}" }, method = RequestMethod.GET)
	public String findUser(@PathVariable Integer id) {
		return null;
	}

	@RequestMapping(value = { "/admin/new" }, method = RequestMethod.GET)
	public String createUser(ModelMap model) throws Exception {

		try {
			ResourceDTO dto = new ResourceDTO();
			List<Connector> connectors = connectorService
					.findAllConnector(null);
			List<String> connectorNames = new ArrayList<String>();
			connectorNames.add(ASSIGN_CONNECTOR_LATER);
			for (Connector connector : connectors) {
				connectorNames.add(connector.getName());
			}
			model.addAttribute("connectors", connectorNames);
			model.addAttribute("resource", dto);
			model.addAttribute("roles", roles);
			model.addAttribute("teamlead", teamlead);

			return "create_user";

		} catch (Exception e) {
			return "create_user";
		}

	}

	@RequestMapping(value = { "/admin/viewExclusion/{user_id}" }, method = RequestMethod.GET)
	public String userLeaveTransaction(@PathVariable Integer user_id,
			ModelMap model) throws Exception {
		ResourceDTO user = (ResourceDTO) userService.findById(user_id);
		List<Leave> leaves = leaveService.findByResourceID(user_id);
		model.addAttribute("leaves", leaves);
		Leave leave = new Leave();
		leave.setResourceId(user_id);
		model.addAttribute("leave", leave);
		model.addAttribute("resourceName", user.getFirstName());
		model.addAttribute("type", SprintConstants.EXCLUSION_TYPE);
		model.addAttribute("percentage", SprintConstants.EXCLUSION_PERCENTAGE);
		model.addAttribute("action", "Mark Exclusion");
		return "view_leave_transaction";
	}

	@RequestMapping(value = { "/admin/getExclusion/{leaveId}" }, method = RequestMethod.GET)
	public String getLeaveTransaction(@PathVariable Integer leaveId,
			ModelMap model) throws Exception {
		try {
			Leave leave = (Leave) leaveService.findById(leaveId);
			if (leave.getType().equals("SELF")) {
				leave.setType("Leave");
			} else if (leave.getType().equals("TRAN")) {
				leave.setType("Training");
			} else {
				leave.setType("Meeting");
			}

			model.addAttribute("leaves",
					leaveService.findByResourceID(leave.getResourceId()));
			model.addAttribute("leave", leave);
			model.addAttribute("resourceName", ((ResourceDTO) userService
					.findById(leave.getResourceId())).getFirstName());
			model.addAttribute("type", SprintConstants.EXCLUSION_TYPE);
			model.addAttribute("percentage",
					SprintConstants.EXCLUSION_PERCENTAGE);
			model.addAttribute("action", "Update Exclusion");
			return "view_leave_transaction";
		} catch (Exception e) {
			return "";
		}
	}

	@RequestMapping(value = { "/admin/deleteExclusion/{leaveId}" }, method = RequestMethod.GET)
	public String deleteLeaveTransaction(@PathVariable Integer leaveId,
			ModelMap model) throws Exception {
		Leave leave = (Leave) leaveService.findById(leaveId);
		int resourceId = leave.getResourceId();
		leaveService.deleteEntity(leave);
		return "redirect:/user/admin/viewExclusion/" + resourceId;
	}

	@RequestMapping(value = { "/admin/addExclusion" }, method = RequestMethod.POST)
	public String createUserLeaveTransaction(
			@ModelAttribute("leave") Leave leave, HttpServletRequest request,
			ModelMap model) throws Exception {
		boolean hasError = false;
		if (leave.getStartDate() == null || leave.getEndDate() == null) {
			model.addAttribute("date_error", "Start/End date required");
			hasError = true;
		}
		if (leave.getType() == null || leave.getType().endsWith("NONE")) {
			model.addAttribute("type_error", "Leave type required");
			hasError = true;
		}
		if (leave.getPercentage() == null || leave.getPercentage() == 0) {
			model.addAttribute("percentage_error", "Percentage required");
			hasError = true;
		}
		Integer resourceId = leave.getResourceId();
		if (!hasError) {
			if (leave.getType().equals("Leave")) {
				leave.setType("SELF");
			}
			if (leave.getType().equals("Training")) {
				leave.setType("TRAN");
			}
			if (leave.getType().equals("Meeting")) {
				leave.setType("MEET");
			}
			if ("Update Exclusion".equals(request.getParameter("action"))) {
				leaveService.updateEntity(leave);
			} else {
				leave.setLeaveId(null);
				leaveService.saveEntity(leave);
			}
			leave = null;
			leave = new Leave();
		}
		ResourceDTO user = (ResourceDTO) userService.findById(resourceId);
		List<Leave> leaves = leaveService.findByResourceID(resourceId);
		model.addAttribute("leaves", leaves);
		leave.setResourceId(resourceId);
		model.addAttribute("leave", leave);
		model.addAttribute("resourceName", user.getFirstName());
		model.addAttribute("type", SprintConstants.EXCLUSION_TYPE);
		model.addAttribute("percentage", SprintConstants.EXCLUSION_PERCENTAGE);
		model.addAttribute("action", "Mark Exclusion");
		return "view_leave_transaction";
	}

	@RequestMapping(value = { "/admin/new" }, method = RequestMethod.POST)
	public String saveUser(@Valid ResourceDTO resourcedto,
			BindingResult result, ModelMap model) throws Exception {
		try {
			if (resourcedto.getFirstName().isEmpty()) {
				model.addAttribute("firstName_error", "First name required");
			}
			if (resourcedto.getLastName().isEmpty()) {
				model.addAttribute("lastName_error", "Last name required");
			}
			if (resourcedto.getJobAssigned().isEmpty()) {
				model.addAttribute("jobAssigned_error", "Expertise required");
			}
			if (resourcedto.getTeamlead().isEmpty()) {
				model.addAttribute("teamlead_error", "Team Lead required");
			}
			if (resourcedto.getFirstName().isEmpty()
					|| resourcedto.getLastName().isEmpty()
					|| resourcedto.getJobAssigned().isEmpty()
					|| resourcedto.getTeamlead().isEmpty()) {
				model.addAttribute("resource", resourcedto);
				model.addAttribute("roles", roles);
				model.addAttribute("teamlead", teamlead);
				return "create_user";
			} else {
				userService.saveEntity(resourcedto);
				return "redirect:/user/admin/view-resource/false";
			}
		} catch (RecordAllReadyExistsException e) {
			model.addAttribute("error", e.getMessage());
			return "redirect:/user/admin/new";
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "redirect:/error";
		}
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = { "/admin/edit/{userId}" }, method = RequestMethod.POST)
	public String updateUser(@PathVariable Integer userId,
			@ModelAttribute("ResourceDTO") ResourceDTO resourceDTO,
			ModelMap model, RedirectAttributes attribute) throws Exception {

		try {
			userService.updateEntity(resourceDTO);
			model.addAttribute("resources", userService.findAll(false, null));
			return "view_users";
		} catch (Exception e) {
			if (e.getMessage().equalsIgnoreCase(
					"First Name and Last name can not be changed")) {
				attribute.addFlashAttribute("error", e.getMessage());
				return "redirect:/user/admin/edit/" + userId;
			}
			throw e;
		}

	}

	/**
	 * 
	 * @param connectorId
	 * @param userId
	 * @param resourcesLog
	 * @param model
	 * @param result
	 * @param redirectAttribute
	 * @return
	 * @throws Exception
	 * 
	 *             This controller is used for modifying the allocations,
	 * 
	 */

	@RequestMapping(value = { "/admin/edit/allocation/{connectorId}/{userId}" }, method = RequestMethod.POST)
	public String updateUsers(@PathVariable Integer connectorId,
			@PathVariable Integer userId,
			@Valid ResourceAllocationLog resourcesLog, ModelMap model,
			BindingResult result, RedirectAttributes redirectAttribute)
			throws Exception {

		try {

			int s_day = resourcesLog.getStartDate().getDayOfWeek();
			int e_day = resourcesLog.getEndDate().getDayOfWeek();

			if (s_day == 6 || s_day == 7 || e_day == 6 || e_day == 7) {
				StringBuilder builder = new StringBuilder(
						"connector/editAllocation/");
				builder.append(resourcesLog.getAllocationId()).append("/")
						.append(userId).append("/")
						.append(resourcesLog.getStartDate()).append("/")
						.append(resourcesLog.getEndDate()).append("/")
						.append("isCheck");
				redirectAttribute
						.addFlashAttribute("error",
								"Start date and end date can not be Saturday or Sunday");
				return "redirect:/" + builder.toString();
			}

			Resource resource = new Resource();
			resource.setResourceId(userId);
			resourcesLog.setResource(resource);
			resourcesLog.setConnectorId(connectorId);
			resource.getResourceAllocationList().add(resourcesLog);
			userService.updateUserWithModifiedAllocation(resourcesLog);

			String connector0 = connectorService.findById(connectorId)
					.getName();
			return "redirect:/connector/view-resources/" + connector0;
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * 
	 * @param resourceId
	 * @param allocationLog
	 * @param model
	 * @param result
	 * @param connector
	 * @param startDate
	 * @param endDate
	 * @param attributes
	 * @return
	 * @throws Exception
	 * 
	 *             this method updates the user and connector with allocations
	 *             and create an entry in resoure log table
	 * 
	 */
	@RequestMapping(value = { "/admin/newAllocation/{resourceId}/{connector}/{startDate}/{endDate}/{bandwidth}" }, method = RequestMethod.POST)
	public String updateUserWithNewAllocation(@PathVariable Integer resourceId,
			@Valid ResourceAllocationLog allocationLog, ModelMap model,
			BindingResult result, @PathVariable Integer connector,
			@PathVariable String startDate, @PathVariable String endDate,
			@PathVariable Double bandwidth, RedirectAttributes attributes)
			throws Exception {

		if (allocationLog.getBandwidthShare().equals(0.0d)) {
			attributes.addFlashAttribute("error",
					"Not a valid allocation percentage");
			return "redirect:/connector/view-resources/"
					+ allocationLog.getConnectorName();
		}

		/*
		 * in db allocations are saved between 0.0 to 1.0, if it is in % convert
		 * it accordingly
		 */
		if (allocationLog.getBandwidthShare() > 1.0) {
			Double allocation = allocationLog.getBandwidthShare() / 100.0;
			allocationLog.setBandwidthShare(allocation);
		}

		if (allocationLog.getStartDate() == null
				|| allocationLog.getEndDate() == null) {
			attributes.addFlashAttribute("error", "Invalid start and end date");
			StringBuilder builder = new StringBuilder(
					"connector/newAllocation/");
			builder.append(resourceId).append("/").append(connector)
					.append("/").append(bandwidth).append("/")
					.append(startDate).append("/").append(endDate);

			return "redirect:/" + builder.toString();
		}

		int s_day = allocationLog.getStartDate().getDayOfWeek();
		int e_day = allocationLog.getEndDate().getDayOfWeek();

		if (s_day == 6 || s_day == 7 || e_day == 6 || e_day == 7) {

			attributes.addFlashAttribute("error",
					"Start date and end date can not be Saturday or Sunday");
			StringBuilder builder = new StringBuilder(
					"connector/newAllocation/");
			builder.append(resourceId).append("/").append(connector)
					.append("/").append(bandwidth).append("/")
					.append(startDate).append("/").append(endDate);

			return "redirect:/" + builder.toString();
		}

		Resource resources = new Resource();
		allocationLog.setCreatedDate(new DateTime());
		allocationLog.setCreatedBy((String) SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal());
		allocationLog.setUpdatedDate(new DateTime());
		allocationLog.setUpdatedBy((String) SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal());

		if (allocationLog.getStartDate().isBefore(new LocalDate(startDate))
				|| allocationLog.getEndDate().isAfter(new LocalDate(endDate))) {
			attributes.addFlashAttribute("error",
					"Can not create allocation , selected date is beyond range :"
							+ startDate + " to " + endDate);

			StringBuilder builder = new StringBuilder(
					"connector/newAllocation/");
			builder.append(resourceId).append("/").append(connector)
					.append("/").append(bandwidth).append("/")
					.append(startDate).append("/").append(endDate);

			return "redirect:/" + builder.toString();
		}
		Connector tempConnector = connectorService.findById(allocationLog
				.getConnectorId());
		Double initailPds = tempConnector.getInitialPds().doubleValue();
		Double totalPDSUtilized = connectorService
				.getTotalPDSUtilized(tempConnector.getName());
		if (totalPDSUtilized != null
				&& initailPds <= totalPDSUtilized
				&& (tempConnector.getCategory() == null
						|| tempConnector.getCategoryExternal() == null
						|| tempConnector.getEstimatedPds() == null
						|| tempConnector.getEstimatedPdsExternal() == null
						|| tempConnector.getEstimatedPdsQa() == null || tempConnector
						.getEstimatedPdsExternalQa() == null)) {
			attributes.addFlashAttribute("error",
					"To proceed with the allocation, you need to create estimation for the "
							+ tempConnector.getName());
			StringBuilder builder = new StringBuilder(
					"connector/newAllocation/");
			builder.append(resourceId).append("/").append(connector)
					.append("/").append(bandwidth).append("/")
					.append(startDate).append("/").append(endDate);
			return "redirect:/" + builder.toString();
		}/*
		 * else { String start_Date = allocationLog.getStartDate().toString();
		 * String end_Date = allocationLog.getEndDate().toString(); SprintMaster
		 * findByStartDateEndDateAndConnectorId = sprintMasterService
		 * .findByStartDateEndDateAndConnectorId(start_Date, end_Date,
		 * tempConnector.getId()); if (findByStartDateEndDateAndConnectorId ==
		 * null && (tempConnector.getIsExempted() != null && tempConnector
		 * .getIsExempted() == 0)) { attributes.addFlashAttribute("error",
		 * "To proceed with the allocation, you need to create sprint for the "
		 * + tempConnector.getName()); StringBuilder builder = new
		 * StringBuilder( "connector/newAllocation/");
		 * builder.append(resourceId).append("/").append(connector)
		 * .append("/").append(bandwidth).append("/")
		 * .append(startDate).append("/").append(endDate); return "redirect:/" +
		 * builder.toString(); } }
		 */
		resources.setResourceId(resourceId);
		resources.getResourceAllocationList().add(allocationLog);
		try {
			userService.updateUserWithAllocation(resources);
			return "redirect:/connector/view-resources/"
					+ allocationLog.getConnectorName();
		} catch (Exception e) {
			attributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/connector/view-resources/"
					+ allocationLog.getConnectorName();
		}
	}

	@RequestMapping(value = { "/admin/edit/{userId}" }, method = RequestMethod.GET)
	public String editUser(@PathVariable Integer userId, ModelMap model)
			throws Exception {

		ResourceDTO dto = (ResourceDTO) userService.findById(userId);
		List<String> connectors = new ArrayList<String>();
		connectors.add(ASSIGNMENT_NOT_APPLICABLE);
		connectors.add(RELEASE_FROM_ASSIGNMENT);
		for (Connector iterable_element : connectorService
				.findAllConnector(null)) {
			connectors.add(iterable_element.getName());
		}
		model.addAttribute("resourceDTO", dto);
		model.addAttribute("connector", connectors);
		model.addAttribute("expertise", roles);
		model.addAttribute("access_levels", accessLevel);

		return "edit_user";

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = { "/admin/view-resource/{edit}" }, method = RequestMethod.GET)
	public String findAllResource(@PathVariable boolean edit, ModelMap model,
			HttpServletRequest request) throws Exception {
		try {
			Resource activeUserData = (Resource) request.getSession()
					.getAttribute("user");

			model.addAttribute("resources",
					userService.findAll(edit, activeUserData.getResourceId()));
			return "view_users";
		} catch (Exception e) {
			return "view_users";
		}

	}

	@RequestMapping(value = { "/admin/resource-allocation-report" }, method = RequestMethod.GET)
	public String getResourceAllocationReport(Model model) {
		model.addAttribute("ReportDTO", new ReportDTO());
		return "resource_allocation_report";
	}

	@RequestMapping(value = { "/admin/resource-allocation-report" }, method = RequestMethod.POST)
	public ModelAndView downloadResourceReport(Model model,
			@Valid ReportDTO reportDTO, BindingResult bindingResult)
			throws Exception {
		HashMap<String, Object> resourceAllocationReport = resourceAllocationReportService
				.downloadResourceAllocationReport(reportDTO);
		return new ModelAndView("excelView", "resourceAllocationReport",
				resourceAllocationReport);
	}

	@RequestMapping(value = { "/getAllResources" }, method = RequestMethod.GET)
	public @ResponseBody
	List<ResourceDTO> getAllResource() throws Exception {

		List<ResourceDTO> resourceDTOList = userService.getAllResourceNames();
		return resourceDTOList;
	}

	@RequestMapping(value = { "/getResourceAllocationDetails" }, method = RequestMethod.GET)
	@ResponseBody
	public HashMap<String, Object> downloadResourceReport(Model model,
			@ModelAttribute("reportDTO") ReportDTO reportDTO) throws Exception {
		if (reportDTO.getConnector() != null
				&& !reportDTO.getConnector().equals("0")) {
			ConnectorMaster connectorMaster = (ConnectorMaster) connectorMasterService
					.findById(Integer.parseInt(reportDTO.getConnector()));
			String monthYear = reportDTO.getMonthYear();
			String startDate = "";
			String endDate = "";
			if (reportDTO.getDuration().equals("monthlyradio")) {
				String[] monthYearArray = monthYear.split("-");
				startDate = monthYear + "-01";
				endDate = GeneralUtility.getLastDayOfMonth(
						Integer.parseInt(monthYearArray[1]),
						Integer.parseInt(monthYearArray[0]));
			} else {
				startDate = reportDTO.getStartDate();
				endDate = reportDTO.getEndDate();
			}
			Double pds = 0d;
			List<TemporaryResults> findByStartDateAndEndDate = resourceAllocationReportService
					.findByStartDateAndEndDate(startDate, endDate,
							connectorMaster.getConnectorName());
			for (TemporaryResults result : findByStartDateAndEndDate) {
				pds += result.getAdjust_day();
			}
			HashMap<String, Object> resourceAllocationReport = new HashMap<String, Object>();
			resourceAllocationReport.put("result", "{\"connector_name\": \""
					+ connectorMaster.getConnectorName() + "\",\"pds\" : "
					+ pds + "}");
			return resourceAllocationReport;
		} else {
			HashMap<String, Object> resourceAllocationReport = resourceAllocationReportService
					.getResourceAllocationReport(reportDTO);
			if (ArrayUtils.contains(reportDTO.getResourceIds(), 0)) {
				List<ReportDTO> resourceUnallocationReport = resourceAllocationReportService
						.getResourceUnallocationReport(reportDTO);
				resourceAllocationReport.put("0/Unallocated",
						resourceUnallocationReport);
			}
			return resourceAllocationReport;
		}
	}

	@RequestMapping(value = { "/getAllConnectors" }, method = RequestMethod.GET)
	public @ResponseBody
	List<ConnectorDto> getAllConnectors() throws Exception {

		/*
		 * Authentication auth1 = SecurityContextHolder.getContext()
		 * .getAuthentication();
		 */

		List<Connector> connectorList = resourceAllocationReportService
				.findAll();

		ArrayList<ConnectorDto> connectorDTOList = new ArrayList<ConnectorDto>();
		for (Connector connector : connectorList) {
			ConnectorDto connectorDto = new ConnectorDto();
			connectorDto.setConnectorName(connector.getName());
			connectorDto.setConnectorId(connector.getId());
			connectorDTOList.add(connectorDto);
		}
		return connectorDTOList;
	}

	@RequestMapping(value = { "/getProjectWorkLog" }, method = RequestMethod.GET)
	public @ResponseBody
	List<ReportDTO> getProjectWorkLog(int connectorId) throws Exception {

		List<ReportDTO> connectorLog = resourceAllocationReportService
				.getProjectWorkLog(connectorId);
		return connectorLog;

	}

	@RequestMapping(value = { "/task" }, method = RequestMethod.GET)
	public String getTaskList(Model model, HttpServletRequest request)
			throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		if (resource == null) {
			return "redirect:/";
		}
		LocalDate date = LocalDate.now();
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(resource, date.toString());
		Map<Integer, String> connectors = new HashMap<Integer, String>();
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			connectors.put(resourceAllocation.getConnectorId(),
					resourceAllocation.getConnectorName());
		}
		List<Task> taskList = (List<Task>) taskService.findByName(resource);
		model.addAttribute("connectorList", connectors);
		model.addAttribute("action", "Add");
		Task task = new Task();
		task.setResourceId(resource.getResourceId());
		model.addAttribute("task", task);
		model.addAttribute("taskList", taskList);
		return "task";
	}

	@ResponseBody
	@RequestMapping(value = { "/getConnectorsList" }, method = RequestMethod.GET, produces = "application/json")
	public Object getConnectorsList(HttpServletRequest request)
			throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		if (resource == null) {
			return "redirect:/";
		}
		String date = request.getParameter("date");
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(resource, date);
		StringBuffer buffer = new StringBuffer();
		List<Integer> connectorIds = new ArrayList<Integer>();
		buffer.append("[");
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			if (!connectorIds.contains(resourceAllocation.getConnectorId())) {
				buffer.append("{");
				buffer.append("\"id\": " + resourceAllocation.getConnectorId()
						+ ",");
				buffer.append("\"name\": \""
						+ resourceAllocation.getConnectorName() + "\"");
				connectorIds.add(resourceAllocation.getConnectorId());
				buffer.append("},");
			}
		}
		if (!connectorList.isEmpty()) {
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]");
		return buffer.toString();
	}

	@ResponseBody
	@RequestMapping(value = { "/getAllPhases/{connectorId}" }, method = RequestMethod.GET, produces = "application/json")
	public String changeStatus(@PathVariable Integer connectorId,
			HttpServletRequest request, ModelMap model) throws Exception {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[");

		List findByConnectorId = (List) sprintItemService
				.findByConnectorId(service.findById(connectorId)
						.getConnectorType());
		for (Object object : findByConnectorId) {
			buffer.append("{ \"header\" : \"" + object + "\"},");
		}
		buffer.append("{ \"header\" : \"Build Pipeline IT / UT issues\"},");
		buffer.append("{ \"header\" : \"Meeting / Co-ordination\"},");
		buffer.append("{ \"header\" : \"Rework\"},");
		buffer.append("{ \"header\" : \"Enhancements\"},");
		buffer.append("{ \"header\" : \"Others\"}");
		buffer.append("]");
		return buffer.toString();
	}

	@RequestMapping(value = { "/task/edit/{task_id}" }, method = RequestMethod.GET)
	public String editTask(@PathVariable Integer task_id, Model model,
			HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		if (resource == null) {
			return "redirect:/";
		}
		List<Task> taskList = (List<Task>) taskService.findByName(resource);
		Task task = (Task) taskService.findById(task_id);
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(resource, task.getTaskDate().toString());
		Map<Integer, String> connectors = new HashMap<Integer, String>();
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			connectors.put(resourceAllocation.getConnectorId(),
					resourceAllocation.getConnectorName());
		}
		model.addAttribute("connectorList", connectors);
		model.addAttribute("action", "Update");
		model.addAttribute("task", task);
		List findByConnectorId = (List) sprintItemService
				.findByConnectorId(service.findById(task.getConnectorId())
						.getConnectorType());
		List<String> phase = new ArrayList<String>();
		for (int i = 0; i < findByConnectorId.size(); i++) {
			if (((String) findByConnectorId.get(i))
					.equals("Integration Testing/Acceptance Testing - Mocha")) {
				phase.add("Integration Testing (Mocha) - TEST CASE CREATION");
				phase.add("Integration Testing (Mocha) - TEST CASE EXECUTION");
			} else {
				phase.add((String) findByConnectorId.get(i));
			}
		}
		phase.add("Build Pipeline IT / UT issues");
		phase.add("Meeting / Co-ordination");
		phase.add("Rework");
		phase.add("Enhancements");
		phase.add("Others");
		model.addAttribute("phase", phase);
		model.addAttribute("taskList", taskList);
		return "task";
	}

	@RequestMapping(value = { "/task/delete/{task_id}" }, method = RequestMethod.GET)
	public String deleteTask(@PathVariable Integer task_id, Model model,
			HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		if (resource == null) {
			return "redirect:/";
		}
		Object deleteObject = taskService.findById(task_id);
		if (deleteObject != null) {
			taskService.deleteEntity(deleteObject);
		}
		List<Task> taskList = (List<Task>) taskService.findByName(resource);
		model.addAttribute("action", "Add");
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(resource, LocalDate.now().toString());
		Map<Integer, String> connectors = new HashMap<Integer, String>();
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			connectors.put(resourceAllocation.getConnectorId(),
					resourceAllocation.getConnectorName());
		}
		model.addAttribute("connectorList", connectors);
		model.addAttribute("task", new Task());
		model.addAttribute("taskList", taskList);
		return "task";
	}

	@RequestMapping(value = { "/task/save" }, method = RequestMethod.POST)
	public String saveTask(@ModelAttribute("task") Task task, Model map,
			HttpServletRequest request) throws Exception {
		boolean hasError = false;
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		if (resource == null) {
			return "redirect:/";
		}

		if (task.getPhase() == null || task.getPhase().equals("NONE")) {
			map.addAttribute("phase_error", "Phase required");
			hasError = true;
		} else if (task.getPhase().equals("Others")
				&& (task.getDescription() == null || task.getDescription()
						.isEmpty())) {
			map.addAttribute("description_error", "Description required");
			hasError = true;
		} else if (!(task.getPhase().equals("Build Pipeline IT / UT issues")
				|| task.getPhase().equals("Others") || task.getPhase().equals(
				"Meeting / Co-ordination"))) {
			if (task.getConnectorId() == null || task.getConnectorId() == 0) {
				map.addAttribute("connectorId_error", "Connector required");
				hasError = true;
			}
		}
		if (task.getHoursSpent() == null || task.getHoursSpent() < 0d) {
			map.addAttribute("hoursSpent_error",
					"Hours spent required || Hours spent should be positive");
			hasError = true;
		}
		if (task.getTaskDate() == null) {
			map.addAttribute("taskDate_error", "Date required");
			hasError = true;
		} else {
			LocalDate minus2Days = new LocalDate().minusDays(2);
			if (task.getTaskDate().isBefore(minus2Days)) {
				map.addAttribute("taskDate_error",
						"Date cannot be less than last 2 days");
				hasError = true;
			}
		}
		LocalDate date = LocalDate.now();
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(resource, date.toString());
		Map<Integer, String> connectors = new HashMap<Integer, String>();
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			connectors.put(resourceAllocation.getConnectorId(),
					resourceAllocation.getConnectorName());
		}
		map.addAttribute("connectorList", connectors);
		List<Task> taskList = (List<Task>) taskService.findByName(resource);
		map.addAttribute("action", "Add");
		map.addAttribute("taskList", taskList);
		if (!hasError) {
			if ("Add".equals(request.getParameter("action"))) {
				task.setCreatedDate(new LocalDate());
				task.setCreatedBy((String) request.getSession().getAttribute(
						"hostname"));
				taskService.saveEntity(task);
			} else {
				Task task1 = (Task) taskService.findById(task.getId());
				task.setCreatedDate(task1.getCreatedDate());
				task.setCreatedBy(task1.getCreatedBy());
				task.setModifiedDate(new LocalDate());
				task.setModifiedBy((String) request.getSession().getAttribute(
						"hostname"));
				taskService.updateEntity(task);
			}
			Task newTask = new Task();
			newTask.setResourceId(resource.getResourceId());
			map.addAttribute("task", newTask);
			return "redirect:/user/task";
		} else {
			List findByConnectorId = (List) sprintItemService
					.findByConnectorId(service.findById(task.getConnectorId())
							.getConnectorType());
			List<String> phase = new ArrayList<String>();
			for (int i = 0; i < findByConnectorId.size(); i++) {
				if (((String) findByConnectorId.get(i))
						.equals("Integration Testing/Acceptance Testing - Mocha")) {
					phase.add("Integration Testing (Mocha) - TEST CASE CREATION");
					phase.add("Integration Testing (Mocha) - TEST CASE EXECUTION");
				} else {
					phase.add((String) findByConnectorId.get(i));
				}
			}
			phase.add("Build Pipeline IT / UT issues");
			phase.add("Meeting / Co-ordination");
			phase.add("Rework");
			phase.add("Enhancements");
			phase.add("Others");
			map.addAttribute("phase", phase);
			map.addAttribute("task", task);
			return "task";
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/getTask" }, method = RequestMethod.GET, produces = "application/json")
	public String getEffortsByDateAndOrConnector(HttpServletRequest request)
			throws Exception {
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		Integer connectorId = null;
		if (request.getParameter("connectorId") != null) {
			connectorId = Integer.parseInt(request.getParameter("connectorId"));
		}
		Integer resourceId = null;
		if (request.getParameter("resourceId") != null) {
			resourceId = Integer.parseInt(request.getParameter("resourceId"));
		}

		List<TaskEffortsByConnector> effortsForPhaseByConnector = taskService
				.getEffortsByDateAndOrConnector(startDate, endDate,
						connectorId, resourceId);
		StringBuffer buffer = new StringBuffer();
		buffer.append("{\"data\": [");
		for (TaskEffortsByConnector taskResourceConnector : effortsForPhaseByConnector) {
			buffer.append("[");
			buffer.append("\"" + taskResourceConnector.getResourceName()
					+ "\",");
			buffer.append("\"" + taskResourceConnector.getTaskDate() + "\",");
			buffer.append("\"" + taskResourceConnector.getConnectorName()
					+ "\",");
			buffer.append("\"" + taskResourceConnector.getPhase() + "\",");
			String description = taskResourceConnector.getDescription();
			description = description.replaceAll("\r", " ");
			description = description.replaceAll("\n", " ");
			description = description.replaceAll("\t", " ");
			buffer.append("\"" + description + "\",");
			buffer.append("\"" + taskResourceConnector.getNoOfHours() + "\"");
			buffer.append("],");
		}
		if (!effortsForPhaseByConnector.isEmpty()) {
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]}");
		return buffer.toString();
	}

	@RequestMapping(value = { "/task/Resources" }, method = RequestMethod.GET)
	public String getResourcesTaskList(Model model, HttpServletRequest request)
			throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		if (resource == null) {
			return "redirect:/";
		}
		LocalDate date = LocalDate.now();
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(resource, date.toString());
		Map<Integer, String> connectors = new HashMap<Integer, String>();
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			connectors.put(resourceAllocation.getConnectorId(),
					resourceAllocation.getConnectorName());
		}
		List<Task> taskList = (List<Task>) taskService.findByName(resource);

		List<Resource> subCordinates = userService.findResourcesBYRmId(resource
				.getResourceId());
		model.addAttribute("subCordinates", subCordinates);
		model.addAttribute("connectorList", connectors);
		model.addAttribute("action", "Add");
		Task task = new Task();
		task.setResourceId(resource.getResourceId());
		model.addAttribute("task", task);
		model.addAttribute("taskList", taskList);
		model.addAttribute("message", " ");
		return "resourceTask";
	}

}