package com.psl.sprint.controller;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.model.Task;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.service.ResourceAllocationReportService;
import com.psl.sprint.service.SprintItemService;
import com.psl.sprint.service.TaskService;
import com.psl.sprint.service.UserService;

@Controller
@RequestMapping("/associate")
public class associateController extends AbstractController {
	@Autowired
	private UserService userService;
	@Autowired
	private ResourceAllocationReportService resourceAllocationReportService;
	@Autowired
	private TaskService taskService;

	@Autowired
	private SprintItemService sprintItemService;
	@Autowired
	private ConnectorService service;

	@ResponseBody
	@RequestMapping(value = { "/getConnectorsListforResource" }, method = RequestMethod.GET, produces = "application/json")
	public Object getConnectorsListforResource(HttpServletRequest request)
			throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		if (resource == null) {
			return "redirect:/";
		}
		String date = request.getParameter("date");
		String subresourceId = request.getParameter("subresourceId");
		Resource subResource = userService.findResourceByID(Integer
				.parseInt(subresourceId));

		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUserStartDate(subResource, date);
		StringBuffer buffer = new StringBuffer();
		List<Integer> connectorIds = new ArrayList<Integer>();
		buffer.append("[");
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			if (!connectorIds.contains(resourceAllocation.getConnectorId())) {
				buffer.append("{");
				buffer.append("\"id\": " + resourceAllocation.getConnectorId()
						+ ",");
				buffer.append("\"name\": \""
						+ resourceAllocation.getConnectorName() + "\"");
				connectorIds.add(resourceAllocation.getConnectorId());
				buffer.append("},");
			}
		}
		if (!connectorList.isEmpty()) {
			buffer.deleteCharAt(buffer.length() - 1);
		}
		buffer.append("]");
		return buffer.toString();
	}

	@RequestMapping(value = { "/task/save" }, method = RequestMethod.POST)
	public String saveTask(@ModelAttribute("task") Task task, Model map,
			HttpServletRequest request, RedirectAttributes attributes)
			throws Exception {
		boolean hasError = false;
		HttpSession session = request.getSession();

		Map<String, String> params = new ConcurrentHashMap<String, String>();
		for (Enumeration<String> parameterNames = request.getParameterNames(); parameterNames
				.hasMoreElements();) {
			String key = parameterNames.nextElement();
			params.put(key, request.getParameter(key));
		}

		Integer resourceId = Integer.parseInt(params.get("resourceId"));
		Resource resource = userService.findResourceByID(resourceId);
		if (resource == null) {
			return "redirect:/";
		}

		if (task.getPhase() == null || task.getPhase().equals("NONE")) {
			map.addAttribute("phase_error", "Phase required");
			hasError = true;
		} else if (task.getPhase().equals("Others")
				&& (task.getDescription() == null || task.getDescription()
						.isEmpty())) {
			map.addAttribute("description_error", "Description required");
			hasError = true;
		} else if (!(task.getPhase().equals("Build Pipeline IT / UT issues")
				|| task.getPhase().equals("Others") || task.getPhase().equals(
				"Meeting / Co-ordination"))) {
			if (task.getConnectorId() == null || task.getConnectorId() == 0) {
				map.addAttribute("connectorId_error", "Connector required");
				hasError = true;
			}
		}
		if (task.getHoursSpent() == null || task.getHoursSpent() < 0d) {
			map.addAttribute("hoursSpent_error",
					"Hours spent required || Hours spent should be positive");
			hasError = true;
		}
		if (task.getTaskDate() == null) {
			map.addAttribute("taskDate_error", "Date required");
			hasError = true;
		}
		LocalDate date = LocalDate.now();
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(resource, date.toString());
		Map<Integer, String> connectors = new HashMap<Integer, String>();
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			connectors.put(resourceAllocation.getConnectorId(),
					resourceAllocation.getConnectorName());
		}
		map.addAttribute("connectorList", connectors);
		List<Task> taskList = (List<Task>) taskService.findByName(resource);
		map.addAttribute("action", "Add");
		map.addAttribute("taskList", taskList);
		if (!hasError) {
			if ("Add".equals(request.getParameter("action"))) {
				task.setCreatedDate(new LocalDate());
				task.setCreatedBy((String) request.getSession().getAttribute(
						"hostname"));
				taskService.saveEntity(task);
			} else {
				Task task1 = (Task) taskService.findById(task.getId());
				task.setCreatedDate(task1.getCreatedDate());
				task.setCreatedBy(task1.getCreatedBy());
				task.setModifiedDate(new LocalDate());
				task.setModifiedBy((String) request.getSession().getAttribute(
						"hostname"));
				taskService.updateEntity(task);
			}
			Task newTask = new Task();
			newTask.setResourceId(resource.getResourceId());
			map.addAttribute("task", newTask);
			attributes.addFlashAttribute("message", "Record Inserted ");
			return "redirect:/user/task/Resources";
		} else {
			List findByConnectorId = (List) sprintItemService
					.findByConnectorId(service.findById(task.getConnectorId())
							.getConnectorType());
			List<String> phase = new ArrayList<String>();
			for (int i = 0; i < findByConnectorId.size(); i++) {
				if (((String) findByConnectorId.get(i))
						.equals("Integration Testing/Acceptance Testing - Mocha")) {
					phase.add("Integration Testing (Mocha) - TEST CASE CREATION");
					phase.add("Integration Testing (Mocha) - TEST CASE EXECUTION");
				} else {
					phase.add((String) findByConnectorId.get(i));
				}
			}
			phase.add("Build Pipeline IT / UT issues");
			phase.add("Meeting / Co-ordination");
			phase.add("Rework");
			phase.add("Enhancements");
			phase.add("Others");
			map.addAttribute("phase", phase);
			map.addAttribute("task", task);
			map.addAttribute("message", "Record Inserted");
			return "resourceTask";
		}
	}

	@ResponseBody
	@RequestMapping(value = { "/displayRecords" }, method = RequestMethod.GET, produces = "application/json")
	public Object displayRecords(HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		if (resource == null) {
			return "redirect:/";
		}
		String todate = request.getParameter("todate");
		String fromDate = request.getParameter("fromDate");
		String subresourceId = request.getParameter("subresourceId");
		List<Resource> allResource = new ArrayList<>();
		List<Task> allTaskList = new ArrayList<>();
		if (subresourceId.equalsIgnoreCase("NONE")) {
			List<Resource> subCordinates = userService
					.findResourcesBYRmId(resource.getResourceId());
			if (subCordinates != null) {
				allResource.addAll(subCordinates);
			}
		} else {
			Resource subResource = userService.findResourceByID(Integer
					.parseInt(subresourceId));
			if (subResource != null) {
				allResource.add(subResource);
			}

		}

		if (allResource != null && allResource.size() > 0) {
			for (Resource resour : allResource) {
				List<Task> taskList = taskService.findByidAndDate(
						resour.getResourceId(), new LocalDate(todate),
						new LocalDate(fromDate));
				if (taskList != null) {
					allTaskList.addAll(taskList);
				}
			}
		}

		StringBuffer buffer = new StringBuffer();

		buffer.append("[");
		if (allTaskList != null && allTaskList.size() > 0) {
			for (Task task : allTaskList) {

				buffer.append("{");
				buffer.append("\"taskDate\": \"" + task.getTaskDate() + "\",");
				buffer.append("\"connectorId\": \"" + task.getConnectorId()
						+ "\",");
				buffer.append("\"phase\": \"" + task.getPhase() + "\",");
				buffer.append("\"hoursSpent\": \"" + task.getHoursSpent()
						+ "\",");
				String description = task.getDescription().trim();
				description = description.replace(
						System.getProperty("line.separator"), " ");
				buffer.append("\"description\": \"" + description + "\",");
				Resource subResource = userService.findResourceByID(task
						.getResourceId());
				buffer.append("\"resourceid\": \""
						+ subResource.getResourceId() + "\",");
				buffer.append("\"subResource\": \""
						+ subResource.getFirstName() + " "
						+ subResource.getLastName() + "\",");
				buffer.append("\"taskid\": \"" + task.getId() + "\"");
				buffer.append("},");

			}
			buffer.deleteCharAt(buffer.length() - 1);

		}
		buffer.append("]");
		return buffer.toString();
	}

	@RequestMapping(value = { "/task/edit/{task_id}/{resourceid}" }, method = RequestMethod.GET)
	public String editTask(@PathVariable Integer task_id,
			@PathVariable Integer resourceid, Model model,
			HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		Resource subResource = userService.findResourceByID(resourceid);
		List<Resource> subResources = new ArrayList<>();
		if (subResource == null) {
			return "redirect:/";
		}
		List<Task> taskList = (List<Task>) taskService.findByName(subResource);
		Task task = (Task) taskService.findById(task_id);
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(subResource, task.getTaskDate().toString());
		Map<Integer, String> connectors = new HashMap<Integer, String>();
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			connectors.put(resourceAllocation.getConnectorId(),
					resourceAllocation.getConnectorName());
		}
		model.addAttribute("connectorList", connectors);
		model.addAttribute("action", "Update");
		model.addAttribute("task", task);
		List findByConnectorId = (List) sprintItemService
				.findByConnectorId(service.findById(task.getConnectorId())
						.getConnectorType());
		List<String> phase = new ArrayList<String>();
		for (int i = 0; i < findByConnectorId.size(); i++) {
			if (((String) findByConnectorId.get(i))
					.equals("Integration Testing/Acceptance Testing - Mocha")) {
				phase.add("Integration Testing (Mocha) - TEST CASE CREATION");
				phase.add("Integration Testing (Mocha) - TEST CASE EXECUTION");
			} else {
				phase.add((String) findByConnectorId.get(i));
			}
		}
		phase.add("Build Pipeline IT / UT issues");
		phase.add("Meeting / Co-ordination");
		phase.add("Rework");
		phase.add("Enhancements");
		phase.add("Others");
		List<Resource> subCordinates = userService.findResourcesBYRmId(resource
				.getResourceId());
		model.addAttribute("subCordinates", subCordinates);
		model.addAttribute("phase", phase);
		model.addAttribute("taskList", taskList);
		return "resourceTask";
	}

	@RequestMapping(value = { "/task/delete/{task_id}/{resourceid}" }, method = RequestMethod.GET)
	public String deleteTask(@PathVariable Integer task_id,
			@PathVariable Integer resourceid, Model model,
			HttpServletRequest request) throws Exception {
		HttpSession session = request.getSession();
		Resource resource = (Resource) session.getAttribute("user");
		Resource subResource = userService.findResourceByID(resourceid);
		if (subResource == null) {
			return "redirect:/";
		}
		Object deleteObject = taskService.findById(task_id);
		if (deleteObject != null) {
			taskService.deleteEntity(deleteObject);
		}
		List<Task> taskList = (List<Task>) taskService.findByName(subResource);
		model.addAttribute("action", "Add");
		List<ResourceAllocationLog> connectorList = resourceAllocationReportService
				.findByUser(subResource, LocalDate.now().toString());
		Map<Integer, String> connectors = new HashMap<Integer, String>();
		for (ResourceAllocationLog resourceAllocation : connectorList) {
			connectors.put(resourceAllocation.getConnectorId(),
					resourceAllocation.getConnectorName());
		}
		List<Resource> subCordinates = userService.findResourcesBYRmId(resource
				.getResourceId());
		model.addAttribute("subCordinates", subCordinates);
		model.addAttribute("connectorList", connectors);
		model.addAttribute("task", new Task());
		model.addAttribute("taskList", taskList);
		return "resourceTask";
	}
}
