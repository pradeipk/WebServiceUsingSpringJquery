package com.psl.sprint.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class AbstractDao<PK extends Serializable, T> {

	public final Class<T> persistentClass;

	@SuppressWarnings("unchecked")
	public AbstractDao() {
		this.persistentClass = (Class<T>) ((ParameterizedType) this.getClass()
				.getGenericSuperclass()).getActualTypeArguments()[1];
	}

	@Autowired
	private SessionFactory sessionFactory;

	public Session getSession() throws Exception {
		try {
			return sessionFactory.getCurrentSession();
		} catch (Exception e) {
			throw e;
		}

	}

	/*
	 * Get by Primary Key
	 */
	@SuppressWarnings("unchecked")
	public T getByKey(PK key) throws Exception {
		return (T) getSession().get(persistentClass, key);
	}

	/*
	 * Get all records from a table/entity
	 */
	@SuppressWarnings("unchecked")
	public T getAll() throws Exception {
		return null;
	}

	/*
	 * Save a record
	 */
	public void persist(T entity) throws Exception {
		getSession().persist(entity);

	}

	/*
	 * Update a record
	 */
	public void update(T entity) throws Exception {
		getSession().update(entity);

	}

	/*
	 * Delete a record
	 */
	public void delete(T entity) throws Exception {
		getSession().delete(entity);
	}

	/*
	 * Create criteria to retrieve set of records matching filters or criteria
	 */
	protected Criteria createEntityCriteria() throws Exception {
		return getSession().createCriteria(persistentClass);
	}

}
