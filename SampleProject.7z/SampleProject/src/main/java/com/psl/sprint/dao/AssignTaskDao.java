/**
 * 
 */
package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.AssignTask;

/**
 * @author pradeep_patel
 * 
 */

public interface AssignTaskDao {

	public AssignTask findById(int id) throws Exception ;

	public void saveAssignTask(AssignTask assignTask)throws Exception ;

	public List<AssignTask> findAllAssignTasks()throws Exception ;

	public List<AssignTask> findAllAssignTasksByConnectorId(Integer connectorId)throws Exception ;

}
