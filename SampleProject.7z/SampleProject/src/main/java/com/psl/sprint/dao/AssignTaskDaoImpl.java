/**
 * 
 */
package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.AssignTask;

/**
 * @author pradeep_patel
 *
 */
@Repository("assigntaskdao")
public class AssignTaskDaoImpl extends AbstractDao<Integer, AssignTask> implements AssignTaskDao{

	public AssignTask findById(int id) {
		return null;
	}	
	
	public void saveAssignTask(AssignTask assignTask) throws Exception  {
		persist(assignTask);
		
	}

	@SuppressWarnings("unchecked")
	public List<AssignTask> findAllAssignTasks() throws Exception {
		Criteria criteria = createEntityCriteria();
		return (List<AssignTask>) criteria.list();
		
	}

	@SuppressWarnings("unchecked")
	public List<AssignTask> findAllAssignTasksByConnectorId(Integer connectorId) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connector_id", connectorId));
		return (List<AssignTask>) criteria.list();
	}
}