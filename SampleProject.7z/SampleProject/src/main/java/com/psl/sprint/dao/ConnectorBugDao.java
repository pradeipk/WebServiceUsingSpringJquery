package com.psl.sprint.dao;

import com.psl.sprint.model.ConnectorBug;

public interface ConnectorBugDao extends GenericDao {
	public void delete(Integer connectorId) throws Exception;
	public ConnectorBug findByConnector(Integer connectorId) throws Exception;
}
