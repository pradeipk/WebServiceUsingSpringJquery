package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.ConnectorBug;

@Repository("connectorBugDao")
public class ConnectorBugDaoImpl extends AbstractDao<Integer, ConnectorBug>
		implements ConnectorBugDao {

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((ConnectorBug) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((ConnectorBug) object);
	}

	@Override
	public Object findById(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Integer connectorId) throws Exception {
		Session session = getSession();
		Query query = session
				.createSQLQuery("DELETE from tbl_connector_bug WHERE connector_id = "
						+ connectorId);
		query.executeUpdate();
	}

	@Override
	public ConnectorBug findByConnector(Integer connectorId) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorId", connectorId));
		return (ConnectorBug) criteria.uniqueResult();

	}
}
