package com.psl.sprint.dao;

public interface ConnectorComplexityDao extends GenericDao {
	public void deleteAllByConnectorId(Integer connectorId) throws Exception;
}
