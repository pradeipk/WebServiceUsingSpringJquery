package com.psl.sprint.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.psl.sprint.model.ConnectorComplexity;

@Repository("connectorComplexityDao")
public class ConnectorComplexityDaoImpl extends
		AbstractDao<Integer, ConnectorComplexity> implements
		ConnectorComplexityDao {

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((ConnectorComplexity) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((ConnectorComplexity) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((ConnectorComplexity) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		return null;
	}

	@Override
	public void deleteAllByConnectorId(Integer connectorId) throws Exception {
		//TODO Delete all by Connector Id
	}
}