package com.psl.sprint.dao;

import java.util.List;
import java.util.Map;

import com.psl.sprint.model.Connector;

public interface ConnectorDao {

	public Connector findById(Integer id) throws Exception;

	public void saveConnector(Connector connector) throws Exception;

	public void updateConnector(Connector connector) throws Exception;

	public List<Connector> findAllConnector(Map<String, Object> filter)
			throws Exception;

	public List<Connector> findAllByConnectorName(String connector)
			throws Exception;

	public List<Connector> findAllByConnectorParentId(Integer connectorParentId)
			throws Exception;

	public List<Connector> findEstimatedEffortsParentId(Integer connectorParentId)
			throws Exception;
	
	public List<Integer> findAllConnectorMasters(Map<String, Object> filter)
			throws Exception;

	public List<Connector> findAllConnectorsWithNameLike()
			throws Exception;;

	public Double getTotalPDSUtilized(String connectorName) throws Exception;

	public List<Connector> findAllConnectors() throws Exception;
	
	public List<Integer> findMasterIds(List<Integer> connectorIds) throws Exception;
	
	public List<Integer> findConnectorsByMasterId(Integer masterId) throws Exception;
	

}
