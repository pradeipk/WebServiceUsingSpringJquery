package com.psl.sprint.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.Connector;

@Repository("connectorDao")
public class ConnectorDaoImpl extends AbstractDao<Integer, Connector> implements
		ConnectorDao {

	public Connector findById(Integer id) throws Exception {
		return getByKey(id);
	}

	public void saveConnector(Connector entity) throws Exception {
		persist(entity);
	}

	@SuppressWarnings("unchecked")
	public List<Connector> findAllConnector(Map<String, Object> filter)
			throws Exception {
		Criteria criteria = createEntityCriteria();

		if (filter != null) {
			if (filter.get("status") != null)
				criteria.add(Restrictions.eq("status",
						(String) filter.get("status")));
		}
		criteria.addOrder(Order.asc("name"));
		List<Connector> connectors = (List<Connector>) criteria.list();
		return connectors;
	}

	@SuppressWarnings("unchecked")
	public List<Integer> findAllConnectorMasters(Map<String, Object> filter)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.isNotNull("connectorParentId"));
		criteria.setProjection(Projections.groupProperty("connectorParentId"));

		if (filter != null) {
			filter.get("status");
			criteria.add(Restrictions.eq("status",
					(String) filter.get("status")));
		}
		criteria.addOrder(Order.asc("name"));
		List<Integer> connectors = (List<Integer>) criteria.list();
		return connectors;
	}

	@SuppressWarnings("unchecked")
	public List<Connector> findAllByConnectorName(String connector)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("name", connector));
		criteria.addOrder(Order.asc("name"));
		return (List<Connector>) criteria.list();
	}

	public void updateConnector(Connector connector) throws Exception {
		update(connector);
	}

	@Override
	public List<Connector> findAllByConnectorParentId(Integer connectorParentId)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorParentId", connectorParentId));
		return (List<Connector>) criteria.list();
	}

	@Override
	public List<Connector> findEstimatedEffortsParentId(
			Integer connectorParentId) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorParentId", connectorParentId));
		return (List<Connector>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Connector> findAllConnectorsWithNameLike() throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("status", "Open"));
		criteria.addOrder(Order.asc("name"));
		List<Connector> connectors = (List<Connector>) criteria.list();
		return connectors;
	}

	@Override
	public Double getTotalPDSUtilized(String connectorName) throws Exception {
		// TODO Auto-generated method stub
		String sql = "SELECT sum(bandwidth) AS TotalPDS FROM get_resource_work_detail_view WHERE connector = '"
				+ connectorName + "'";
		Query query = getSession().createSQLQuery(sql);
		return (Double) query.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Connector> findAllConnectors() throws Exception {
		Criteria criteria = createEntityCriteria();
		return (List<Connector>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> findMasterIds(List<Integer> connectorIds)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.in("id", connectorIds));
		criteria.add(Restrictions.eq("status", "Open"));
		criteria.setProjection(Projections.groupProperty("connectorParentId"));
		List<Integer> connectors = (List<Integer>) criteria.list();
		return connectors;

	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Integer> findConnectorsByMasterId(Integer masterId) throws Exception{
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorParentId", masterId));
		criteria.setProjection(Projections.groupProperty("id"));
		criteria.addOrder(Order.asc("name"));
		List<Integer> connectors = (List<Integer>) criteria.list();
		return connectors;

	}
}
