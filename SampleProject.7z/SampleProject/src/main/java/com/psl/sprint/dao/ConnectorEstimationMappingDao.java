package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.ConnectorEstimationMapping;
import com.psl.sprint.model.EstimationHeaderConnector;
import com.psl.sprint.model.EstimationHeaderQuestionConnector;

public interface ConnectorEstimationMappingDao extends GenericDao {	
	public List<ConnectorEstimationMapping> findConnectorEstimationMappingByConnectorId(Integer connectorId) throws Exception;
	public void deleteByConnectorId(Integer connectorId) throws Exception;
	public List<EstimationHeaderConnector> findEstimationHeaderConnectorByConnectorIdAndType(Integer connectorId, String connectorType) throws Exception;
	public List<EstimationHeaderQuestionConnector> findEstimationHeaderQuestionConnectorByConnectorId(Integer connectorId) throws Exception;
    public List<EstimationHeaderQuestionConnector> findEstimationHeaderQuestionConnectorByConnectorIdAndType(Integer connectorId,String connectorType) throws Exception;
    
}
