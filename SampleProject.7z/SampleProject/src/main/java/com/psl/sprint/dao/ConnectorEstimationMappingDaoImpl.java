package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.ConnectorEstimationMapping;
import com.psl.sprint.model.EstimationHeaderConnector;
import com.psl.sprint.model.EstimationHeaderQuestionConnector;

@Repository("connectorEstimationMappingDao")
public class ConnectorEstimationMappingDaoImpl extends
		AbstractDao<Integer, ConnectorEstimationMapping> implements
		ConnectorEstimationMappingDao {

	@Override
	public List<ConnectorEstimationMapping> findConnectorEstimationMappingByConnectorId(
			Integer connectorId) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorId", connectorId));
		return (List<ConnectorEstimationMapping>) criteria.list();
	}

	@Override
	public Object findById(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((ConnectorEstimationMapping) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteByConnectorId(Integer connectorId) throws Exception {
		String sql = "DELETE FROM tbl_connectoretmapping WHERE connector_id = "
				+ connectorId;
		Session session = getSession();
		Query query = session.createSQLQuery(sql);
		query.executeUpdate();
	}

	@Override
	public List<EstimationHeaderConnector> findEstimationHeaderConnectorByConnectorIdAndType(
			Integer connectorId, String connectorType) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT distinct a.id AS hid, b.connector_id AS connectorId, a.SDLCPhaseTask AS header, a.Type AS connectorType ");
		sql.append("FROM tbl_etheaders a, tbl_connectoretmapping b WHERE b.connector_id = "
				+ connectorId + " AND b.hid = a.id ");
		sql.append("AND a.Type = '" + connectorType + "'");
		Session session = getSession();
		Query query = session.createSQLQuery(sql.toString())
				.addScalar("hid", StandardBasicTypes.INTEGER)
				.addScalar("connectorId", StandardBasicTypes.INTEGER)
				.addScalar("header", StandardBasicTypes.STRING)
				.addScalar("connectorType", StandardBasicTypes.STRING);
		query.setResultTransformer(Transformers
				.aliasToBean(EstimationHeaderConnector.class));
		return (List<EstimationHeaderConnector>) query.list();
	}

	@Override
	public List<EstimationHeaderQuestionConnector> findEstimationHeaderQuestionConnectorByConnectorId(
			Integer connectorId) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT a.hid, c.SDLCPhaseTask AS 'header', d.QDesc as 'description', b.Options As 'optionSelected' ");
		sql.append("FROM tbl_connectoretmapping a, tbl_qs b, tbl_etheaders c, tbl_etsubheaders d ");
		sql.append("WHERE a.qid=b.id AND a.hid=c.id AND a.shid = d.id and a.connector_id="
				+ connectorId + " ORDER BY hid");
		Session session = getSession();
		Query query = session.createSQLQuery(sql.toString())
				.addScalar("hid", StandardBasicTypes.INTEGER)
				.addScalar("header", StandardBasicTypes.STRING)
				.addScalar("description", StandardBasicTypes.STRING)
				.addScalar("optionSelected", StandardBasicTypes.STRING);

		query.setResultTransformer(Transformers
				.aliasToBean(EstimationHeaderQuestionConnector.class));
		return (List<EstimationHeaderQuestionConnector>) query.list();
	}


	@Override
	public List<EstimationHeaderQuestionConnector> findEstimationHeaderQuestionConnectorByConnectorIdAndType(
			Integer connectorId,String connectorType) throws Exception {
		StringBuffer sql = new StringBuffer();	
		
		sql.append("SELECT a.hid, c.SDLCPhaseTask AS 'header', d.QDesc AS 'description', b.Options AS 'optionSelected', e.pds AS 'pds' ");
		sql.append("FROM tbl_connectoretmapping a, tbl_qs b, tbl_etheaders c, tbl_etsubheaders d, tbl_connector_complexity e ");
		sql.append("WHERE a.qid=b.id AND a.hid=c.id AND a.shid = d.id AND a.connector_id in(select g.connector_id from tbl_connector g where g.conn_master_id="+connectorId+") AND a.connector_id = e.connector_id AND a.hid = e.hid and c.Type='"+connectorType+"' ");
		sql.append("ORDER BY hid");
		
		Session session = getSession();
		Query query = session.createSQLQuery(sql.toString())
				.addScalar("hid", StandardBasicTypes.INTEGER)
				.addScalar("header", StandardBasicTypes.STRING)
				.addScalar("description", StandardBasicTypes.STRING)
				.addScalar("optionSelected", StandardBasicTypes.STRING)
		        .addScalar("pds", StandardBasicTypes.DOUBLE);  
		query.setResultTransformer(Transformers
				.aliasToBean(EstimationHeaderQuestionConnector.class));
		return (List<EstimationHeaderQuestionConnector>) query.list();
	}
	
}