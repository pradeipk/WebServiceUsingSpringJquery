package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.ConnectorIssue;
import com.psl.sprint.model.ConnectorIssueList;

public interface ConnectorIssueDao {

	public ConnectorIssue findById(Integer id) throws Exception;

	public void saveConnector(ConnectorIssue connectorIssue) throws Exception;

	public void updateConnector(ConnectorIssue connectorIssue) throws Exception;

	public List<ConnectorIssueList> findAllConnectorParentId(Integer connectorParentId, Integer issueType)
			throws Exception;
	
}