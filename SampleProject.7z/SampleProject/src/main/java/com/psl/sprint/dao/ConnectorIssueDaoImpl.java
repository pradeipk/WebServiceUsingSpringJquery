package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.ConnectorIssue;
import com.psl.sprint.model.ConnectorIssueList;

@Repository("connectorIssueDao")
public class ConnectorIssueDaoImpl extends AbstractDao<Integer, ConnectorIssue>
		implements ConnectorIssueDao {

	@Override
	public ConnectorIssue findById(Integer id) throws Exception {
		return getByKey(id);
	}

	@Override
	public void saveConnector(ConnectorIssue connectorIssue) throws Exception {
		persist(connectorIssue);
	}

	@Override
	public void updateConnector(ConnectorIssue connectorIssue) throws Exception {
		update(connectorIssue);
	}

	@Override
	public List<ConnectorIssueList> findAllConnectorParentId(
			Integer connectorParentId, Integer issueType) throws Exception {
		String sql = null;
		if (connectorParentId == null) {
			sql = "SELECT a.issueID AS IssueID, a.issueTitle AS IssueTitle, a.issueDescription AS Description, b.connector_id AS ConnectorId, "
					+ "b.name AS ConnectorName, a.createdDate AS CreatedDate, a.gitIssueLink AS GitIssueLink, a.gitIssueDate AS GitIssueDate "
					+ "FROM tbl_issuetracker a, tbl_connector b, tbl_connector_issue c, tbl_connector_master d "
					+ "WHERE a.issueReason = '" + issueType + "' AND d.connectorMID = b.CONN_MASTER_ID	AND b.CONNECTOR_ID = c.connector_id AND c.issue_id = a.issueID "
					+ "AND a.status in ('Open', 'Deferred') ORDER BY ConnectorId";
		} else {
			sql = "SELECT a.issueID AS IssueID, a.issueTitle AS IssueTitle, a.issueDescription AS Description, b.connector_id AS ConnectorId, "
					+ "b.name AS ConnectorName, a.createdDate AS CreatedDate, a.gitIssueLink AS GitIssueLink, a.gitIssueDate AS GitIssueDate "
					+ "FROM tbl_issuetracker a, tbl_connector b, tbl_connector_issue c, tbl_connector_master d "
					+ "WHERE d.connectorMID = " + connectorParentId + " AND a.issueReason = '" + issueType + "'"
					+ " AND d.connectorMID = b.CONN_MASTER_ID	AND b.CONNECTOR_ID = c.connector_id AND c.issue_id = a.issueID "
					+ "AND a.status in ('Open', 'Deferred')";
		}
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("IssueID", StandardBasicTypes.INTEGER)
				.addScalar("IssueTitle", StandardBasicTypes.STRING)
				.addScalar("GitIssueLink", StandardBasicTypes.STRING)
				.addScalar("CreatedDate", StandardBasicTypes.DATE)
				.addScalar("GitIssueDate", StandardBasicTypes.DATE)
				.addScalar("Description", StandardBasicTypes.STRING)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING);
		query.setResultTransformer(Transformers
				.aliasToBean(ConnectorIssueList.class));
		return (List<ConnectorIssueList>) query.list();
	}
}
