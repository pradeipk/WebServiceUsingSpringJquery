package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.ConnectorLeadMapping;
import com.psl.sprint.model.Resource;

public interface ConnectorLeadMappingDao   extends GenericDao{


	public void saveEntity(ConnectorLeadMapping connectorLeadMapping) throws Exception;

	public List<ConnectorLeadMapping> findMapping() throws Exception;
	
	public Object findById(Integer id) throws Exception ;

	public List<ConnectorLeadMapping> findMappingForRecource(Integer resourceId, String jobAssigned, boolean isjobAssigned) throws Exception;

	public List<ConnectorLeadMapping> findByConnectorIdAndUser(Integer connectorMasterId, Integer resourceId)throws Exception;

	public List<Resource> findLeadsByRole(String roleType,Integer connectorMasterID) throws Exception;

	List<ConnectorLeadMapping> findMappingForRecource(Integer resourceId,
			String jobAssigned, boolean isjobAssigned, boolean isQaResource)
			throws Exception;
}
