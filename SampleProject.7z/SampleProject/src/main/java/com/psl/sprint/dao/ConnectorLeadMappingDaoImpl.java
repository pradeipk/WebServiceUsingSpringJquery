package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorLeadMapping;
import com.psl.sprint.model.Resource;

@Repository("ConnectorLeadMappingDao")
public class ConnectorLeadMappingDaoImpl extends
		AbstractDao<Integer, ConnectorLeadMapping> implements
		ConnectorLeadMappingDao {

	@Override
	public void saveEntity(ConnectorLeadMapping connectorLeadMapping)
			throws Exception {
		persist(connectorLeadMapping);

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ConnectorLeadMapping> findMapping() throws Exception {
		Criteria criteria = createEntityCriteria();
		return criteria.list();

	}

	@Override
	public Object findById(Object object) throws Exception {
		// TODO Auto-generated method stub
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object findById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return getByKey(id);
	}

	@Override
	public List<ConnectorLeadMapping> findMappingForRecource(
			Integer resourceId, String jobAssigned, boolean isjobAssigned)
			throws Exception {
		// TODO Auto-generated method stub

		String sql = "SELECT recources.* FROM tbl_connector_lead_mapping  recources ";
		sql += " WHERE recources.dev_resource_id = ";
		sql += +resourceId;
		sql += " or  recources.qa_resource_id = ";
		sql += resourceId;
		if (isjobAssigned) {
			sql += " or  recources.admin = '" + jobAssigned + "'";
		}
		Session session = getSession();
		Query query = session.createSQLQuery(sql).addEntity(
				ConnectorLeadMapping.class);
		return query.list();
	}

	@Override
	public List<ConnectorLeadMapping> findByConnectorIdAndUser(
			Integer connectorMasterId, Integer resourceId) throws Exception {
		// TODO Auto-generated method stub

		String sql = "SELECT recources.* FROM tbl_connector_lead_mapping  recources ";
		sql += " WHERE ( recources.dev_resource_id = ";
		sql += +resourceId;
		sql += " or  recources.qa_resource_id = ";
		sql += resourceId;

		sql += " ) and   recources.connector_id = " + connectorMasterId + "";

		Session session = getSession();
		Query query = session.createSQLQuery(sql).addEntity(
				ConnectorLeadMapping.class);
		return query.list();
	}

	@Override
	public List<ConnectorLeadMapping> findMappingForRecource(
			Integer resourceId, String jobAssigned, boolean isjobAssigned,
			boolean isQaResource) throws Exception {
		// TODO Auto-generated method stub

		String sql = "SELECT recources.* FROM tbl_connector_lead_mapping  recources ";
		sql += " WHERE ";
		if (isQaResource) {
			sql += " recources.qa_resource_id = ";
		} else {
			sql += "recources.dev_resource_id = ";
		}
		sql += +resourceId;

		if (isjobAssigned) {
			sql += " or  recources.admin = '" + jobAssigned + "'";
		}
		Session session = getSession();
		Query query = session.createSQLQuery(sql).addEntity(
				ConnectorLeadMapping.class);
		return query.list();
	}

	@Override
	public List<Resource> findLeadsByRole(String roleType, Integer connId)
			throws Exception {

		String sql = "SELECT RESOURCE.* FROM tbl_resource  RESOURCE ";
		sql += "where RESOURCE.RESOURCE_ID in (Select ";
		if (roleType.equalsIgnoreCase("pslSME")) {
			sql += "sme_Id";
		}
		if (roleType.equalsIgnoreCase("devLead")) {
			sql += "dev_resource_id";
		}
		if (roleType.equalsIgnoreCase("qaLead")) {
			sql += "qa_resource_id";
		}
		sql += " from tbl_connector_lead_mapping where connector_id in ";
		sql += "(Select CONNECTOR_ID from tbl_connector where CONN_MASTER_ID='";
		sql += connId + "') group by sme_id)";

		Session session = getSession();
		Query query = session.createSQLQuery(sql).addEntity(Resource.class);
		return query.list();

	}
}
