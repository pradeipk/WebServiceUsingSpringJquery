package com.psl.sprint.dao;

import java.util.List;
import java.util.Map;

import com.psl.sprint.model.ConnectorMaster;

public interface ConnectorMasterDao extends GenericDao {

	public List<ConnectorMaster> findAllConnector(Map<String, Object> filter)
			throws Exception;
	
	public ConnectorMaster findByIdConnMaster(Integer id) throws Exception;
	
	public List<ConnectorMaster> findAllConnectorMaster() throws Exception;
	
}
