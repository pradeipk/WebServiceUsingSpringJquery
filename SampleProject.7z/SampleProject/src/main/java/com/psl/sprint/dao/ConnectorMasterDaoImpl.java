package com.psl.sprint.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.ConnectorLeadMapping;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.service.ConnectorLeadMappingService;
import com.psl.sprint.service.ConnectorService;
import com.psl.sprint.util.SprintConstants;

@Repository("connectorMasterDao")
public class ConnectorMasterDaoImpl extends AbstractDao<Integer, ConnectorMaster>
		implements ConnectorMasterDao {

	@Autowired
	private ConnectorService service;
	
	@Autowired
	private ConnectorLeadMappingService leadMapService;
	
	@Override
	public void saveEntity(Object object) throws Exception {
		persist((ConnectorMaster) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((ConnectorMaster) object);
	}

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer)object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((ConnectorMaster) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorStatus", new Integer(1)));
		return criteria.list();
	}
	
	@SuppressWarnings("unchecked")
	public List<ConnectorMaster> findAllConnector(Map<String, Object> filter) throws Exception {
		List<Integer> connectorsChilds;
		int leadID=Integer.parseInt(filter.get("leadID").toString());
		
		List<ConnectorLeadMapping> connectorLeadMappings = leadMapService.findMappingForRecource(leadID,"Others", false);		
		List<Integer> connByLeads = new ArrayList<Integer>();
		if (connectorLeadMappings != null && connectorLeadMappings.size() > 0) {
			for (ConnectorLeadMapping connectorLeadMapping : connectorLeadMappings) {
				connByLeads.add(connectorLeadMapping.getConnector().getId());				
			}			
		}

		if(leadID!=SprintConstants.MASTER_ACCESS_RES_ID_1)		
			connectorsChilds = service.findMasterIds(connByLeads);
		else		
		connectorsChilds = service.findAllConnectorMasters(filter);
		
		Criteria criteria = createEntityCriteria();		
		criteria.addOrder(Order.asc("connectorName"));
		criteria.add(Restrictions.in("id", connectorsChilds));		
		List<ConnectorMaster> connectorMaster = (List<ConnectorMaster>) criteria.list();
		
		return connectorMaster;
	}

	@Override
	public ConnectorMaster findByIdConnMaster(Integer id) throws Exception {
		return getByKey(id);
	}

	@Override
	public List<ConnectorMaster> findAllConnectorMaster() throws Exception {

		Criteria criteria = createEntityCriteria();
		return (List<ConnectorMaster>) criteria.list();
	}
}
