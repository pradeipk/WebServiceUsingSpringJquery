package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.EffortsEstimationMaster;

public interface EffortsEstimationMasterDao extends GenericDao {
	public List<EffortsEstimationMaster> findByVersionAndType(String version, String connectorType) throws Exception;
}
