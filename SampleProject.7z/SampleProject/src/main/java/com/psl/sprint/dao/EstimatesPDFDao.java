package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.EstimatesPDF;

public interface EstimatesPDFDao {
	public EstimatesPDF findByConnectorId(Integer id) throws Exception ;
	public void save(EstimatesPDF estimatesPDF) throws Exception ;
	public void update(EstimatesPDF estimatesPDF) throws Exception ;
	public List<EstimatesPDF> findAll() throws Exception;
	public EstimatesPDF findByFileName(String fileName, String fieldName) throws Exception ;
}
