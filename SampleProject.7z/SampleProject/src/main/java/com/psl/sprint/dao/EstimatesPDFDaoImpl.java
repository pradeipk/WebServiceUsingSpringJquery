package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.EstimatesPDF;

@Repository("estimatesPdfDao")
public class EstimatesPDFDaoImpl extends AbstractDao<Integer, EstimatesPDF>
		implements EstimatesPDFDao {

	@Override
	public EstimatesPDF findByConnectorId(Integer connectorId) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorId", connectorId));
		return (EstimatesPDF) criteria.uniqueResult();
	}

	@Override
	public void save(EstimatesPDF estimatesPdf) throws Exception {
		persist(estimatesPdf);
	}

	@Override
	public void update(EstimatesPDF estimatesPdf) throws Exception {
		update(estimatesPdf);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EstimatesPDF> findAll() throws Exception {
		Criteria criteria = createEntityCriteria();
		return (List<EstimatesPDF>) criteria.list();
	}

	@Override
	public EstimatesPDF findByFileName(String fileName, String fieldName) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq(fieldName, fileName));
		return (EstimatesPDF) criteria.uniqueResult();
	}
}