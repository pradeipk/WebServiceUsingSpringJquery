package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.EstimationHeaders;

public interface EstimationHeadersDao extends GenericDao {
	
	public List<EstimationHeaders> findByType(String connectorType, String version) throws Exception;

}
