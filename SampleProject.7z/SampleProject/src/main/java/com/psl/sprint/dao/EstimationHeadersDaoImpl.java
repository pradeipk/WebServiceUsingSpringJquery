package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.EstimationHeaders;

@Repository("estimatesHeaderDao")
public class EstimationHeadersDaoImpl extends AbstractDao<Integer, EstimationHeaders> implements EstimationHeadersDao {

	@Override
	public List<EstimationHeaders> findByType(String connectorType, String version)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("Type", connectorType));
		criteria.add(Restrictions.eq("TemplateVersion", version));
		return (List<EstimationHeaders>)criteria.list();
	}

	@Override
	public Object findById(Object object) throws Exception {
		// TODO Auto-generated method stub
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
