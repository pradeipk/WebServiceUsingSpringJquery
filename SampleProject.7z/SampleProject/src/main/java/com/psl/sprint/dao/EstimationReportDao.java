package com.psl.sprint.dao;

import com.psl.sprint.model.EstimationReport;

public interface EstimationReportDao {
	public void saveEstimationReport(EstimationReport estimationReport) throws Exception;
}
