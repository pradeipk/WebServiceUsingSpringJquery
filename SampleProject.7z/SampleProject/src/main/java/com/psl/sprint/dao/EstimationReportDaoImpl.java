package com.psl.sprint.dao;


import org.springframework.stereotype.Repository;

import com.psl.sprint.model.EstimationReport;


@Repository("estimationReportDao")
public class EstimationReportDaoImpl extends AbstractDao<Integer, EstimationReport> implements EstimationReportDao{

	@Override
	public void saveEstimationReport(EstimationReport estimationReport)
			throws Exception {
		persist(estimationReport);
		
	}

}
