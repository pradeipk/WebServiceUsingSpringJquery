package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.EstimationSubHeaders;

@Repository("estimationSubHeaderDao")
public class EstimationSubHeadersDaoImpl extends AbstractDao<Integer, EstimationSubHeaders> implements EstimationSubHeadersDao {
	
	@Override
	public List<EstimationSubHeaders> findByHeaderId(Integer hid)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("hid", hid));
		return (List<EstimationSubHeaders>)criteria.list();
	}

	@Override
	public Object findById(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
