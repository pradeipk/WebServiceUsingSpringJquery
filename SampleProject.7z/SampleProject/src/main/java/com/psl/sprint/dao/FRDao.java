package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.FunctionalRequrement;

public interface FRDao {
	
	public FunctionalRequrement findById(Integer id)throws Exception ;

	public void saveFR(FunctionalRequrement functionalRequrement)throws Exception ;
	public void updateFR(FunctionalRequrement functionalRequrement)throws Exception ;
	
	public List<FunctionalRequrement> findAllRequirements()throws Exception ;
}
