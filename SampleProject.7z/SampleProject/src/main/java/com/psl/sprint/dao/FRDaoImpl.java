package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.FunctionalRequrement;

@Repository("frDao")
public class FRDaoImpl extends AbstractDao<Integer, FunctionalRequrement> implements FRDao {

	public void saveFR(FunctionalRequrement entity)throws Exception  {
		persist(entity);
	}

	public List<FunctionalRequrement> findAllRequirements() throws Exception {
		Criteria criteria = createEntityCriteria();
		return criteria.list();
	}

	public FunctionalRequrement findById(Integer id) throws Exception {
		return getByKey(id);
	}

	@Override
	public void updateFR(FunctionalRequrement functionalRequrement) throws Exception {
		update(functionalRequrement);
	}

}
