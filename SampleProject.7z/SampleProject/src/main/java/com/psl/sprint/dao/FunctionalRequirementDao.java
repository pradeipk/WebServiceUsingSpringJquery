package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.Connector;
import com.psl.sprint.model.FunctionalRequrement;

public interface FunctionalRequirementDao {
	
	public FunctionalRequrement findById(Integer iD) throws Exception;
	
	public FunctionalRequrement findByUniqueName(String name) throws Exception;

	public List<FunctionalRequrement> findByRequirementNameAndConnectorName(String requirementName, Connector connector) throws Exception;

}
