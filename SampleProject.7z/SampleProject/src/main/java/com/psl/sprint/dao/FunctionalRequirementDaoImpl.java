package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.Connector;
import com.psl.sprint.model.FunctionalRequrement;

@Repository("functionalRequirementDaoImpl")
public class FunctionalRequirementDaoImpl extends AbstractDao<Integer, FunctionalRequrement> implements
		FunctionalRequirementDao {

	@Override
	public FunctionalRequrement findById(Integer iD) throws Exception {
		return getByKey(iD);
	}

	@Override
	public FunctionalRequrement findByUniqueName(String name) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("uniqueId", name));
		List<FunctionalRequrement> functionalRequrements = (List<FunctionalRequrement>) criteria.list();
		if (functionalRequrements.isEmpty()) {
			return null;
		}
		return functionalRequrements.get(0);
	}

	@Override
	public List<FunctionalRequrement> findByRequirementNameAndConnectorName(String requirementName, Connector connector)
			throws Exception {

		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("requirement", requirementName)).add(Restrictions.eq("connector", connector));
		List<FunctionalRequrement> functionalRequrements = (List<FunctionalRequrement>) criteria.list();
		return functionalRequrements;
	}

}
