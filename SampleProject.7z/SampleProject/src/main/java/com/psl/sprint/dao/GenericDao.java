package com.psl.sprint.dao;

import java.util.List;

public interface GenericDao {

	public static final String NAME = "name";
	
	public Object findById(Object object) throws Exception;

	public List<?> findByName(Object object) throws Exception;

	public void saveEntity(Object object) throws Exception;

	public void updateEntity(Object object) throws Exception;

	public void deleteEntity(Object object) throws Exception;

	public List<?> findAll() throws Exception;

}
