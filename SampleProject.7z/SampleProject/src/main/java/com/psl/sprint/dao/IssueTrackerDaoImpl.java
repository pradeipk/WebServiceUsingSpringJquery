package com.psl.sprint.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.IssueTracker;

@Repository("issueTrackerDao")
public class IssueTrackerDaoImpl extends AbstractDao<Integer, IssueTracker>
		implements IssueTrackerDao {

	public IssueTracker findById(Integer id) throws Exception {
		return getByKey(id);
	}

	@Override
	public void saveIssue(IssueTracker issueTracker) throws Exception {
		persist(issueTracker);
	}

	@Override
	public void updateIssue(IssueTracker issueTracker) throws Exception {
		update(issueTracker);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<IssueTracker> findAllIssues(Map<String, Object> filter)
			throws Exception {
		Criteria criteria = createEntityCriteria();

		if (filter != null) {
			if (filter.get("status") != null)
				criteria.add(Restrictions.eq("status",
						(String) filter.get("status")));
			if (filter.get("issueReason") != null)
				criteria.add(Restrictions.eq("issueReason",
						(Integer) filter.get("issueReason")));
			if (filter.get("issueId") != null)
				criteria.add(Restrictions.eq("issueID",
						(Integer) filter.get("issueId")));
		}
		criteria.addOrder(Order.asc("createdDate"));
		List<IssueTracker> issues = (List<IssueTracker>) criteria.list();
		return issues;
	}

}
