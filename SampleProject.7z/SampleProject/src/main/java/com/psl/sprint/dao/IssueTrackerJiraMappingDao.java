package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.IssueTrackerJiraMapping;

public interface IssueTrackerJiraMappingDao {

	public void save(IssueTrackerJiraMapping issueTrackerJiraMapping) throws Exception;
	public List<?> findAll() throws Exception ;

}
