package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.IssueTrackerJiraMapping;

@Repository("issueTrackerJiraMappingDa")
public class IssueTrackerJiraMappingDaoImpl extends AbstractDao<Integer,IssueTrackerJiraMapping> implements IssueTrackerJiraMappingDao{

	@Override
	public void save(IssueTrackerJiraMapping entity) throws Exception {
		persist(entity);
	}

	@Override
	public List<?> findAll() throws Exception {
		Criteria criteria = createEntityCriteria();
		List<IssueTrackerJiraMapping> list=criteria.list();
		return list;
	}



}
