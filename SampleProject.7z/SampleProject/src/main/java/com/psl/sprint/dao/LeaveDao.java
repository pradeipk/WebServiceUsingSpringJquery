package com.psl.sprint.dao;

import java.util.List;

import org.joda.time.LocalDate;

import com.psl.sprint.model.Leave;

public interface LeaveDao extends GenericDao{
	public List<Leave> findByResourceId(int id) throws Exception;
	//public Double getTotalPercentage(Integer resourceId, String workDate) throws Exception;
	public Leave isPublicLeave(LocalDate date) throws Exception;
}
