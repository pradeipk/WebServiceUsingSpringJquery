package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.Leave;

@Repository("leaveDao")
public class LeaveDaoImpl extends AbstractDao<Integer, Leave> implements
		LeaveDao {

	@Override
	public List<?> findByName(Object object) throws Exception {
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((Leave) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((Leave) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((Leave) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		return null;
	}

	@Override
	public List<Leave> findByResourceId(int id) throws Exception {
		Criteria criteria = createEntityCriteria();
		Criterion restriction = Restrictions.or(
				Restrictions.eq("resourceId", id),
				Restrictions.eq("resourceId", 0));
		criteria.add(restriction);
		criteria.addOrder(Order.asc("startDate"));
		return (List<Leave>) criteria.list();
	}

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	/*@Override
	public Double getTotalPercentage(Integer resourceId, String workDate)
			throws Exception {
		String sql = "SELECT sum(PERCENTAGE) AS Percentage FROM tbl_leave WHERE resource_id = " + resourceId
				+ " AND START_DATE <= '" + workDate + "' AND END_DATE >= '" + workDate + "' AND (ADJUST IS NULL OR ADJUST = 1)";
		Query query = getSession().createSQLQuery(sql);
		return (Double)query.uniqueResult();
	}*/

	@Override
	public Leave isPublicLeave(LocalDate date) throws Exception {
		Criteria criteria = createEntityCriteria();
		Criterion restriction = Restrictions.and(
				Restrictions.eq("startDate", date),
				Restrictions.eq("endDate", date),
				Restrictions.eq("resourceId", 0));
		criteria.add(restriction);
		return (Leave) criteria.uniqueResult();
	}
}