package com.psl.sprint.dao;

import com.psl.sprint.model.MasterTable;

public interface MasterDao extends GenericDao{

	public MasterTable findUniqueRecordByName(Object object) throws Exception ;
}
