package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.MasterTable;

@Repository("masterDaoImpl")
public class MasterDaoImpl extends AbstractDao<Integer, MasterTable>  implements MasterDao {

	@Override
	public Object findById(Object object) throws Exception {
		return null;
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		return null;
		
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MasterTable findUniqueRecordByName(Object object) throws Exception {
		try {
			Criteria crit = createEntityCriteria();
			crit.add(Restrictions.eq("name", (String)object));
			List<MasterTable> mt = (List<MasterTable>) crit.list();
			if (mt==null||mt.isEmpty()||mt.size()>1){
				throw new Exception("More than one record exists for freeze time");
			}
		return 	mt.get(0);
		} catch (Exception e) {
			throw e;
		}	
	}

}
