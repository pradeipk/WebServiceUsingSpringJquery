package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DateType;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.ConnectorPlannedCompletion;
import com.psl.sprint.model.Notes;

@Repository("notesDao")
public class NotesDaoImpl extends AbstractDao<Integer, Notes> implements
		NotesDao {

	@Override
	public List<?> findByName(Object object) throws Exception {
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((Notes) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((Notes) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((Notes) object);
	}

	@Override
	public List<Notes> findAll() throws Exception {
		Session session = getSession();
		Query query = session
				.createSQLQuery(
						"SELECT id as Id, notes as Notes, connector_id as ConnectorId, planned_completion_date as PlannedCompletionDate, actual_completion_date as ActualCompletionDate from tbl_connector_notes")
				.addScalar("Id", StandardBasicTypes.INTEGER)
				.addScalar("Notes", StandardBasicTypes.STRING)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("PlannedCompletionDate", StandardBasicTypes.DATE)
				.addScalar("ActualCompletionDate", StandardBasicTypes.DATE);
		query.setResultTransformer(Transformers.aliasToBean(Notes.class));
		return (List<Notes>) query.list();
	}

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public Notes findByConnectorId(Integer connectorId) throws Exception {
		Session session = getSession();
		Query query = session
				.createSQLQuery(
						"SELECT id as Id, notes as Notes, connector_id as ConnectorId,planned_completion_date as PlannedCompletionDate,actual_completion_date as ActualCompletionDate from tbl_connector_notes where connector_id="
								+ connectorId)
				.addScalar("Id", StandardBasicTypes.INTEGER)
				.addScalar("Notes", StandardBasicTypes.STRING)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("PlannedCompletionDate", StandardBasicTypes.DATE)
				.addScalar("ActualCompletionDate", StandardBasicTypes.DATE);
		query.setResultTransformer(Transformers.aliasToBean(Notes.class));
		return (Notes) query.uniqueResult();
	}

	private void addScalar(String string, DateType date) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ConnectorPlannedCompletion> findPlannedConnectorByDateOrMonth(
			String fromDate, String toDate, String monthYear,
			String comparisonType) throws Exception {
		Session session = getSession();
		String sql = null;
		if (comparisonType.equals("DATE")) {
			sql = "SELECT"
					+ " tbl_connector_notes.connector_id as ConnectorId, tbl_connector.NAME as ConnectorName,"
					+ " tbl_connector_notes.planned_completion_date as PlannedCompletionDate, tbl_connector_notes.notes as Notes"
					+ " FROM sprint.tbl_connector_notes,sprint.tbl_connector where tbl_connector_notes.connector_id = tbl_connector.connector_id"
					+ " AND tbl_connector_notes.planned_completion_date between '"
					+ fromDate + "' AND '" + toDate + "'";
		} else {
			int month = Integer.parseInt(monthYear.split("-")[1]);
			int year = Integer.parseInt(monthYear.split("-")[0]);
			sql = "SELECT"
					+ " tbl_connector_notes.connector_id as ConnectorId, tbl_connector.NAME as ConnectorName,"
					+ " tbl_connector_notes.planned_completion_date as PlannedCompletionDate, tbl_connector_notes.notes as Notes"
					+ " FROM sprint.tbl_connector_notes,sprint.tbl_connector where tbl_connector_notes.connector_id = tbl_connector.connector_id"
					+ " AND MONTH(tbl_connector_notes.planned_completion_date) = "
					+ month
					+ " AND YEAR(tbl_connector_notes.planned_completion_date) = "
					+ year;
		}
		Query query = session.createSQLQuery(sql)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("Notes", StandardBasicTypes.STRING)
				.addScalar("PlannedCompletionDate", StandardBasicTypes.DATE);
		query.setResultTransformer(Transformers
				.aliasToBean(ConnectorPlannedCompletion.class));
		return (List<ConnectorPlannedCompletion>) query.list();
	}
}