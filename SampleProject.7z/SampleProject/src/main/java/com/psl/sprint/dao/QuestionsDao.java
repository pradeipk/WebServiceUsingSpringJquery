package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.Questions;

public interface QuestionsDao extends GenericDao {
	public List<Questions> findByHeaderIdAndSubHeaderId(Integer hid, Integer shid) throws Exception;
}
