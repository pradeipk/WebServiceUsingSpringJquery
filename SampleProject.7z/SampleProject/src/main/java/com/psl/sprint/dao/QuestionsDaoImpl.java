package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.Questions;

@Repository("questionsDao")
public class QuestionsDaoImpl extends AbstractDao<Integer, Questions> implements QuestionsDao {

	@Override
	public List<Questions> findByHeaderIdAndSubHeaderId(Integer hid,
			Integer shid) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("hid", hid));
		criteria.add(Restrictions.eq("shid", shid));
		return (List<Questions>)criteria.list();
	}

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		saveEntity((Questions) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		updateEntity((Questions) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((Questions) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
