package com.psl.sprint.dao;

import java.util.List;
import java.util.Map;

import com.psl.sprint.dto.ReportDTO;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.model.TemporaryResults;

public interface ResourceAllocationReportDao {

	public List<ReportDTO> getResourceAllocationData(int resourceId,
			String startDate, String endDate) throws Exception;

	public List<ReportDTO> getResourceAllocationDataForAssignWork(
			int resourceId, String startDate, String endDate) throws Exception;

	public ResourceAllocationLog findById(Integer Id) throws Exception;

	public void updateAllocation(ResourceAllocationLog allocationLog)
			throws Exception;

	public List<ReportDTO> getResourceUnallocationData(Integer resourceId,
			String startDate, String endDate) throws Exception;

	public List<ReportDTO> getResourceAllocationForProject(int connectorId)
			throws Exception;

	public Map<String, Object> findMinimaOfAllAllocationsForAResourceForAConnectorForADateRange(
			String connectorName, int resourceId, String startDate,
			String endDate) throws Exception;

	public List<ResourceAllocationLog> findByUser(Resource resource, String date)
			throws Exception;

	public List<TemporaryResults> findByStartDateAndEndDate(String startDate,
			String endDate, String connectorName) throws Exception;

	public List<ResourceAllocationLog> findByUserStartDate(
			Resource subResource, String date) throws Exception;

}
