package com.psl.sprint.dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Repository;

import com.psl.sprint.dto.ReportDTO;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.model.TemporaryResults;

@Repository("resourceAllocationReportDao")
public class ResourceAllocationReportDaoImpl extends
		AbstractDao<Integer, ResourceAllocationLog> implements
		ResourceAllocationReportDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<ReportDTO> getResourceAllocationData(int resourceId,
			String startDate, String endDate) throws Exception {
		Session session = getSession();
		Query callStoredProcedureQuery = session
				.createSQLQuery(
						"CALL get_resource_allocation_data_with_leave_procedure(:param1,:param2,:param3)")
				.addScalar("workdate", StandardBasicTypes.STRING)
				.addScalar("userName", StandardBasicTypes.STRING)
				.addScalar("connector", StandardBasicTypes.STRING)
				.addScalar("bandwidthConcat", StandardBasicTypes.STRING)
				.addScalar("bandwidth", StandardBasicTypes.DOUBLE)
				.addScalar("type", StandardBasicTypes.STRING)
				.addScalar("unallocated", StandardBasicTypes.DOUBLE);
		callStoredProcedureQuery.setInteger("param1", resourceId);
		callStoredProcedureQuery.setString("param2", startDate);
		callStoredProcedureQuery.setString("param3", endDate);

		callStoredProcedureQuery.setResultTransformer(Transformers
				.aliasToBean(ReportDTO.class));

		List<ReportDTO> reportDataList = callStoredProcedureQuery.list();
		return reportDataList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ReportDTO> getResourceAllocationDataForAssignWork(
			int resourceId, String startDate, String endDate) throws Exception {
		Session session = getSession();
		Query callStoredProcedureQuery = session
				.createSQLQuery(
						"CALL get_resource_allocation_data_procedure(:param1,:param2,:param3)")
				.addScalar("workdate", StandardBasicTypes.STRING)
				.addScalar("userName", StandardBasicTypes.STRING)
				.addScalar("connector", StandardBasicTypes.STRING)
				.addScalar("bandwidthConcat", StandardBasicTypes.STRING)
				.addScalar("bandwidth", StandardBasicTypes.DOUBLE)
				.addScalar("unallocated", StandardBasicTypes.DOUBLE);
		callStoredProcedureQuery.setInteger("param1", resourceId);
		callStoredProcedureQuery.setString("param2", startDate);
		callStoredProcedureQuery.setString("param3", endDate);

		callStoredProcedureQuery.setResultTransformer(Transformers
				.aliasToBean(ReportDTO.class));

		List<ReportDTO> reportDataList = callStoredProcedureQuery.list();
		return reportDataList;
	}

	@Override
	public ResourceAllocationLog findById(Integer id) throws Exception {
		return getByKey(id);
	}

	@Override
	public void updateAllocation(ResourceAllocationLog allocationLog)
			throws Exception {
		update(allocationLog);
	}

	@Override
	public List<ReportDTO> getResourceUnallocationData(Integer resourceId,
			String startDate, String endDate) throws Exception {
		Session session = getSession();
		Query callStoredProcedureQuery = session
				.createSQLQuery(
						"CALL get_resource_unallocation_data_procedure_with_leave(:param1,:param2,:param3)")
				.addScalar("workdate", StandardBasicTypes.STRING)
				.addScalar("userName", StandardBasicTypes.STRING)
				.addScalar("connector", StandardBasicTypes.STRING)
				.addScalar("bandwidthConcat", StandardBasicTypes.STRING)
				.addScalar("bandwidth", StandardBasicTypes.DOUBLE)
				.addScalar("unallocated", StandardBasicTypes.DOUBLE);
		// resource id
		callStoredProcedureQuery.setInteger("param1", resourceId);
		callStoredProcedureQuery.setString("param2", startDate);
		callStoredProcedureQuery.setString("param3", endDate);

		callStoredProcedureQuery.setResultTransformer(Transformers
				.aliasToBean(ReportDTO.class));

		List<ReportDTO> reportDataList = callStoredProcedureQuery.list();
		return reportDataList;
	}

	@Override
	public List<ReportDTO> getResourceAllocationForProject(int connectorId)
			throws Exception {

		Session session = getSession();
		Query query = session
				.createSQLQuery(
						"SELECT CONNECTOR_NAME AS connector, START_DATE AS startDate, END_DATE AS endDate, USER_NAME AS userName, BANDWIDTH AS bandwidth  FROM search_resource_by_month_vw WHERE CONNECTOR_ID="
								+ connectorId
								+ " ORDER BY USER_NAME,START_DATE")

				.addScalar("userName", StandardBasicTypes.STRING)
				.addScalar("connector", StandardBasicTypes.STRING)
				.addScalar("bandwidth", StandardBasicTypes.DOUBLE)
				.addScalar("startDate", StandardBasicTypes.STRING)
				.addScalar("endDate", StandardBasicTypes.STRING);

		query.setResultTransformer(Transformers.aliasToBean(ReportDTO.class));

		List<ReportDTO> reportDataList = query.list();
		return reportDataList;

	}

	@Override
	public Map<String, Object> findMinimaOfAllAllocationsForAResourceForAConnectorForADateRange(
			String connectorName, int resourceId, String startDate,
			String endDate) throws Exception {

		Session session = getSession();
		Query callStoredProcedureQuery = session
				.createSQLQuery(
						"CALL procedure_max_allocation_for_connector_for_date_range(:param1,:param2,:param3,:param4)")
				.addScalar("dayNumber", StandardBasicTypes.INTEGER)
				.addScalar("day", StandardBasicTypes.STRING)
				.addScalar("userName", StandardBasicTypes.STRING)
				.addScalar("connector", StandardBasicTypes.STRING)
				.addScalar("bandwidthConcat", StandardBasicTypes.STRING)
				.addScalar("bandwidth", StandardBasicTypes.DOUBLE);

		callStoredProcedureQuery.setInteger("param1", resourceId);
		callStoredProcedureQuery.setString("param2", connectorName);
		callStoredProcedureQuery.setString("param3", startDate);
		callStoredProcedureQuery.setString("param4", endDate);
		callStoredProcedureQuery.setResultTransformer(Transformers
				.aliasToBean(ReportDTO.class));
		List<ReportDTO> reportDataList = callStoredProcedureQuery.list();

		Set<Double> allocations = new HashSet<Double>();

		for (ReportDTO reportDTO : reportDataList) {
			if (reportDTO.getBandwidth() != 0.0) {
				allocations.add(reportDTO.getBandwidth());
			}

		}
		// find minima of all llocations;
		Double d = null;
		if (!allocations.isEmpty()) {
			d = Collections.min(allocations);
		}

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("minAllocation", d);
		return map;
	}

	@Override
	public List<ResourceAllocationLog> findByUser(Resource resource, String date)
			throws Exception {
		LocalDate today = new LocalDate(date).minusDays(2);
		Criteria criteria = createEntityCriteria();
		Criterion resourceId = Restrictions.eq("resource", resource);
		Criterion endDate = Restrictions.ge("endDate", today);
		LogicalExpression andExp = Restrictions.and(resourceId, endDate);
		criteria.add(andExp);
		return criteria.list();
	}

	@Override
	public List<TemporaryResults> findByStartDateAndEndDate(String startDate,
			String endDate, String connectorName) throws Exception {
		Session session = getSession();
		Query callStoredProcedureQuery = session
				.createSQLQuery(
						"CALL GetPDsForConnector(:param1, :param2, :param3)")
				.addScalar("connector_id", StandardBasicTypes.INTEGER)
				.addScalar("connector_name", StandardBasicTypes.STRING)
				.addScalar("adjust_day", StandardBasicTypes.DOUBLE);
		callStoredProcedureQuery.setString("param1", startDate);
		callStoredProcedureQuery.setString("param2", endDate);
		if (connectorName == null) {
			callStoredProcedureQuery.setString("param3", "");
		} else {
			callStoredProcedureQuery.setString("param3", connectorName);
		}
		callStoredProcedureQuery.setResultTransformer(Transformers
				.aliasToBean(TemporaryResults.class));
		return callStoredProcedureQuery.list();
	}

	@Override
	public List<ResourceAllocationLog> findByUserStartDate(
			Resource subResource, String date) throws Exception {
		// TODO Auto-generated method stub
		LocalDate today = new LocalDate(date);
		Criteria criteria = createEntityCriteria();
		Criterion resourceId = Restrictions.eq("resource", subResource);
		Criterion endDate = Restrictions.ge("startDate", today);
		LogicalExpression andExp = Restrictions.and(resourceId, endDate);
		criteria.add(andExp);
		return criteria.list();
	}
}