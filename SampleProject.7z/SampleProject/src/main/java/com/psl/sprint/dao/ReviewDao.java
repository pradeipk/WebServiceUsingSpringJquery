package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.Review;
import com.psl.sprint.model.ReviewUI;

public interface ReviewDao extends GenericDao {

	// public List<ReviewPhase> getAllReviewPhases(Map<String, Object> filter)
	// throws Exception;

	// public List<ReviewPhase> getAllReviewPhases() throws Exception;

	// public ReviewPhase findReviewPhaseByID(Integer id) throws Exception;

	public void saveReview(Review review) throws Exception;

	public List<ReviewUI> getAllReviews() throws Exception;

	public List<ReviewUI> getReview() throws Exception;

	public List<ReviewUI> getReviewForConnector(Integer connectorMID) throws Exception;
	
	public Review findReviewById(Integer reviewId) throws Exception;
	
	public void updateReview(Review review) throws Exception;
	
	public void deleteReview(Integer reviewId) throws Exception;

}
