package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.Review;
import com.psl.sprint.model.ReviewUI;
import com.psl.sprint.service.ConnectorService;

@Repository("reviewDao")
public class ReviewDaoImpl extends AbstractDao<Integer, Review> implements
		ReviewDao {

	@Autowired
	private ConnectorService service;

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((Review) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((Review) object);
	}

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((Review) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorStatus", new Integer(1)));
		return criteria.list();
	}

	@Override
	public void saveReview(Review review) throws Exception {
		persist(review);
	}

	@Override
	public List<ReviewUI> getAllReviews() throws Exception {
		String sql = null;

		sql = "SELECT a.id_review AS reviewId, a.review_comments AS reviewComments, b.connectorMID AS connectorMID, b.connectorName AS connectorName, c.id_review_phase AS id_review_phase, c.Review_Phase AS Review_Phase, a.review_type AS reviewType, a.reviewer AS reviewer, a.severity AS severity "
				+ "FROM tbl_review a,tbl_connector_master b,tbl_review_phase_master c "
				+ "WHERE a.connectorMID = b.connectorMID AND a.id_review_phase = c.id_review_phase "
				+ "ORDER BY id_review";
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("reviewId", StandardBasicTypes.INTEGER)
				.addScalar("reviewComments", StandardBasicTypes.STRING)
				.addScalar("reviewType", StandardBasicTypes.STRING)
				.addScalar("reviewer", StandardBasicTypes.STRING)
				.addScalar("severity", StandardBasicTypes.STRING)
				.addScalar("connectorName", StandardBasicTypes.STRING)
				.addScalar("id_review_phase", StandardBasicTypes.INTEGER)
				.addScalar("Review_Phase", StandardBasicTypes.STRING);

		query.setResultTransformer(Transformers.aliasToBean(ReviewUI.class));
		return (List<ReviewUI>) query.list();
	}

	@Override
	public List<ReviewUI> getReview() throws Exception {
		String sql = null;
		sql = "SELECT connectorMID, connectorName from tbl_connector_master";
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("connectorMID", StandardBasicTypes.INTEGER)
				.addScalar("connectorName", StandardBasicTypes.STRING);

		query.setResultTransformer(Transformers.aliasToBean(ReviewUI.class));
		return (List<ReviewUI>) query.list();
	}

	@Override
	public List<ReviewUI> getReviewForConnector(Integer connectorMID)
			throws Exception {
		String sql = null;

		sql = "SELECT a.id_review AS reviewId, a.review_comments AS reviewComments, b.connectorMID AS connectorMID, b.connectorName AS connectorName, c.id_review_phase AS id_review_phase, c.Review_Phase AS Review_Phase, a.review_type AS reviewType, a.reviewer AS reviewer, a.severity AS severity "
				+ "FROM tbl_review a,tbl_connector_master b,tbl_review_phase_master c "
				+ "WHERE a.connectorMID = "
				+ connectorMID
				+ " AND a.connectorMID = b.connectorMID AND a.id_review_phase = c.id_review_phase "
				+ "ORDER BY id_review";

		Session session = getSession();
		Query query = session
				.createSQLQuery(sql)
				.addScalar("reviewId", StandardBasicTypes.INTEGER)
				.addScalar("reviewComments", StandardBasicTypes.STRING)
				.addScalar("reviewType", StandardBasicTypes.STRING)
				.addScalar("reviewer", StandardBasicTypes.STRING)
				.addScalar("severity", StandardBasicTypes.STRING)
				// .addScalar("connectorMID", StandardBasicTypes.INTEGER)
				.addScalar("connectorName", StandardBasicTypes.STRING)
				.addScalar("id_review_phase", StandardBasicTypes.INTEGER)
				.addScalar("Review_Phase", StandardBasicTypes.STRING);

		query.setResultTransformer(Transformers.aliasToBean(ReviewUI.class));
		return (List<ReviewUI>) query.list();
	}

	@Override
	public Review findReviewById(Integer reviewId) throws Exception {
		return getByKey(reviewId);
	}

	@Override
	public void updateReview(Review review) throws Exception {
		update(review);
	}

	@Override
	public void deleteReview(Integer reviewId) throws Exception {
		Session session = getSession();
		Query query = session
				.createSQLQuery("DELETE from tbl_review WHERE id_review = "
						+ reviewId);
		query.executeUpdate();

	}

	// @Override
	// public List<ReviewPhase> getAllReviewPhases(Map<String, Object> filter)
	// throws Exception {
	// // TODO Auto-generated method stub
	// return null;
	// }

}
