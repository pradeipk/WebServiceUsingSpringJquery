package com.psl.sprint.dao;

import java.util.List;
import java.util.Map;

import com.psl.sprint.model.Connector;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ReviewPhase;

public interface ReviewPhaseDao extends GenericDao {

//	public List<ReviewPhase> getAllReviewPhases(Map<String, Object> filter) throws Exception;
	
	public List<ReviewPhase> getAllReviewPhases() throws Exception;
	
	public void saveReviewPhase(ReviewPhase phase) throws Exception;
	
	public ReviewPhase findReviewPhaseByID(Integer id) throws Exception;
	
	

}
