package com.psl.sprint.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ReviewPhase;
import com.psl.sprint.service.ConnectorService;

@Repository("reviewPhaseDao")
public class ReviewPhaseDaoImpl extends AbstractDao<Integer, ReviewPhase> implements ReviewPhaseDao {

	@Autowired
	private ConnectorService service;

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((ReviewPhase) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((ReviewPhase) object);
	}

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((ReviewPhase) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorStatus", new Integer(1)));
		return criteria.list();
	}

	// @Override
	// public List<ReviewPhase> getAllReviewPhases(Map<String, Object> filter)
	// throws Exception {
	// // TODO Auto-generated method stub
	// return null;
	// }

	@Override
	public void saveReviewPhase(ReviewPhase phase) throws Exception {
		persist(phase);

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ReviewPhase> getAllReviewPhases() throws Exception {
		Criteria criteria = createEntityCriteria();
		return (List<ReviewPhase>) criteria.list();
	}

	@Override
	public ReviewPhase findReviewPhaseByID(Integer id) throws Exception {
		Criteria criteria = createEntityCriteria();
		Criterion checkDevOrQA = Restrictions.eq("id", id);
		criteria.add(checkDevOrQA);
		List<ReviewPhase> reviewPhases = (List<ReviewPhase>) criteria.list();
		return reviewPhases.get(0);

	}

}
