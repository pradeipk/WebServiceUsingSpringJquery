package com.psl.sprint.dao;

import com.psl.sprint.model.SprintItemStatus;

public interface SprintItemStatusDao extends GenericDao {
	public SprintItemStatus findBySprintItemId(Integer sprintItemId) throws Exception;
}
