package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.SprintItemStatus;

@Repository("sprintItemStatusDao")
public class SprintItemStatusDaoImpl extends
		AbstractDao<Integer, SprintItemStatus> implements SprintItemStatusDao {

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((SprintItemStatus) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((SprintItemStatus) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((SprintItemStatus) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SprintItemStatus findBySprintItemId(Integer sprintItemId)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("sprintItemId", sprintItemId));
		return (SprintItemStatus)criteria.uniqueResult();
	}
}
