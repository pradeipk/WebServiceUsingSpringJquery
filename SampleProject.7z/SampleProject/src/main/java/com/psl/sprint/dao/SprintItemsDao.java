package com.psl.sprint.dao;

import java.util.List;

import org.joda.time.LocalDate;

import com.psl.sprint.model.SprintItem;
import com.psl.sprint.model.SprintSummary;

public interface SprintItemsDao extends GenericDao {
	public List<SprintItem> findBySprintMasterId(Integer sprintMasterId)
			throws Exception;

	public Double getTotalPercentageCompletionByConnectorIdAndHid(
			Integer connectorId, Integer hid) throws Exception;

	public List<SprintSummary> getSprintSummary(Integer[] connectorIds)
			throws Exception;

	public Object findByConnectorId(Integer connectorId) throws Exception;

	public List<SprintSummary> getConnectorStoryPointsSprintWise(
			String startDate, String endDate) throws Exception;

	public List<SprintSummary> getSprintSummary(LocalDate startDate,
			LocalDate endDate, String createdby) throws Exception;

	public SprintItem findBySprintidnadHid(Integer id, Integer hid)
			throws Exception;

	public List<SprintItem> findByConnectorIdAndHidByOwner(Integer connectorId,
			Integer hid, Integer sprintId) throws Exception;

	public List<SprintItem> findByConnectorIdAndHid(Integer connectorId,
			Integer hid) throws Exception;

	public List<SprintSummary> getSprintSummaryByIds(String connectorIds)
			throws Exception;

	public List<SprintSummary> getSprintSummary(Integer sprintId)
			throws Exception;

}