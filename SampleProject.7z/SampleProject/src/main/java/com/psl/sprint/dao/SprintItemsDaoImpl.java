package com.psl.sprint.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.SprintItem;
import com.psl.sprint.model.SprintSummary;

@Repository("sprintItemsDao")
public class SprintItemsDaoImpl extends AbstractDao<Integer, SprintItem>
		implements SprintItemsDao {

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((SprintItem) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((SprintItem) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((SprintItem) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SprintItem> findBySprintMasterId(Integer sprintMasterId)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("sprintId", sprintMasterId));
		return criteria.list();
	}

	@Override
	public Double getTotalPercentageCompletionByConnectorIdAndHid(
			Integer connectorId, Integer hid) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT sum(percentage_completion) as PercentageCompletion FROM tbl_sprint_items"
				+ " WHERE connector_id = "
				+ connectorId
				+ " AND hid = "
				+ hid
				+ " GROUP BY connector_id + hid");
		Session session = getSession();
		Query query = session.createSQLQuery(sql.toString()).addScalar(
				"PercentageCompletion", StandardBasicTypes.DOUBLE);
		return (Double) query.uniqueResult();
	}

	@Override
	public List<SprintSummary> getSprintSummary(Integer[] connectorIds)
			throws Exception {
		StringBuffer ids = new StringBuffer();
		ids.append("(");
		for (Integer id : connectorIds) {
			ids.append(id + ",");
		}
		ids.deleteCharAt(ids.length() - 1);
		ids.append(")");
		String sql = "SELECT a.id AS Id, a.connector_id as ConnectorId, e.name AS ConnectorName, e.connector_type as ConnectorType, "
				+ "a.hid AS Hid, b.sprint_no AS SprintNo, c.SDLCPhaseTask AS SDLCPhaseTask, b.start_date AS StartDate, "
				+ "b.end_date AS EndDate, a.percentage_completion AS PercentageCompletion, (a.percentage_completion * d.complexity) / 100 AS StoryPoints "
				+ "FROM tbl_sprint_items a, tbl_sprintmaster b, tbl_etheaders c, tbl_connector_complexity d, tbl_connector e "
				+ "WHERE a.sprint_id = b.id AND a.hid = c.id AND a.hid = d.hid AND a.connector_id = d.connector_id "
				+ "AND a.connector_id = e.connector_id AND a.connector_id IN "
				+ ids + " ORDER BY a.sprint_id, e.name, a.hid";
		
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("Id", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("ConnectorType", StandardBasicTypes.INTEGER)
				.addScalar("Hid", StandardBasicTypes.INTEGER)
				.addScalar("SprintNo", StandardBasicTypes.INTEGER)
				.addScalar("SDLCPhaseTask", StandardBasicTypes.STRING)
				.addScalar("StartDate", StandardBasicTypes.DATE)
				.addScalar("EndDate", StandardBasicTypes.DATE)
				.addScalar("PercentageCompletion", StandardBasicTypes.DOUBLE)
				.addScalar("StoryPoints", StandardBasicTypes.DOUBLE);

		query.setResultTransformer(Transformers
				.aliasToBean(SprintSummary.class));
		return query.list();
	}

	@Override
	public Object findByConnectorId(Integer connectorId) throws Exception {
		// String sql =
		// "SELECT b.SDLCPhaseTask AS Headers from tbl_sprint_items a, tbl_etheaders b where a.connector_id = "
		// + connectorId + " AND a.hid = b.id";
		String connectorType = "";
		if (connectorId == 1) {
			connectorType = "Outbound";
		} else if (connectorId == 2) {
			connectorType = "Polling";
		} else {
			connectorType = "Webhooks";
		}
		String sql = "SELECT SDLCPhaseTask AS Headers from tbl_etheaders WHERE Type = '"
				+ connectorType + "'";
		Session session = getSession();
		Query query = session.createSQLQuery(sql);
		return query.list();
	}

	@Override
	public List<SprintSummary> getConnectorStoryPointsSprintWise(
			String startDate, String endDate) throws Exception {
		
		Date newSPlanDate=new SimpleDateFormat("yyyy-MM-dd").parse("2017-06-30");
		
		System.out.println("Start Date "+startDate);
		Date date = new Date();
		Date sStartDate=new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
		
		String sql;
		
		if(!sStartDate.after(newSPlanDate))		
		sql = "SELECT e.connectorMID AS ConnectorParentId, e.connectorName AS ConnectorName, b.sprint_no AS SprintNo, "				
				+ "b.start_date AS StartDate, b.end_date AS EndDate, "
				+ "SUM(a.percentage_completion * c.complexity) / 100 AS StoryPoints "
				+ "FROM tbl_sprint_items a, tbl_sprintmaster b, tbl_connector_complexity c, tbl_connector_master e, tbl_sprint_items_status f "
				+ "WHERE a.sprint_id = b.id AND a.hid = c.hid AND b.sprint_no != 0 AND a.connector_id = c.connector_id "
				+ "AND b.connector_master_id = e.connectorMID AND b.end_date between '"
				+ startDate
				+ "' AND '"
				+ endDate
				+ "' "
				+ "AND a.id = f.sprint_item_id AND (f.status = 'Completed' OR f.status = '25% Completed' OR f.status = '50% Completed' OR f.status = '75% Completed') "
				+ "GROUP BY ConnectorName, SprintNo ORDER BY e.connectorName, b.sprint_no";
		else
			sql = "SELECT e.CONN_MASTER_ID AS ConnectorParentId, d.connectorName AS ConnectorName, "
					+ "b.start_date AS StartDate, b.end_date AS EndDate, "
					+ "b.start_date AS StartDate, b.end_date AS EndDate, "
					+ "SUM(a.percentage_completion * c.complexity) / 100 AS StoryPoints "
					+ "FROM tbl_sprint_items a, tbl_sprintmaster b, tbl_connector_complexity c, tbl_connector_master d, tbl_connector e, tbl_sprint_items_status f "
					+ "WHERE a.sprint_id = b.id AND a.hid = c.hid AND a.connector_id = c.connector_id "
					+ "AND a.connector_id =e.CONNECTOR_ID AND d.connectorMID = e.CONN_MASTER_ID "
					+ "AND b.end_date between '"
					+ startDate
					+ "' AND '"
					+ endDate
					+ "' "
					+ "AND a.id = f.sprint_item_id AND (f.status = 'Completed' OR f.status = '25% Completed' OR f.status = '50% Completed' OR f.status = '75% Completed') "
					+ "GROUP BY StartDate, ConnectorName ORDER BY d.connectorName";	
		
		Session session = getSession();
		System.out.println(sql);
		Query query;
		if(!sStartDate.after(newSPlanDate))
			query = session.createSQLQuery(sql)
				.addScalar("ConnectorParentId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("SprintNo", StandardBasicTypes.INTEGER)
				.addScalar("StartDate", StandardBasicTypes.DATE)
				.addScalar("EndDate", StandardBasicTypes.DATE)
				.addScalar("StoryPoints", StandardBasicTypes.DOUBLE);	
		else
			query = session.createSQLQuery(sql)
			.addScalar("ConnectorParentId", StandardBasicTypes.INTEGER)
			.addScalar("ConnectorName", StandardBasicTypes.STRING)	
			.addScalar("StartDate", StandardBasicTypes.DATE)
			.addScalar("EndDate", StandardBasicTypes.DATE)
			.addScalar("StoryPoints", StandardBasicTypes.DOUBLE);	
		
		query.setResultTransformer(Transformers
				.aliasToBean(SprintSummary.class));
		return query.list();
	}

	@Override
	public List<SprintSummary> getSprintSummary(LocalDate startDate,
			LocalDate endDate, String createdby) throws Exception {
		String sql = "SELECT * FROM ("
				+ "SELECT a.id AS Id, a.connector_id as ConnectorId, e.name AS ConnectorName, e.connector_type as ConnectorType, "
				+ "a.hid AS Hid, b.sprint_no AS SprintNo, c.SDLCPhaseTask AS SDLCPhaseTask, b.start_date AS StartDate, a.lead_mapping as leadMapping ,a.created_by as CreateBy,"
				+ "b.end_date AS EndDate, a.percentage_completion AS PercentageCompletion, (a.percentage_completion * d.complexity) / 100 AS StoryPoints "
				+ "FROM tbl_sprint_items a, tbl_sprintmaster b, tbl_etheaders c, tbl_connector_complexity d, tbl_connector e "
				+ "WHERE a.sprint_id = b.id AND a.hid = c.id AND a.hid = d.hid AND a.connector_id = d.connector_id "
				+ "  AND b.frozoned=1  And b.start_date = \"" + startDate
				+ "\" And b.end_date = \"" + endDate + "\" "
				+ " AND a.connector_id = e.connector_id"
				+ "  And b.created_by = " + createdby
				+ " ORDER BY  e.name, a.hid"
				+ ") as connectorinfo  ORDER BY  EndDate desc";
		
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("Id", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("ConnectorType", StandardBasicTypes.INTEGER)
				.addScalar("Hid", StandardBasicTypes.INTEGER)
				.addScalar("SprintNo", StandardBasicTypes.INTEGER)
				.addScalar("SDLCPhaseTask", StandardBasicTypes.STRING)
				.addScalar("StartDate", StandardBasicTypes.DATE)
				.addScalar("EndDate", StandardBasicTypes.DATE)
				.addScalar("PercentageCompletion", StandardBasicTypes.DOUBLE)
				.addScalar("StoryPoints", StandardBasicTypes.DOUBLE)
				.addScalar("CreateBy", StandardBasicTypes.INTEGER)
				.addScalar("leadMapping", StandardBasicTypes.INTEGER);

		query.setResultTransformer(Transformers
				.aliasToBean(SprintSummary.class));
		return query.list();
	}

	@Override
	public SprintItem findBySprintidnadHid(Integer sprintMasterId, Integer hid)
			throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("sprintId", sprintMasterId));
		criteria.add(Restrictions.eq("hId", hid));
		if (criteria != null && criteria.list().size() > 0) {
			return (SprintItem) criteria.list().get(0);
		} else {
			return null;
		}
	}

	@Override
	public List<SprintItem> findByConnectorIdAndHidByOwner(Integer connectorId,
			Integer hid, Integer sprintId) throws Exception {

		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorId", connectorId));
		criteria.add(Restrictions.eq("hId", hid));
		criteria.add(Restrictions.eq("sprintId", sprintId));

		return criteria.list();

	}

	@Override
	public List<SprintItem> findByConnectorIdAndHid(Integer connectorId,
			Integer hid) throws Exception {

		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorId", connectorId));
		criteria.add(Restrictions.eq("hId", hid));

		return criteria.list();

	}

	@Override
	public List<SprintSummary> getSprintSummaryByIds(String connectorIds)
			throws Exception {
		// TODO Auto-generated method stub

		String sql = "SELECT * FROM ("
				+ "SELECT a.id AS Id, a.connector_id as ConnectorId, e.name AS ConnectorName, e.connector_type as ConnectorType, "
				+ "a.hid AS Hid, b.sprint_no AS SprintNo, c.SDLCPhaseTask AS SDLCPhaseTask, b.start_date AS StartDate, a.lead_mapping as leadMapping ,a.created_by as CreateBy,"
				+ "b.end_date AS EndDate, a.percentage_completion AS PercentageCompletion, (a.percentage_completion * d.complexity) / 100 AS StoryPoints "
				+ "FROM tbl_sprint_items a, tbl_sprintmaster b, tbl_etheaders c, tbl_connector_complexity d, tbl_connector e "
				+ "WHERE a.sprint_id = b.id AND a.hid = c.id AND a.hid = d.hid AND a.connector_id = d.connector_id "
				+ "  AND b.frozoned=1 "
				+ " AND a.connector_id = e.connector_id"
				+ " AND a.lead_mapping in ( " + connectorIds + " ) "
				+ " ORDER BY  e.name, a.hid"
				+ ") as connectorinfo  ORDER BY  EndDate desc";

		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("Id", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("ConnectorType", StandardBasicTypes.INTEGER)
				.addScalar("Hid", StandardBasicTypes.INTEGER)
				.addScalar("SprintNo", StandardBasicTypes.INTEGER)
				.addScalar("SDLCPhaseTask", StandardBasicTypes.STRING)
				.addScalar("StartDate", StandardBasicTypes.DATE)
				.addScalar("EndDate", StandardBasicTypes.DATE)
				.addScalar("PercentageCompletion", StandardBasicTypes.DOUBLE)
				.addScalar("StoryPoints", StandardBasicTypes.DOUBLE)
				.addScalar("CreateBy", StandardBasicTypes.INTEGER)
				.addScalar("leadMapping", StandardBasicTypes.INTEGER);

		query.setResultTransformer(Transformers
				.aliasToBean(SprintSummary.class));
		return query.list();
	}

	@Override
	public List<SprintSummary> getSprintSummary(Integer sprintId)
			throws Exception {
		String sql = "SELECT distinct* FROM ("
				+ "SELECT a.id AS Id, a.connector_id as ConnectorId, e.name AS ConnectorName, e.connector_type as ConnectorType, "
				+ "a.hid AS Hid, b.sprint_no AS SprintNo, c.SDLCPhaseTask AS SDLCPhaseTask, b.start_date AS StartDate, a.lead_mapping as leadMapping ,a.created_by as CreateBy,"
				+ "b.end_date AS EndDate, a.percentage_completion AS PercentageCompletion, (a.percentage_completion * d.complexity) / 100 AS StoryPoints "
				+ "FROM tbl_sprint_items a, tbl_sprintmaster b, tbl_etheaders c, tbl_connector_complexity d, tbl_connector e "
				+ "WHERE a.sprint_id = b.id AND a.hid = c.id AND a.hid = d.hid AND a.connector_id = d.connector_id "
				+ "  AND b.frozoned=1  And b.id = \"" + sprintId
				+ "\" And a.sprint_id = b.id"
				+ " AND a.connector_id = e.connector_id"

				+ " ORDER BY  e.name, a.hid"
				+ ") as connectorinfo  ORDER BY  EndDate desc";
		
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("Id", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("ConnectorType", StandardBasicTypes.INTEGER)
				.addScalar("Hid", StandardBasicTypes.INTEGER)
				.addScalar("SprintNo", StandardBasicTypes.INTEGER)
				.addScalar("SDLCPhaseTask", StandardBasicTypes.STRING)
				.addScalar("StartDate", StandardBasicTypes.DATE)
				.addScalar("EndDate", StandardBasicTypes.DATE)
				.addScalar("PercentageCompletion", StandardBasicTypes.DOUBLE)
				.addScalar("StoryPoints", StandardBasicTypes.DOUBLE)
				.addScalar("CreateBy", StandardBasicTypes.INTEGER)
				.addScalar("leadMapping", StandardBasicTypes.INTEGER);

		query.setResultTransformer(Transformers
				.aliasToBean(SprintSummary.class));
		return query.list();
	}

}
