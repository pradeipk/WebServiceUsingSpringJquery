package com.psl.sprint.dao;

import java.util.List;

import org.joda.time.LocalDate;

import com.psl.sprint.model.Resource;
import com.psl.sprint.model.SprintMaster;
import com.psl.sprint.model.SprintSummary;

public interface SprintMasterDao extends GenericDao {

	public List<SprintMaster> findByConnectorMasterId(Integer connectorMasterId)
			throws Exception;

	public SprintMaster findByStartDateEndDateAndConnectorId(String startDate,
			String endDate, Integer connectorId) throws Exception;

	public List<Object[]> getSprintrecource(String ids) throws Exception;

	public SprintMaster findBynonForzenById(Integer id) throws Exception;

	public Integer saveSprintMasterRecords(SprintMaster sprintMasterRow)
			throws Exception;

	public void deleteMapping(Integer id) throws Exception;

	public List<SprintMaster> getFrozenedSprint() throws Exception;

	public List<Object[]> getReportForAlertUser(LocalDate startDate,
			LocalDate endDate) throws Exception;

	public List<SprintMaster> getNonFrozenSprints(LocalDate today)
			throws Exception;

	public List<SprintMaster> findByStartDateEndDateAndConnectorId(
			LocalDate startDate, LocalDate endDate, Integer[] ids)
			throws Exception;

	public List<SprintSummary> getFrozenedSprintbyIds(String ids)
			throws Exception;

	public List<SprintSummary> getallfrozonedSprintsbyGroup() throws Exception;

	public List<SprintMaster> getExistingSprintsForUser(Integer resourceId,
			Integer isfreezed) throws Exception;

	public SprintMaster getLastSprintDateForUser(Integer resourceId,
			int isfreezed, boolean isEndate) throws Exception;

	public List<SprintMaster> getMasterSprintsforUser(Integer creadedBy,
			int isfrozen, int rowLimit) throws Exception;

}