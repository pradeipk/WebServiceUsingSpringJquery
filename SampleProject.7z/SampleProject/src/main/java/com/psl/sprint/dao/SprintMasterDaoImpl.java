package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.psl.sprint.configuration.SprintConfiguration;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.SprintMaster;
import com.psl.sprint.model.SprintSummary;

@Repository("sprintMasterDao")
public class SprintMasterDaoImpl extends AbstractDao<Integer, SprintMaster>
		implements SprintMasterDao {

	@Autowired
	private SprintConfiguration sprintConfiguration;

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((SprintMaster) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((SprintMaster) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((SprintMaster) object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();
		return criteria.list();

		// return null;
	}

	@Override
	public List<SprintMaster> findByConnectorMasterId(Integer connectorMasterId)
			throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("connectorMasterId", connectorMasterId));
		return criteria.list();
	}

	@Override
	public SprintMaster findByStartDateEndDateAndConnectorId(String startDate,
			String endDate, Integer connectorId) throws Exception {
		String sql = "SELECT a.* FROM tbl_sprintmaster a, tbl_connector_master b, tbl_connector c "
				+ "WHERE a.start_date <= '"
				+ startDate
				+ "' AND a.end_date >= '"
				+ endDate
				+ "' AND a.connector_master_id = b.connectorMID "
				+ "AND b.connectorMID = c.CONN_MASTER_ID AND c.connector_id = "
				+ connectorId;
		Session session = getSession();
		Query query = session.createSQLQuery(sql).addEntity(SprintMaster.class);
		return (SprintMaster) query.uniqueResult();
	}

	@Override
	public List<Object[]> getSprintrecource(String ids) throws Exception {
		// TODO Auto-generated method stub
		String sqlQuery = " SELECT sprint_id as sprintid,connector_lead as connectorLead  FROM  tbl_sprint_lead_mapping  where connector_lead in ( "
				+ ids + " ) " + " group by sprint_id ";

		SQLQuery query = getSession().createSQLQuery(sqlQuery);
		List<Object[]> reports = query.list();
		return reports;
	}

	@Override
	public SprintMaster findBynonForzenById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("id", id));
		criteria.add(Restrictions.eq("freezed", 0));
		if (criteria != null && criteria.list().size() > 0) {
			return (SprintMaster) criteria.list().get(0);
		} else {
			return null;
		}
	}

	@Override
	public Integer saveSprintMasterRecords(SprintMaster sprintMaster)
			throws Exception {

		Integer id = (Integer) getSession().save(sprintMaster);
		return id;
	}

	@Override
	public void deleteMapping(Integer id) throws Exception {
		// TODO Auto-generated method stub

		String sqlQuery = " delete   FROM  tbl_sprint_lead_mapping  where sprint_id =  "
				+ id;

		SQLQuery query = getSession().createSQLQuery(sqlQuery);
		query.executeUpdate();

	}

	@Override
	public List<SprintMaster> getFrozenedSprint() throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("freezed", 1));
		criteria.addOrder(Order.desc("endDate"));
		criteria.setMaxResults(sprintConfiguration
				.getSprintSuymmaryDisplayCount());
		if (criteria != null && criteria.list().size() > 0) {
			return criteria.list();
		} else {
			return null;
		}

	}

	@Override
	public List<Object[]> getReportForAlertUser(LocalDate startDate,
			LocalDate endDate) throws Exception {
		// TODO Auto-generated method stub
		String sqlQuery = "select mainConnectorName, sum(StoryPoints) as StoryPoints from "
				+ "  (SELECT connectormaster.connectorName as mainConnectorName,connector.NAME as subConnectorName,"
				+ "  sprintitems.percentage_completion AS PercentageCompletion,"
				+ "  connectorcomplexity.complexity ,"
				+ "  (sprintitems.percentage_completion * connectorcomplexity.complexity) / 100 AS StoryPoints "
				+ "  FROM tbl_sprint_items  sprintitems"
				+ "  INNER JOIN tbl_sprintmaster sprintmaster"
				+ "  ON sprintitems.sprint_id = sprintmaster.id"
				+ "  INNER JOIN tbl_connector connector "
				+ "  on connector.connector_id =sprintitems.connector_id"
				+ "  INNER JOIN tbl_connector_master connectormaster "
				+ "  on connectormaster.connectorMID =connector.conn_master_id"
				+ "  INNER JOIN  tbl_connector_complexity connectorcomplexity"
				+ "  on connectorcomplexity.hid=sprintitems.hid "
				+ "  and connectorcomplexity.connector_id=sprintitems.connector_id"
				+ "  where sprintmaster.frozoned=0 "
				+ "  and sprintmaster.start_date = \'"
				+ startDate
				+ "\'"
				+ "  and sprintmaster.end_date = \'" + endDate + "\'"

				+ "  ) as connectorinfo" + "  group by mainConnectorName";

		SQLQuery query = getSession().createSQLQuery(sqlQuery);
		List<Object[]> reports = query.list();
		return reports;

	}

	@Override
	public List<SprintMaster> getNonFrozenSprints(LocalDate today)
			throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();

		criteria.add(Restrictions.eq("freezed", 0));
		criteria.add(Restrictions.lt("startDate", today));
		if (criteria != null && criteria.list().size() > 0) {
			return criteria.list();
		} else {
			return null;
		}
	}

	@Override
	public List<SprintMaster> findByStartDateEndDateAndConnectorId(
			LocalDate startDate, LocalDate endDate, Integer[] ids)
			throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();
		if (ids != null) {
			criteria.add(Restrictions.in("id", ids));
			// criteria.add(Restrictions.eq("owner", "ff"));
		}

		criteria.add(Restrictions.eq("startDate", startDate));
		criteria.add(Restrictions.eq("endDate", endDate));

		if (criteria != null && criteria.list().size() > 0) {
			return criteria.list();
		} else {
			return null;
		}
	}

	@Override
	public List<SprintSummary> getFrozenedSprintbyIds(String connectorIds)
			throws Exception {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM ( select "
				+ "  b.created_by as CreateBy, b.start_date as StartDate, b.end_date  as EndDate "
				+ " FROM tbl_sprint_items a, tbl_sprintmaster b  "
				+ " WHERE  a.sprint_id = b.id " + "  and   b.frozoned=1 "
				+ " AND a.lead_mapping in ( " + connectorIds + " ) "
				+ " group by  b.created_by, b.start_date ,b.end_date "
				+ ") as connectorinfo  ORDER BY  EndDate desc";
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("StartDate", StandardBasicTypes.DATE)
				.addScalar("EndDate", StandardBasicTypes.DATE)
				.addScalar("CreateBy", StandardBasicTypes.INTEGER);

		query.setResultTransformer(Transformers
				.aliasToBean(SprintSummary.class));
		query.setMaxResults(sprintConfiguration.getSprintSuymmaryDisplayCount());
		return query.list();
	}

	@Override
	public List<SprintSummary> getallfrozonedSprintsbyGroup() throws Exception {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM ( select "
				+ "  b.created_by as CreateBy, b.start_date as StartDate, b.end_date  as EndDate "
				+ " FROM tbl_sprint_items a, tbl_sprintmaster b  "
				+ " WHERE  a.sprint_id = b.id " + "  and   b.frozoned=1 "
				+ " group by  b.created_by, b.start_date ,b.end_date "
				+ ") as connectorinfo  ORDER BY  EndDate desc";
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("StartDate", StandardBasicTypes.DATE)
				.addScalar("EndDate", StandardBasicTypes.DATE)
				.addScalar("CreateBy", StandardBasicTypes.INTEGER);

		query.setResultTransformer(Transformers
				.aliasToBean(SprintSummary.class));
		query.setMaxResults(sprintConfiguration.getSprintSuymmaryDisplayCount());
		return query.list();
	}

	@Override
	public List<SprintMaster> getExistingSprintsForUser(Integer resourceId,
			Integer isfreezed) throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("freezed", isfreezed));
		criteria.addOrder(Order.asc("startDate"));
		criteria = criteria.createCriteria("resource").add(
				Restrictions.eq("resourceId", resourceId));

		if (criteria != null && criteria.list().size() > 0) {
			return criteria.list();
		} else {
			return null;
		}

	}

	@Override
	public SprintMaster getLastSprintDateForUser(Integer resourceId,
			int isfreezed, boolean isEndate) throws Exception {
		// TODO Auto-generated method stub
		/*
		 * DetachedCriteria maxDateQry = DetachedCriteria.forClass(Quote.class);
		 * maxDateQry.setProjection( Projections.projectionList()
		 * .add(Projections.groupProperty("qid.id"))
		 * .add(Projections.max("qid.date", "maxdate")) );
		 * 
		 * Criteria criteria = session.createCriteria(Quote.class); Object
		 * environmentIdAndStartedDateProperty = "(environmentId, startedDate)"
		 * // but not this, some sort of magic criteria.add(
		 * Subqueries.in(environmentIdAndStartedDateProperty, maxDateQry));
		 */
		String dateProperty = null;
		DetachedCriteria maxDateQry = DetachedCriteria
				.forClass(SprintMaster.class);
		maxDateQry.add(Restrictions.eq("freezed", isfreezed));
		ProjectionList projectionList = Projections.projectionList();
		if (isEndate) {
			projectionList.add(Projections.max("endDate"));
			dateProperty = "endDate";
		} else {
			projectionList.add(Projections.max("startDate"));
			dateProperty = "startDate";

		}
		maxDateQry.setProjection(projectionList);
		maxDateQry = maxDateQry.createCriteria("resource").add(
				Restrictions.eq("resourceId", resourceId));

		Criteria criteria = createEntityCriteria();

		criteria.add(Restrictions.eq("freezed", isfreezed));
		criteria.add(Subqueries.propertyIn(dateProperty, maxDateQry));
		criteria = criteria.createCriteria("resource").add(
				Restrictions.eq("resourceId", resourceId));
		if (criteria != null && criteria.list().size() > 0) {
			return (SprintMaster) criteria.list().get(0);
		} else {
			return null;
			/*
			 * Criteria criteria = createEntityCriteria(); criteria =
			 * criteria.createCriteria
			 * ("resource").add(Restrictions.eq("resourceId", resourceId));
			 * criteria.add(Restrictions.eq("freezed", isfreezed));
			 * ProjectionList projectionList = Projections.projectionList();
			 * if(isEndate) projectionList.add(Projections.max("endDate")); else
			 * projectionList.add(Projections.max("startDate"));
			 * criteria.setProjection(projectionList); if(criteria!=null &&
			 * criteria.list().size()>0) return
			 * (LocalDate)criteria.list().get(0);
			 * 
			 * else return null;
			 */
		}

	}

	@Override
	public List<SprintMaster> getMasterSprintsforUser(Integer creadedBy,
			int isfrozen, int rowLimit) throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("freezed", isfrozen));
		criteria.addOrder(Order.desc("endDate"));
		criteria = criteria.createCriteria("resource").add(
				Restrictions.eq("resourceId", creadedBy));
		criteria.setMaxResults(rowLimit);
		if (criteria != null && criteria.list().size() > 0) {
			return criteria.list();
		} else {
			return null;
		}

	}

}