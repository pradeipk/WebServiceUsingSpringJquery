package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.StoryPointsEstimationMaster;

public interface StoryPointsEstimationMasterDao extends GenericDao {
	public List<StoryPointsEstimationMaster> findByVersionAndType(String version, String connectorType) throws Exception;
}
