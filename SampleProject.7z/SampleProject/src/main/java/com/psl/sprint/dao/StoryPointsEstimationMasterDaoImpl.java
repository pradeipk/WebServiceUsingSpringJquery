package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.StoryPointsEstimationMaster;

@Repository("storyPointsEstimationMasterDao")
public class StoryPointsEstimationMasterDaoImpl extends
		AbstractDao<Integer, StoryPointsEstimationMaster> implements
		StoryPointsEstimationMasterDao {

	@Override
	public List<StoryPointsEstimationMaster> findByVersionAndType(String version, String connectorType)
			throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT a.id AS id, a.hid AS hid, a.tiny AS tiny, a.simple AS simple, a.medium AS medium, a.complex AS complex, a.template_version AS templateVersion " 
				+ "FROM tbl_sps_estimation_master a, tbl_etheaders b " 
				+ "WHERE a.template_version = '" + version + "' AND a.hid = b.id AND b.Type = '" + connectorType +"'");
		Session session = getSession();
		Query query = session.createSQLQuery(sql.toString())
				.addScalar("id", StandardBasicTypes.INTEGER)
				.addScalar("hid", StandardBasicTypes.INTEGER)
				.addScalar("tiny", StandardBasicTypes.INTEGER)
				.addScalar("simple", StandardBasicTypes.INTEGER)
				.addScalar("medium", StandardBasicTypes.INTEGER)
				.addScalar("complex", StandardBasicTypes.INTEGER)
				.addScalar("templateVersion", StandardBasicTypes.STRING);
		query.setResultTransformer(Transformers
				.aliasToBean(StoryPointsEstimationMaster.class));
		return (List<StoryPointsEstimationMaster>)query.list();

	}

	@Override
	public Object findById(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}