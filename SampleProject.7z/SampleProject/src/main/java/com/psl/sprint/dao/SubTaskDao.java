package com.psl.sprint.dao;

import java.util.List;

import com.psl.sprint.model.Subtask;

public interface SubTaskDao {

	public Subtask findById(int id) throws Exception;

	public void saveSubtask(Subtask storyPoint) throws Exception;

	public void updateSubtask(Subtask storyPoint) throws Exception;

	public void deleteSubtask(Integer id) throws Exception;

	public List<Subtask> findAllSubtask() throws Exception;

	public Subtask findSubtaskByConnectorName(String ssn);
	
	public List<Subtask> findAllSubtaskByName(String subtask) throws Exception;

	public Subtask findByName(String subtask) throws Exception;

}
