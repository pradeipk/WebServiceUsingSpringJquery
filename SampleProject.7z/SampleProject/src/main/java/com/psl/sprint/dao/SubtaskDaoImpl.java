package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.Subtask;

@Repository("storyPointDao")
public class SubtaskDaoImpl extends AbstractDao<Integer, Subtask> implements
		SubTaskDao {

	public void saveSubtask(Subtask entity) throws Exception {
		persist(entity);
	}

	public Subtask findById(int id) throws Exception {
		return getByKey(id);
	}

	public void deleteSubtask(Integer id) throws Exception {
		Subtask task = new Subtask();
		task.setTaskId(id);
		delete(task);
	}

	@SuppressWarnings("unchecked")
	public List<Subtask> findAllSubtask() throws Exception {
		Criteria criteria = createEntityCriteria();
		return (List<Subtask>) criteria.list();

	}
	
	@SuppressWarnings("unchecked")
	public List<Subtask> findAllSubtaskByName(String subtask) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("subtask", subtask));
		return (List<Subtask>) criteria.list();
	}


	public Subtask findSubtaskByConnectorName(String ssn) {
		return null;
	}

	public void updateSubtask(Subtask subtask) throws Exception {
		update(subtask);
	}

	@Override
	public Subtask findByName(String subtask) throws Exception {
		try {
			Criteria criteria = createEntityCriteria();
			List<Subtask> list = (List<Subtask>) criteria.add(Restrictions.eq("subtask", subtask)).list();
			if(!list.isEmpty()){
				return list.get(0);
			}
			return null;
		} catch (Exception e) {
			
			e.printStackTrace();
			throw e;
		}
		
		
	}

}
