package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.Resource;
import com.psl.sprint.model.Task;
import com.psl.sprint.model.TaskEffortsByConnector;
import com.psl.sprint.model.TaskEffortsByConnectorAndPhase;

@Repository("taskDao")
public class TaskDaoImpl extends AbstractDao<Integer, Task> implements TaskDao {

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	public List<?> findByName(Object object) throws Exception {
		Resource resource = (Resource) object;
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("resourceId", resource.getResourceId()));
		LocalDate date = new LocalDate().minusDays(2);
		criteria.add(Restrictions.ge("taskDate", date));
		return criteria.list();
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		Task task = (Task) object;
		persist(task);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		Task task = (Task) object;
		update(task);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		Task task = (Task) object;
		delete(task);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TaskEffortsByConnectorAndPhase> getEffortsByConnectorAndPhase(
			Integer connectorId, String phase) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("SELECT a.resource_id AS ResourceId, b.first_name AS FirstName, b.last_name AS LastName, a.task_date AS TaskDate, a.description AS Description, ");
		sql.append("a.connector_id AS ConnectorId, c.name AS ConnectorName, a.hours_spent AS HoursSpent");
		sql.append(" FROM tbl_task a, tbl_resource b, tbl_connector c");
		sql.append(" WHERE a.connector_id = " + connectorId);
		sql.append(" AND a.phase = '" + phase + "'");
		sql.append(" AND a.resource_id = b.resource_id AND a.connector_id = c.connector_id ORDER BY a.resource_id");
		Session session = getSession();
		Query query = session.createSQLQuery(sql.toString())
				.addScalar("ResourceId", StandardBasicTypes.INTEGER)
				.addScalar("FirstName", StandardBasicTypes.STRING)
				.addScalar("LastName", StandardBasicTypes.STRING)
				.addScalar("TaskDate", StandardBasicTypes.DATE)
				.addScalar("Description", StandardBasicTypes.STRING)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("HoursSpent", StandardBasicTypes.DOUBLE);

		query.setResultTransformer(Transformers
				.aliasToBean(TaskEffortsByConnectorAndPhase.class));
		List<TaskEffortsByConnectorAndPhase> efforts = query.list();
		return efforts;
	}

	@Override
	public List<Task> getEffortsForAllConnectors(String job) throws Exception {
		String sql = "SELECT a.connector_id AS connectorId, sum(a.hours_spent) AS hoursSpent FROM tbl_task a, tbl_resource b "
				+ "WHERE a.phase != 'Others' AND a.resource_id = b.resource_id AND b.job_assigned = '"
				+ job + "' group by a.connector_id";
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("connectorId", StandardBasicTypes.INTEGER)
				.addScalar("hoursSpent", StandardBasicTypes.DOUBLE);

		query.setResultTransformer(Transformers.aliasToBean(Task.class));
		List<Task> efforts = query.list();
		return efforts;
	}

	@Override
	public List<Task> getEffortsByConnector(Integer connectorId, String job)
			throws Exception {
		String sql = "SELECT a.phase, sum(a.hours_spent) AS hoursSpent FROM tbl_task a, tbl_resource b "
				+ "WHERE a.connector_id = "
				+ connectorId
				+ " AND a.resource_id = b.resource_id AND b.job_assigned = '"
				+ job + "' group by phase";
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("phase", StandardBasicTypes.STRING)
				.addScalar("hoursSpent", StandardBasicTypes.DOUBLE);
		query.setResultTransformer(Transformers.aliasToBean(Task.class));
		List<Task> efforts = query.list();
		return efforts;
	}

	@Override
	public List<TaskEffortsByConnector> getEffortsByDateAndOrConnector(
			String startDate, String endDate, Integer connectorId,
			Integer resourceId) throws Exception {
		String sql = null;

		if (connectorId == null && resourceId == null) {
			sql = "SELECT a.resource_id AS ResourceId, concat(c.first_name, ' ', c.last_name) AS ResourceName, a.task_date AS TaskDate, "
					+ "a.connector_id AS ConnectorId, b.name AS ConnectorName, a.hours_spent AS NoOfHours, a.phase AS Phase, a.description AS Description, "
					+ " a.tcs_Created AS TcsCreated, a.tcs_Exec AS TcsExecuted "
					+ "FROM tbl_task a, tbl_connector b, tbl_resource c "
					+ "WHERE a.task_date >= '"
					+ startDate
					+ "' AND a.task_date <= '"
					+ endDate
					+ "' AND a.connector_id = b.connector_id "
					+ "AND a.resource_id = c.resource_id ORDER BY a.task_date";
		} else {
			if (connectorId != null && resourceId == null) {
				sql = "SELECT a.resource_id AS ResourceId, concat(c.first_name, ' ', c.last_name) AS ResourceName, a.task_date AS TaskDate, "
						+ "a.connector_id AS ConnectorId, b.name AS ConnectorName, a.hours_spent AS NoOfHours, a.phase AS Phase, a.description AS Description, "
						+ " a.tcs_Created AS TcsCreated, a.tcs_Exec AS TcsExecuted "
						+ "FROM tbl_task a, tbl_connector b, tbl_resource c WHERE a.task_date >= '"
						+ startDate
						+ "' AND a.task_date <= '"
						+ endDate
						+ "' AND "
						+ "a.connector_id = "
						+ connectorId
						+ " AND a.connector_id = b.connector_id AND a.resource_id = c.resource_id ORDER BY a.task_date";
			} else if (resourceId != null && connectorId == null) {
				sql = "SELECT a.resource_id AS ResourceId, concat(c.first_name, ' ', c.last_name) AS ResourceName, a.task_date AS TaskDate, "
						+ "a.connector_id AS ConnectorId, b.name AS ConnectorName, a.hours_spent AS NoOfHours, a.phase AS Phase, a.description AS Description, "
						+ " a.tcs_Created AS TcsCreated, a.tcs_Exec AS TcsExecuted "
						+ "FROM tbl_task a, tbl_connector b, tbl_resource c WHERE a.task_date >= '"
						+ startDate
						+ "' AND a.task_date <= '"
						+ endDate
						+ "' AND "
						+ "a.resource_id = "
						+ resourceId
						+ " AND a.connector_id = b.connector_id AND a.resource_id = c.resource_id ORDER BY a.task_date";
			} else {
				sql = "SELECT a.resource_id AS ResourceId, concat(c.first_name, ' ', c.last_name) AS ResourceName, a.task_date AS TaskDate, "
						+ "a.connector_id AS ConnectorId, b.name AS ConnectorName, a.hours_spent AS NoOfHours, a.phase AS Phase, a.description AS Description, "
						+ " a.tcs_Created AS TcsCreated, a.tcs_Exec AS TcsExecuted "
						+ "FROM tbl_task a, tbl_connector b, tbl_resource c WHERE a.task_date >= '"
						+ startDate
						+ "' AND a.task_date <= '"
						+ endDate
						+ "' AND "
						+ "a.resource_id = "
						+ resourceId
						+ " AND a.connector_id = "
						+ connectorId
						+ " AND a.connector_id = b.connector_id "
						+ "AND a.resource_id = c.resource_id ORDER BY a.task_date";

			}
		}
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("ResourceId", StandardBasicTypes.INTEGER)
				.addScalar("ResourceName", StandardBasicTypes.STRING)
				.addScalar("TaskDate", StandardBasicTypes.DATE)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("Phase", StandardBasicTypes.STRING)
				.addScalar("NoOfHours", StandardBasicTypes.DOUBLE)
				.addScalar("Description", StandardBasicTypes.STRING)
				.addScalar("TcsCreated", StandardBasicTypes.INTEGER)
				.addScalar("TcsExecuted", StandardBasicTypes.INTEGER);

		query.setResultTransformer(Transformers
				.aliasToBean(TaskEffortsByConnector.class));
		List<TaskEffortsByConnector> efforts = query.list();
		return efforts;
	}

	@Override
	public List<TaskEffortsByConnector> getEffortsByDateAndPhase(
			String startDate, String endDate, String phaseName,
			String monthYear, String comparisonType) throws Exception {

		String dateRange = null;
		if (comparisonType.equals("MONTH")) {
			int month = Integer.parseInt(monthYear.split("-")[1]);
			int year = Integer.parseInt(monthYear.split("-")[0]);
			dateRange = " MONTH(a.task_date) = " + month
					+ " AND YEAR(a.task_date) = " + year;
		} else {
			dateRange = "a.task_date >= '" + startDate
					+ "' AND a.task_date <= '" + endDate + "'";
		}

		String sql = null;
		if (phaseName != null && phaseName.equalsIgnoreCase("TcExecution")) {
			sql = "SELECT a.resource_id AS ResourceId, concat(c.first_name, ' ', c.last_name) AS ResourceName, a.task_date AS TaskDate, "
					+ "a.connector_id AS ConnectorId, b.name AS ConnectorName, a.hours_spent AS NoOfHours, a.phase AS Phase, a.description AS Description, "
					+ " a.tcs_Created AS TcsCreated , a.tcs_Exec AS TcsExecuted "
					+ "FROM tbl_task a, tbl_connector b, tbl_resource c "
					+ "WHERE phase='Integration Testing (Mocha) - TEST CASE EXECUTION' "
					+ "and a.tcs_Exec IS NOT NULL and "
					+ dateRange
					+ " AND a.connector_id = b.connector_id "
					+ "AND a.resource_id = c.resource_id ORDER BY a.task_date";
		} else if (phaseName != null
				&& phaseName.equalsIgnoreCase("TcCreation")) {
			sql = "SELECT a.resource_id AS ResourceId, concat(c.first_name, ' ', c.last_name) AS ResourceName, a.task_date AS TaskDate, "
					+ "a.connector_id AS ConnectorId, b.name AS ConnectorName, a.hours_spent AS NoOfHours, a.phase AS Phase, a.description AS Description, "
					+ " a.tcs_Created AS TcsCreated, a.tcs_Exec AS TcsExecuted "
					+ "FROM tbl_task a, tbl_connector b, tbl_resource c "
					+ "WHERE phase='Integration Testing (Mocha) - TEST CASE CREATION' "
					+ "and a.tcs_Created IS NOT NULL and "
					+ dateRange
					+ " AND a.connector_id = b.connector_id "
					+ "AND a.resource_id = c.resource_id ORDER BY a.task_date";
		} else if (phaseName != null) {
			sql = "SELECT a.resource_id AS ResourceId, concat(c.first_name, ' ', c.last_name) AS ResourceName, a.task_date AS TaskDate, "
					+ "a.connector_id AS ConnectorId, b.name AS ConnectorName, a.hours_spent AS NoOfHours, a.phase AS Phase, a.description AS Description, "
					+ " a.tcs_Created AS TcsCreated, a.tcs_Exec AS TcsExecuted "
					+ "FROM tbl_task a, tbl_connector b, tbl_resource c "
					+ "WHERE phase='"
					+ phaseName
					+ "' "
					+ dateRange
					+ " AND a.connector_id = b.connector_id "
					+ "AND a.resource_id = c.resource_id ORDER BY a.task_date";
		}
		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("ResourceId", StandardBasicTypes.INTEGER)
				.addScalar("ResourceName", StandardBasicTypes.STRING)
				.addScalar("TaskDate", StandardBasicTypes.DATE)
				.addScalar("ConnectorId", StandardBasicTypes.INTEGER)
				.addScalar("ConnectorName", StandardBasicTypes.STRING)
				.addScalar("Phase", StandardBasicTypes.STRING)
				.addScalar("Description", StandardBasicTypes.STRING)
				.addScalar("NoOfHours", StandardBasicTypes.DOUBLE)
				.addScalar("TcsCreated", StandardBasicTypes.INTEGER)
				.addScalar("TcsExecuted", StandardBasicTypes.INTEGER);

		query.setResultTransformer(Transformers
				.aliasToBean(TaskEffortsByConnector.class));
		return query.list();
	}

	@Override
	public Object getEffortsByConnectorIdAndDate(Integer connectorIds,
			String startDate, String endDate) throws Exception {
		// TODO Auto-generated method stub
		String sql = "SELECT sum(hours_spent) / 8 AS Days FROM tbl_task WHERE connector_id = "
				+ connectorIds
				+ " AND task_date >= '"
				+ startDate
				+ "' AND task_date <= '" + endDate + "' GROUP BY connector_id";
		Session session = getSession();
		Query query = session.createSQLQuery(sql);
		return query.uniqueResult();
	}

	@Override
	public List<Task> findByidAndDate(Integer subresourceId, LocalDate toDate,
			LocalDate fromDate) throws Exception {
		// TODO Auto-generated method stub

		Criteria criteria = createEntityCriteria();
		if (subresourceId != -1) {
			criteria.add(Restrictions.eq("resourceId", subresourceId));
		}
		criteria.add(Restrictions.ge("taskDate", toDate));
		criteria.add(Restrictions.le("taskDate", fromDate));
		List<Task> tasks = criteria.list();
		if (tasks != null && tasks.size() > 0) {
			return tasks;
		} else {
			return null;
		}
	}
}