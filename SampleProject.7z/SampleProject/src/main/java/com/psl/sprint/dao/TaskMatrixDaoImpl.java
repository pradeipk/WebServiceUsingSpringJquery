package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.TaskMatrix;

@Repository("taskMatrixDaoImpl")
public class TaskMatrixDaoImpl extends AbstractDao<Integer, TaskMatrix>   implements TaskMatrixDao {

	@Override
	public TaskMatrix findById(int id) throws Exception {
		return getByKey(id);
	}

	@Override
	public void saveSubtaskMatrix(TaskMatrix subtask) throws Exception {
		persist(subtask);
	}

	@Override
	public void updateSubtaskMatrix(TaskMatrix subtask) throws Exception {
	}

	@Override
	public void deleteSubtaskMatrix(Integer id) throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public List<TaskMatrix> findAllSubtaskMatrix() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TaskMatrix findSubtaskByRequirementIDAndTaskID(Integer requirementId, Integer taskId) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("requirement_id", requirementId)).add(Restrictions.eq("task_id", taskId));
		return (TaskMatrix) criteria.list().get(0);
	}
}
