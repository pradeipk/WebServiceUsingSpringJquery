package com.psl.sprint.dao;


public interface TemporaryResultsDao extends GenericDao {
}
