package com.psl.sprint.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.psl.sprint.model.TemporaryResults;

@Repository("temporaryResultsDao")
public class TemporaryResultsDaoImpl extends
		AbstractDao<Integer, TemporaryResults> implements TemporaryResultsDao {

	@Override
	public List<?> findByName(Object object) throws Exception {
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((TemporaryResults) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((TemporaryResults) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((TemporaryResults) object);
	}

	@Override
	public List<TemporaryResults> findAll() throws Exception {
		return null;
	}

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}
}