package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.HibernateException;

import com.psl.sprint.dto.ResourceDTO;
import com.psl.sprint.model.Resource;

public interface UserDao extends GenericDao {

	@SuppressWarnings("unchecked")
	public List<?> findAllResourcesForSpecificDateRange()
			throws HibernateException, Exception;

	public List<ResourceDTO> getAllResources() throws Exception;

	public List<?> findAll(boolean edit, Integer rmID) throws Exception;

	public Resource findByIP(String hostname) throws Exception;

	public List<Resource> findAllLeadsAndDualLeads() throws Exception;

	public Resource findResourceById(Integer id) throws Exception;

	public List<Resource> findResourcesBYRmId(Integer id) throws Exception;
}
