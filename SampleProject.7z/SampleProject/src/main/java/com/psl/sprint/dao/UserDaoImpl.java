package com.psl.sprint.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StandardBasicTypes;
import org.joda.time.LocalDate;
import org.springframework.stereotype.Repository;

import com.psl.sprint.dto.ResourceDTO;
import com.psl.sprint.model.Resource;
import com.psl.sprint.util.SprintConstants;

@Repository("userDao")
public class UserDaoImpl extends AbstractDao<Integer, Resource> implements
		UserDao {

	@Override
	public Object findById(Object object) throws Exception {
		return getByKey((Integer) object);
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Resource> findByName(Object object) throws Exception {
		Criteria criteria = createEntityCriteria();
		criteria.add(Restrictions.eq("userName", object));
		return criteria.list();
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		persist((Resource) object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		update((Resource) object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		delete((Resource) object);

	}

	@Override
	@SuppressWarnings("unchecked")
	public List<?> findAll(boolean edit, Integer rmID)
			throws HibernateException, Exception {
		Criteria criteria = createEntityCriteria();
		Criterion dev = Restrictions.eq("jobAssigned", "Development");
		Criterion test = Restrictions.eq("jobAssigned", "Testing");
		Criterion dual_dev = Restrictions.eq("jobAssigned", "Dual_DEV");
		Criterion dual_qa = Restrictions.eq("jobAssigned", "Dual_QA");
		Disjunction orExp = Restrictions.or(dev, test, dual_dev, dual_qa);
		criteria.add(orExp);

		if (rmID != null && rmID != SprintConstants.MASTER_ACCESS_RES_ID_1
				&& rmID != SprintConstants.MASTER_ACCESS_RES_ID_2) {
			criteria.add(Restrictions.eq("resourceManagerId", rmID));
		}

		criteria.addOrder(Order.asc("firstName"));
		List<Resource> resources = criteria.list();
		List<Resource> finalList = new ArrayList<Resource>();

		if (edit == false) {
			for (Resource resource : resources) {
				if (resource.getReleaseDate().isAfter(
						new LocalDate().plusDays(1))) {
					finalList.add(resource);
				}
			}
		} else {
			finalList = resources;
		}
		return finalList;
	}

	@Override
	public List<?> findAllResourcesForSpecificDateRange()
			throws HibernateException, Exception {
		Criteria criteria = createEntityCriteria();
		return null;
	}

	@Override
	public List<ResourceDTO> getAllResources() throws Exception {
		/*
		 * String query =
		 * "SELECT resource.USER_NAME AS userName,resource.RESOURCE_ID AS resourceId, "
		 * +
		 * " GROUP_CONCAT(access_level.ACCESS_LEVEL SEPARATOR ',') AS accessLevelsConcatinate "
		 * +
		 * " FROM tbl_resource AS resource	LEFT JOIN tbl_access_level AS access_level "
		 * +
		 * " ON resource.RESOURCE_ID = access_level.RESOURCE_ID GROUP BY access_level.RESOURCE_ID"
		 * ;
		 */
		String sql = "SELECT resource.USER_NAME AS userName, resource.RESOURCE_ID AS resourceId FROM tbl_resource as resource where resource.job_assigned not in ('Lead', 'Others') and resource.RELEASE_DATE >= CURDATE() ORDER BY userName";

		Session session = getSession();
		Query query = session.createSQLQuery(sql)
				.addScalar("userName", StandardBasicTypes.STRING)
				.addScalar("resourceId", StandardBasicTypes.INTEGER);

		query.setResultTransformer(Transformers.aliasToBean(ResourceDTO.class));
		List<ResourceDTO> reportDataList = query.list();
		return reportDataList;
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Resource findByIP(String hostname) throws Exception {
		Criteria criteria = createEntityCriteria();
		Criterion ip = Restrictions.eq("ip", hostname);
		Criterion ip4 = Restrictions.eq("ip4", hostname);
		Criterion ip6 = Restrictions.eq("ip6", hostname);
		Disjunction or = Restrictions.or(ip, ip4, ip6);
		criteria.add(or);
		List list = criteria.list();
		if (list != null && list.size() > 0 && list.get(0) != null) {
			return (Resource) list.get(0);
		} else {
			return null;
		}
	}

	@Override
	public List<Resource> findAllLeadsAndDualLeads() throws Exception {
		Criteria criteria = createEntityCriteria();
		Criterion lead_dev = Restrictions.eq("jobAssigned", "Lead_DEV");
		Criterion lead_qa = Restrictions.eq("jobAssigned", "Lead_QA");
		Criterion dualDev = Restrictions.eq("jobAssigned", "Dual_DEV");
		Criterion dualQa = Restrictions.eq("jobAssigned", "Dual_QA");
		Disjunction orExp = Restrictions.or(lead_dev, lead_qa, dualDev, dualQa);
		criteria.add(orExp);
		List<Resource> resources = criteria.list();
		return resources;
	}

	@Override
	public Resource findResourceById(Integer id) throws Exception {
		Criteria criteria = createEntityCriteria();
		Criterion checkDevOrQA = Restrictions.eq("resourceId", id);
		criteria.add(checkDevOrQA);
		List<Resource> resources = criteria.list();
		return resources.get(0);

	}

	@Override
	public List<Resource> findResourcesBYRmId(Integer id) throws Exception {
		// TODO Auto-generated method stub
		Criteria criteria = createEntityCriteria();
		Criterion subResouces = Restrictions.eq("resourceManagerId", id);
		criteria.add(subResouces);
		List<Resource> resources = criteria.list();
		if (resources != null && resources.size() > 0) {
			return resources;
		} else {
			return null;
		}
	}
}
