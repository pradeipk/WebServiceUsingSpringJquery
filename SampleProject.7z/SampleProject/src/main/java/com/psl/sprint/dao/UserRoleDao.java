package com.psl.sprint.dao;

public interface UserRoleDao extends GenericDao{

	void deleteNonReferencedRoles() throws Exception;

}
