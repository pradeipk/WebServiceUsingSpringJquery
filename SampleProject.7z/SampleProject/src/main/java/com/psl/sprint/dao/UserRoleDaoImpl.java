package com.psl.sprint.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.psl.sprint.model.AccessLevel;

@Repository("userRoleDao")
public class UserRoleDaoImpl extends AbstractDao<Integer, AccessLevel>
		implements UserRoleDao {

	public Object findById(Object object) throws Exception {

		return getByKey((Integer) object);
	}

	@SuppressWarnings("unchecked")
	public List<AccessLevel> findByName(Object object)
			throws HibernateException, Exception {
		return (List<AccessLevel>) createEntityCriteria().add(
				Restrictions.eq(NAME, (String) object)).list();
	}

	public void saveEntity(Object object) throws Exception {
		persist((AccessLevel) object);
	}

	public void updateEntity(Object object) throws Exception {
		update((AccessLevel) object);
	}

	public void deleteEntity(Object object) throws Exception {
		delete((AccessLevel) object);
	}

	@SuppressWarnings("unchecked")
	public List<?> findAll() throws Exception {
		return (List<AccessLevel>) createEntityCriteria().list();

	}

	public void deleteNonReferencedRoles() throws Exception {
		getSession().flush();
		int i = getSession().createSQLQuery(
				"DELETE from tbl_access_level where RESOURCE_ID is null")
				.executeUpdate();

	}

}
