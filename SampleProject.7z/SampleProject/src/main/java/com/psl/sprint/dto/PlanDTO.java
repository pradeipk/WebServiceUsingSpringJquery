package com.psl.sprint.dto;

public class PlanDTO {
	private String requirement;
	private String requirementId;
	private int storypoint;
	private float sprint;
	private Integer id;

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	public int getStorypoint() {
		return storypoint;
	}

	public void setStorypoint(int storypoint) {
		this.storypoint = storypoint;
	}

	public String getRequirementId() {
		return requirementId;
	}

	public void setRequirementId(String requirementId) {
		this.requirementId = requirementId;
	}

	public float getSprint() {
		return sprint;
	}

	public void setSprint(float sprint) {
		this.sprint = sprint;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

}
