package com.psl.sprint.dto;

import java.util.Arrays;

public class ReportDTO {
	private String duration;
	private String startDate;
	private String endDate;
	private String monthYear;
	private int[] resourceIds;
	private String workdate;
	private String userName;
	private String connector;
	private String bandwidthConcat;
	private double bandwidth;
	private double unallocated;
	private String type;

	public int[] getResourceIds() {
		return resourceIds;
	}

	public void setResourceIds(int[] resourceIds) {
		this.resourceIds = resourceIds;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	public String getWorkdate() {
		return workdate;
	}

	public void setWorkdate(String workdate) {
		this.workdate = workdate;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getConnector() {
		return connector;
	}

	public void setConnector(String connector) {
		this.connector = connector;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public double getBandwidth() {
		return bandwidth;
	}

	public void setBandwidth(double bandwidth) {
		this.bandwidth = bandwidth;
	}

	public double getUnallocated() {
		return unallocated;
	}

	public void setUnallocated(double unallocated) {
		this.unallocated = unallocated;
	}

	/**
	 * @return the bandwidthConcat
	 */
	public String getBandwidthConcat() {
		return bandwidthConcat;
	}

	/**
	 * @param bandwidthConcat the bandwidthConcat to set
	 */
	public void setBandwidthConcat(String bandwidthConcat) {
		this.bandwidthConcat = bandwidthConcat;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "ReportDTO [duration=" + duration + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", monthYear=" + monthYear
				+ ", resourceIds=" + Arrays.toString(resourceIds)
				+ ", workdate=" + workdate + ", userName=" + userName
				+ ", connector=" + connector + ", bandwidthConcat="
				+ bandwidthConcat + ", bandwidth=" + bandwidth
				+ ", unallocated=" + unallocated + ", type=" + type + "]";
	}

}