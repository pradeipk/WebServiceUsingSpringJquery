package com.psl.sprint.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.psl.sprint.model.AccessLevel;
import com.psl.sprint.model.Resource;

public class ResourceDTO implements Comparable<ResourceDTO> {

	private Integer resourceId;
	private String firstName;
	private String lastName;
	private String password;
	private String userName;
	private String jobAssigned;
	private String connectorAssigned;
	private String enabled;
	private boolean assigned;
	private Integer connectorId;
	private String accessLevelsConcatinate = null;
	private Set<String> accessLevels = new HashSet<String>();
	private Set<String> resources = new HashSet<String>();
	private Map<String, Integer> userAndId = new HashMap<String, Integer>();
	private List<String> connectorsAllocated = new ArrayList<String>();
	private double current_level;
	private List<Resource> dtos = new ArrayList<Resource>();
	private String name;
	private List<Double> allocations = new ArrayList<Double>();
	private Integer allocationId;
	private boolean allow_editing = true;
	private Double PDs = 0.0;
	private Double exclusions = 0.0;
	private String description;
	private String phaseType;
	private String teamlead;
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate releaseDate;

	@NotNull
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate startDate;

	@NotNull
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate endDate;

	private double new_allocations;

	public LocalDate getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Double getExclusion() {
		return exclusions;
	}

	public void setExclusion(Double exclusions) {
		this.exclusions = exclusions;
	}

	public double getCurrent_level() {
		return current_level;
	}

	public void setCurrent_level(double current_level) {
		this.current_level = current_level;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public double getNew_allocations() {
		return new_allocations;
	}

	public void setNew_allocations(double new_allocations) {
		this.new_allocations = new_allocations;
	}

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getJobAssigned() {
		return jobAssigned;
	}

	public void setJobAssigned(String jobAssigned) {
		this.jobAssigned = jobAssigned;
	}

	public String getConnectorAssigned() {
		return connectorAssigned;
	}

	public void setConnectorAssigned(String connectorAssigned) {
		this.connectorAssigned = connectorAssigned;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public Set<String> getAccessLevels() {
		return accessLevels;
	}

	public void setAccessLevels(Set<String> accessLevels) {
		this.accessLevels = accessLevels;
	}

	public boolean isAssigned() {
		return assigned;
	}

	public void setAssigned(boolean assigned) {
		this.assigned = assigned;
	}

	public ResourceDTO() {
		super();

	}

	public ResourceDTO(Resource resource) {
		if (resource.getConnector() != null) {
			this.connectorAssigned = "Cassandra";// resource.getConnector().getName();
			this.assigned = true;
		} else {
			this.assigned = false;
		}

		this.firstName = resource.getFirstName();
		this.lastName = resource.getLastName();
		this.resourceId = resource.getResourceId();
		this.jobAssigned = resource.getJobAssigned();
		this.releaseDate = resource.getReleaseDate();
		Set<String> accessLevels = new HashSet<String>();
		for (AccessLevel iterable_element : resource.getAccessLevels()) {
			accessLevels.add(iterable_element.getAccessLevel());
		}
		this.accessLevels = accessLevels;

	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public Set<String> getResources() {
		return resources;
	}

	public void setResources(Set<String> resources) {
		this.resources = resources;
	}

	public Map<String, Integer> getUserAndId() {
		return userAndId;
	}

	public void setUserAndId(Map<String, Integer> userAndId) {
		this.userAndId = userAndId;
	}

	public List<String> getConnectorsAllocated() {
		return connectorsAllocated;
	}

	public void setConnectorsAllocated(List<String> connectorsAllocated) {
		this.connectorsAllocated = connectorsAllocated;
	}

	public List<Resource> getDtos() {
		return dtos;
	}

	public void setDtos(List<Resource> dtos) {
		this.dtos = dtos;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Double> getAllocations() {
		return allocations;
	}

	public void setAllocations(List<Double> allocations) {
		this.allocations = allocations;
	}

	public Integer getAllocationId() {
		return allocationId;
	}

	public void setAllocationId(Integer allocationId) {
		this.allocationId = allocationId;
	}

	public boolean isAllow_editing() {
		return allow_editing;
	}

	public void setAllow_editing(boolean allow_editing) {
		this.allow_editing = allow_editing;
	}

	public String getAccessLevelsConcatinate() {
		return accessLevelsConcatinate;
	}

	public void setAccessLevelsConcatinate(String accessLevelsConcatinate) {
		this.accessLevelsConcatinate = accessLevelsConcatinate;
	}

	public Double getPDs() {
		return PDs;
	}

	public void setPDs(Double pDs) {
		PDs = pDs;
	}

	@Override
	public int compareTo(ResourceDTO o) {
		return (this.name).compareTo(o.getName());
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Double getExclusions() {
		return exclusions;
	}

	public void setExclusions(Double exclusions) {
		this.exclusions = exclusions;
	}

	public String getPhaseType() {
		return phaseType;
	}

	public void setPhaseType(String phaseType) {
		this.phaseType = phaseType;
	}
	
	public String getTeamlead() {
		return teamlead;
	}

	public void setTeamlead(String teamlead) {
		this.teamlead = teamlead;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof ResourceDTO))
			return false;
		ResourceDTO that = (ResourceDTO) obj;
		return (this.name.equals(that.getName()));
	}

	@Override
	public int hashCode() {
		if (name != null)
			return name.hashCode();
		else
			return 0;
	}

	@Override
	public String toString() {
		return "ResourceDTO [resourceId=" + resourceId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", password="
				+ password + ", userName=" + userName + ", jobAssigned="
				+ jobAssigned + ", connectorAssigned=" + connectorAssigned
				+ ", enabled=" + enabled + ", assigned=" + assigned
				+ ", connectorId=" + connectorId + ", accessLevelsConcatinate="
				+ accessLevelsConcatinate + ", accessLevels=" + accessLevels
				+ ", resources=" + resources + ", userAndId=" + userAndId
				+ ", connectorsAllocated=" + connectorsAllocated
				+ ", current_level=" + current_level + ", dtos=" + dtos
				+ ", name=" + name + ", allocations=" + allocations
				+ ", allocationId=" + allocationId + ", allow_editing="
				+ allow_editing + ", PDs=" + PDs + ", exclusions=" + exclusions
				+ ", description=" + description + ", phaseType=" + phaseType
				+ ", teamlead=" + teamlead + ", releaseDate=" + releaseDate
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", new_allocations=" + new_allocations + "]";
	}




}
