package com.psl.sprint.dto;

import java.util.ArrayList;
import java.util.List;

import com.psl.sprint.model.AllocationDTO;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ReviewPhase;

public class ResourceWrapper {
	
	private Integer connectorId;
	private String connector;
	private Integer resourceId;
	private Integer QAresourceId;
	private Integer reviewPhaseId;
	
	private List<Connector> listOfConnectors = new ArrayList<>();
	private List<Resource> listOfQAAndLeads =new ArrayList<>();
	private List<ResourceDTO> resourceDTOs = new ArrayList<ResourceDTO>();
	private List<Resource> resource= new ArrayList<>();
	private List<AllocationDTO> allocationDTOs = new ArrayList<AllocationDTO>();
	private List<ReviewPhase> reviewPhaseList = new ArrayList<>();
	private List<ConnectorMaster> listOfConnectorMaster = new ArrayList<>();
	
	public List<ResourceDTO> getResourceDTOs() {
		return resourceDTOs;
	}

	public void setResourceDTOs(List<ResourceDTO> resourceDTOs) {
		this.resourceDTOs = resourceDTOs;
	}

	public String getConnector() {
		return connector;
	}

	public void setConnector(String connector) {
		this.connector = connector;
	}

	public List<AllocationDTO> getAllocationDTOs() {
		return allocationDTOs;
	}

	public void setAllocationDTOs(List<AllocationDTO> allocationDTOs) {
		this.allocationDTOs = allocationDTOs;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public List<Resource> getResource() {
		return resource;
	}

	public void setResource(List<Resource> resource) {
		this.resource = resource;
	}


	public List<Connector> getListOfConnectors() {
		return listOfConnectors;
	}

	public void setListOfConnectors(List<Connector> listOfConnectors) {
		this.listOfConnectors = listOfConnectors;
	}

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public Integer getQAresourceId() {
		return QAresourceId;
	}

	public void setQAresourceId(Integer qAresourceId) {
		QAresourceId = qAresourceId;
	}

	public List<Resource> getListOfQAAndLeads() {
		return listOfQAAndLeads;
	}

	public void setListOfQAAndLeads(List<Resource> listOfQAAndLeads) {
		this.listOfQAAndLeads = listOfQAAndLeads;
	}
	
	public List<ReviewPhase> getReviewPhaseList() {
		return reviewPhaseList;
	}

	public void setReviewPhaseList(List<ReviewPhase> reviewPhaseList) {
		this.reviewPhaseList = reviewPhaseList;
	}

	public Integer getReviewPhaseId() {
		return reviewPhaseId;
	}

	public void setReviewPhaseId(Integer reviewPhaseId) {
		this.reviewPhaseId = reviewPhaseId;
	}

	public List<ConnectorMaster> getListOfConnectorMaster() {
		return listOfConnectorMaster;
	}

	public void setListOfConnectorMaster(List<ConnectorMaster> listOfConnectorMaster) {
		this.listOfConnectorMaster = listOfConnectorMaster;
	}


}
