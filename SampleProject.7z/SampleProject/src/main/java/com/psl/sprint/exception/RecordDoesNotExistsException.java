package com.psl.sprint.exception;

public class RecordDoesNotExistsException extends Exception {

	public RecordDoesNotExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RecordDoesNotExistsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RecordDoesNotExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RecordDoesNotExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
