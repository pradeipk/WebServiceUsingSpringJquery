package com.psl.sprint.model;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.LocalDate;

public class AllocationDTO {
	
	private String connector_name;	
	private LocalDate startDate;	
	private LocalDate endDate;
	private Double allocation_share;
	private List<Double> avail_allocation = new ArrayList<Double>();
	private Integer allocationId;
	private Integer resourceId;
	private String resourceName;
	private Double avaliable_bandwith;
	private Integer connectorId;
	public String getConnector_name() {
		return connector_name;
	}
	public void setConnector_name(String connector_name) {
		this.connector_name = connector_name;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public Double getAllocation_share() {
		return allocation_share;
	}
	public void setAllocation_share(Double allocation_share) {
		this.allocation_share = allocation_share;
	}
	public List<Double> getAvail_allocation() {
		return avail_allocation;
	}
	public void setAvail_allocation(List<Double> avail_allocation) {
		this.avail_allocation = avail_allocation;
	}
	public Integer getAllocationId() {
		return allocationId;
	}
	public void setAllocationId(Integer allocationId) {
		this.allocationId = allocationId;
	}
	public Integer getResourceId() {
		return resourceId;
	}
	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public Double getAvaliable_bandwith() {
		return avaliable_bandwith;
	}
	public void setAvaliable_bandwith(Double avaliable_bandwith) {
		this.avaliable_bandwith = avaliable_bandwith;
	}
	public Integer getConnectorId() {
		return connectorId;
	}
	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}
	
	
}
