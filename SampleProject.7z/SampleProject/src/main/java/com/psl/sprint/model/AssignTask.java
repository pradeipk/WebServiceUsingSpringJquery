package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_assign_task")
public class AssignTask {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	//@NotEmpty
	//@Size(min = 3, max = 50)
	@Column(name = "CONNECTOR_ID", nullable = false)
	private Integer connector_id;
	
	//@NotEmpty
	//@Size(min = 3, max = 50)
	@Column(name = "REQUIREMENT_ID", nullable = false)
	private Integer requirement_id;

	
	//@NotEmpty
	//@Size(min = 3, max = 50)
	@Column(name = "SUBTASK_ID", nullable = false)
	private Integer subtask_id;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Integer getConnector_id() {
		return connector_id;
	}


	public void setConnector_id(Integer connector_id) {
		this.connector_id = connector_id;
	}


	public Integer getRequirement_id() {
		return requirement_id;
	}


	public void setRequirement_id(Integer requirement_id) {
		this.requirement_id = requirement_id;
	}


	public Integer getSubtask_id() {
		return subtask_id;
	}


	public void setSubtask_id(Integer subtask_id) {
		this.subtask_id = subtask_id;
	}			

}
