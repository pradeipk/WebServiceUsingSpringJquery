package com.psl.sprint.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.hibernate.validator.constraints.NotEmpty;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_connector")
public class Connector {

	@Id
	@Column(name = "CONNECTOR_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "NAME", nullable = false, unique = true)
	private String name;

	// @NotNull
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "START_DATE", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate startDate;

	@Column(name = "STATUS", nullable = false)
	private String status;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "OWNER", unique = false, nullable = false)
	private String owner;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "PSL_SME", unique = false, nullable = false)
	private String pslSME;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "IBM_SME", unique = false, nullable = false)
	private String ibmSME;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "CONNECTOR_ID")
	private Set<FunctionalRequrement> requrements = new HashSet<FunctionalRequrement>();

	// Changed relationship from one to many to many to many to provision
	// partial allocation.
	/*
	 * @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "CONNECTOR_ID")
	 */

	@ManyToMany(cascade = { CascadeType.ALL })
	@JoinTable(name = "tbl_connector_resource", joinColumns = { @JoinColumn(name = "CONNECTOR_ID") }, inverseJoinColumns = { @JoinColumn(name = "RESOURCE_ID") })
	private Set<Resource> resources = new HashSet<Resource>();

	@Column(name = "CATEGORY", nullable = true)
	private String category;

	@Column(name = "CATEGORY_EXTERNAL", nullable = true)
	private String categoryExternal;

	@Column(name = "STORY_POINTS", nullable = true)
	private Integer storyPoints;

	@Column(name = "ESTIMATED_PDS", nullable = true)
	private Double estimatedPds;

	@Column(name = "ESTIMATED_PDS_EXTERNAL", nullable = true)
	private Double estimatedPdsExternal;

	@Column(name = "ESTIMATED_PDS_QA", nullable = true)
	private Double estimatedPdsQa;

	@Column(name = "ESTIMATED_PDS_EXTERNAL_QA", nullable = true)
	private Double estimatedPdsExternalQa;

	@Column(name = "JIRA_ID", nullable = true)
	private String jiraId;

	@Column(name = "STORY_POINTS_QA", nullable = true)
	private Integer storyPointsQa;

	@Column(name = "CONN_MASTER_ID", nullable = true)
	private Integer connectorParentId;

	@Column(name = "CONNECTOR_TYPE", nullable = true)
	private Integer connectorType;

	@Column(name = "INITIAL_PDS", nullable = true)
	private Integer initialPds;

	@Column(name = "IS_EXEMPTED", nullable = true)
	private Byte isExempted;
	
	@Column(name = "EPIC_LINK", nullable = true)
	private String epicLink;

    @OneToMany(mappedBy = "connectorLead")
	private Set<ConnectorLeadMapping> connectorLeadMapping;

	public String getPslSME() {
		return pslSME;
	}

	public void setPslSME(String pslSME) {
		this.pslSME = pslSME;
	}

	public String getIbmSME() {
		return ibmSME;
	}

	public void setIbmSME(String ibmSME) {
		this.ibmSME = ibmSME;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		if (startDate == null)
			this.startDate = new LocalDate();
		else {
			this.startDate = startDate;
		}
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public Set<FunctionalRequrement> getRequrements() {
		return requrements;
	}

	public void setRequrements(Set<FunctionalRequrement> requrements) {
		this.requrements = requrements;
	}

	public Set<Resource> getResources() {
		return resources;
	}

	public void setResources(Set<Resource> resources) {
		this.resources = resources;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getStoryPoints() {
		return storyPoints;
	}

	public void setStoryPoints(Integer storyPoints) {
		this.storyPoints = storyPoints;
	}

	public Double getEstimatedPds() {
		return estimatedPds;
	}

	public void setEstimatedPds(Double estimatedPds) {
		this.estimatedPds = estimatedPds;
	}

	public String getCategoryExternal() {
		return categoryExternal;
	}

	public void setCategoryExternal(String categoryExternal) {
		this.categoryExternal = categoryExternal;
	}

	public Double getEstimatedPdsExternal() {
		return estimatedPdsExternal;
	}

	public void setEstimatedPdsExternal(Double estimatedPdsExternal) {
		this.estimatedPdsExternal = estimatedPdsExternal;
	}

	public String getJiraId() {
		return jiraId;
	}

	public void setJiraId(String jiraId) {
		this.jiraId = jiraId;
	}

	public Double getEstimatedPdsQa() {
		return estimatedPdsQa;
	}

	public void setEstimatedPdsQa(Double estimatedPdsQa) {
		this.estimatedPdsQa = estimatedPdsQa;
	}

	public Double getEstimatedPdsExternalQa() {
		return estimatedPdsExternalQa;
	}

	public void setEstimatedPdsExternalQa(Double estimatedPdsExternalQa) {
		this.estimatedPdsExternalQa = estimatedPdsExternalQa;
	}

	public Integer getStoryPointsQa() {
		return storyPointsQa;
	}

	public void setStoryPointsQa(Integer storyPointsQa) {
		this.storyPointsQa = storyPointsQa;
	}

	public Integer getConnectorParentId() {
		return connectorParentId;
	}

	public void setConnectorParentId(Integer connectorParentId) {
		this.connectorParentId = connectorParentId;
	}

	public Integer getConnectorType() {
		return connectorType;
	}

	public void setConnectorType(Integer connectorType) {
		this.connectorType = connectorType;
	}

	public Integer getInitialPds() {
		return initialPds;
	}

	public void setInitialPds(Integer initialPds) {
		this.initialPds = initialPds;
	}

	public Byte getIsExempted() {
		return isExempted;
	}
	
	public void setIsExempted(Byte isExempted) {
		this.isExempted = isExempted;
	}

	public String getEpicLink() {
		return epicLink;
	}

	public void setEpicLink(String epicLink) {
		this.epicLink = epicLink;
	}

	@Override
	public String toString() {
		return "Connector [id=" + id + ", name=" + name + ", startDate="
				+ startDate + ", status=" + status + ", owner=" + owner
				+ ", pslSME=" + pslSME + ", ibmSME=" + ibmSME
				+ ", requrements=" + requrements + ", resources=" + resources
				+ ", category=" + category + ", categoryExternal="
				+ categoryExternal + ", storyPoints=" + storyPoints
				+ ", estimatedPds=" + estimatedPds + ", estimatedPdsExternal="
				+ estimatedPdsExternal + ", estimatedPdsQa=" + estimatedPdsQa
				+ ", estimatedPdsExternalQa=" + estimatedPdsExternalQa
				+ ", jiraId=" + jiraId + ", storyPointsQa=" + storyPointsQa
				+ ", connectorParentId=" + connectorParentId
				+ ", connectorType=" + connectorType + ", initialPds="
				+ initialPds + ", isExempted=" + isExempted + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Connector))
			return false;
		Connector other = (Connector) obj;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public Set<ConnectorLeadMapping> getConnectorLeadMapping() {
		return connectorLeadMapping;
	}

	public void setConnectorLeadMapping(Set<ConnectorLeadMapping> connectorLeadMapping) {
		this.connectorLeadMapping = connectorLeadMapping;
	}

}