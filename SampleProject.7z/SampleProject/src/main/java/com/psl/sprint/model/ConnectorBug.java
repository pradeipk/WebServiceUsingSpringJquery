package com.psl.sprint.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_connector_bug")
public class ConnectorBug {

	@Id
	@Column(name = "bug_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "fixed")
	private Integer fixed;

	@Column(name = "not_a_bug")
	private Integer notABug;

	@Column(name = "invalid")
	private Integer invalid;

	@Column(name = "duplicate")
	private Integer duplicate;

	@Column(name = "tcs_created")
	private Integer tcsCreated;
	
	@Column(name = "tcs_executed")
	private Integer tcsExecuted;

	@Column(name = "connector_id")
	private Integer connectorId;

	@Column(name = "defect_leakage")
	private Integer defectLeakage;

	@Column(name = "velocity")
	private Integer velocity;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getFixed() {
		return fixed;
	}

	public void setFixed(Integer fixed) {
		this.fixed = fixed;
	}

	public Integer getNotABug() {
		return notABug;
	}

	public void setNotABug(Integer notABug) {
		this.notABug = notABug;
	}

	public Integer getInvalid() {
		return invalid;
	}

	public void setInvalid(Integer invalid) {
		this.invalid = invalid;
	}

	public Integer getDuplicate() {
		return duplicate;
	}

	public void setDuplicate(Integer duplicate) {
		this.duplicate = duplicate;
	}

	public Integer getTcsCreated() {
		return tcsCreated;
	}

	public void setTcsCreated(Integer tcsCreated) {
		this.tcsCreated = tcsCreated;
	}


	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public Integer getTcsExecuted() {
		return tcsExecuted;
	}

	public void setTcsExecuted(Integer tcsExecuted) {
		this.tcsExecuted = tcsExecuted;
	}

	public Integer getDefectLeakage() {
		return defectLeakage;
	}

	public void setDefectLeakage(Integer defectLeakage) {
		this.defectLeakage = defectLeakage;
	}

	public Integer getVelocity() {
		return velocity;
	}

	public void setVelocity(Integer velocity) {
		this.velocity = velocity;
	}

	@Override
	public String toString() {
		return "ConnectorBug [id=" + id + ", fixed=" + fixed + ", notABug="
				+ notABug + ", invalid=" + invalid + ", duplicate=" + duplicate
				+ ", tcsCreated=" + tcsCreated + ", tcsExecuted=" + tcsExecuted
				+ ", connectorId=" + connectorId + ", defectLeakage="
				+ defectLeakage + ", velocity=" + velocity + "]";
	}

}