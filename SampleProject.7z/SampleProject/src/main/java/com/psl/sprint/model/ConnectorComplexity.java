package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_connector_complexity")
public class ConnectorComplexity {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "connector_id")
	private Integer connectorId;
	
	@Column(name = "hid")
	private Integer hId;
	
	@Column(name = "complexity")
	private Double complexity;
	
	@Column(name = "pds")
	private Double pds;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public Integer gethId() {
		return hId;
	}

	public void sethId(Integer hId) {
		this.hId = hId;
	}

	public Double getComplexity() {
		return complexity;
	}

	public void setComplexity(Double complexity) {
		this.complexity = complexity;
	}

	public Double getPds() {
		return pds;
	}

	public void setPds(Double pds) {
		this.pds = pds;
	}

	@Override
	public String toString() {
		return "ConnectorComplexity [id=" + id + ", connectorId=" + connectorId
				+ ", hId=" + hId + ", complexity=" + complexity + ", pds="
				+ pds + "]";
	}	
}