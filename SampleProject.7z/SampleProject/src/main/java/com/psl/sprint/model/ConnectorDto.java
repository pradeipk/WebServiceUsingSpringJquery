package com.psl.sprint.model;

public class ConnectorDto {
	private int connectorId;
	private String connectorName;
	private String requirement;
	private String subtask;

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	public String getSubtask() {
		return subtask;
	}

	public void setSubtask(String subtask) {
		this.subtask = subtask;
	}

	public int getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(int connectorId) {
		this.connectorId = connectorId;
	}

	@Override
	public String toString() {
		return "ConnectorDto [connectorId=" + connectorId + ", connectorName="
				+ connectorName + ", requirement=" + requirement + ", subtask="
				+ subtask + "]";
	}

}
