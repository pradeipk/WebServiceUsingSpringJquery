package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_connectoretmapping")
public class ConnectorEstimationMapping {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "connector_id")
	private Integer connectorId;
	
	@Column(name = "hid")
	private Integer hid;
	
	@Column(name = "shid")
	private Integer shid;
	
	@Column(name = "qid")
	private Integer qid;
	
	@Column(name = "pds")
	private Double pds;

	@Column(name = "message")
	private String message;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public Integer getHid() {
		return hid;
	}

	public void setHid(Integer hid) {
		this.hid = hid;
	}

	public Integer getShid() {
		return shid;
	}

	public void setShid(Integer shid) {
		this.shid = shid;
	}

	public Integer getQid() {
		return qid;
	}

	public void setQid(Integer qid) {
		this.qid = qid;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Double getPds() {
		return pds;
	}

	public void setPds(Double pds) {
		this.pds = pds;
	}

	@Override
	public String toString() {
		return "ConnectorEstimationMapping [id=" + id + ", connectorId="
				+ connectorId + ", hid=" + hid + ", shid=" + shid + ", qid="
				+ qid + ", pds=" + pds + ", message=" + message + "]";
	}
}
