package com.psl.sprint.model;

import java.sql.Date;

import javax.persistence.Column;

public class ConnectorIssueList {
	
	@Column(name = "IssueID")
	private Integer issueID;
	
	@Column(name = "IssueTitle")
	private String issueTitle;
	
	@Column(name = "GitIssueLink")
	private String gitIssueLink;

	@Column(name = "CreatedDate")
	private Date createdDate;
	
	@Column(name = "GitIssueDate")
	private Date gitIssueDate;
	
	@Column(name = "ConnectorId")
	private Integer connectorId;
	
	@Column(name = "ConnectorName")
	private String connectorName;
	
	@Column(name = "Description")
	private String description;

	public Integer getIssueID() {
		return issueID;
	}

	public void setIssueID(Integer issueID) {
		this.issueID = issueID;
	}

	public String getIssueTitle() {
		return issueTitle;
	}

	public void setIssueTitle(String issueTitle) {
		this.issueTitle = issueTitle;
	}

	public String getGitIssueLink() {
		return gitIssueLink;
	}

	public void setGitIssueLink(String gitIssueLink) {
		this.gitIssueLink = gitIssueLink;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Date getGitIssueDate() {
		return gitIssueDate;
	}

	public void setGitIssueDate(Date gitIssueDate) {
		this.gitIssueDate = gitIssueDate;
	}

	@Override
	public String toString() {
		return "ConnectorIssueList [issueID=" + issueID + ", issueTitle="
				+ issueTitle + ", gitIssueLink=" + gitIssueLink
				+ ", createdDate=" + createdDate + ", gitIssueDate="
				+ gitIssueDate + ", connectorId=" + connectorId
				+ ", connectorName=" + connectorName + ", description="
				+ description + "]";
	}
}