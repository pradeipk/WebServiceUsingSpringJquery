package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_connector_lead_mapping")
public class ConnectorLeadMapping {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@ManyToOne
	@JoinColumn(name = "connector_id",referencedColumnName="CONNECTOR_ID")
	private Connector connectorLead;


	@ManyToOne
	@JoinColumn(name = "qa_resource_id",referencedColumnName="RESOURCE_ID")
	private Resource qaResource;


	@ManyToOne
	@JoinColumn(name = "dev_resource_id",referencedColumnName="RESOURCE_ID")
	private Resource devResource;

	@Column(name = "admin")
	private String admin;
	
	@ManyToOne
	@JoinColumn(name = "sme_id",referencedColumnName="RESOURCE_ID")
	private Resource smeResource;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getAdmin() {
		return admin;
	}
	
	public void setAdmin(String admin) {
		this.admin = admin;
	}
	
	public Connector getConnector() {
		return connectorLead;
	}
	
	public void setConnector(Connector connectorLead) {
		this.connectorLead = connectorLead;
	}
	
	public Resource getQaResource() {
		return qaResource;
	}
	
	public void setQaResource(Resource qaResource) {
		this.qaResource = qaResource;
	}
	
	public Resource getDevResource() {
		return devResource;
	}
	
	public void setDevResource(Resource devResource) {
		this.devResource = devResource;
	}
	
	public Connector getConnectorLead() {
		return connectorLead;
	}
	
	public void setConnectorLead(Connector connectorLead) {
		this.connectorLead = connectorLead;
	}
	
	public Resource getSmeResource() {
		return smeResource;
	}
	
	public void setSmeResource(Resource smeResource) {
		this.smeResource = smeResource;
	}
}
