package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_connector_master")
public class ConnectorMaster {
	@Id
	@Column(name = "connectorMID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "connectorName")
	private String connectorName;

	@Column(name = "connectorStatus")
	private Integer connectorStatus;

	@Column(name = "pslLead")
	private String pslLead;

	@Column(name = "pslSME")
	private String pslSME;
	
	@Column(name = "templateVersion")
	private String templateVersion;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public Integer getConnectorStatus() {
		return connectorStatus;
	}

	public void setConnectorStatus(Integer connectorStatus) {
		this.connectorStatus = connectorStatus;
	}
	
	public String getPslLead() {
		return pslLead;
	}

	public void setPslLead(String pslLead) {
		this.pslLead = pslLead;
	}

	public String getPslSME() {
		return pslSME;
	}

	public void setPslSME(String pslSME) {
		this.pslSME = pslSME;
	}

	public String getTemplateVersion() {
		return templateVersion;
	}

	public void setTemplateVersion(String templateVersion) {
		this.templateVersion = templateVersion;
	}

	@Override
	public String toString() {
		return "ConnectorMaster [id=" + id + ", connectorName=" + connectorName
				+ ", connectorStatus=" + connectorStatus + ", pslLead="
				+ pslLead + ", pslSME=" + pslSME + ", templateVersion="
				+ templateVersion + "]";
	}
}
