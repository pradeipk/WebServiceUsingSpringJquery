package com.psl.sprint.model;

import java.sql.Date;

import javax.persistence.Column;

public class ConnectorPlannedCompletion {
	
	@Column(name = "ConnectorId", nullable = true)
	private Integer connectorId;

	@Column(name = "ConnectorName", nullable = true)
	private String connectorName;

	@Column(name = "PlannedCompletionDate", nullable = true)
	private Date plannedCompletionDate;
	
	@Column(name = "Notes", nullable = true)
	private String notes;

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public Date getPlannedCompletionDate() {
		return plannedCompletionDate;
	}

	public void setPlannedCompletionDate(Date plannedCompletionDate) {
		this.plannedCompletionDate = plannedCompletionDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	@Override
	public String toString() {
		return "ConnectorPlannedCompletion [connectorId=" + connectorId
				+ ", connectorName=" + connectorName
				+ ", plannedCompletionDate=" + plannedCompletionDate
				+ ", notes=" + notes + "]";
	}
}
