package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_efforts_estimation_master")
public class EffortsEstimationMaster {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "hid")
	private Integer hid;
	
	@Column(name = "tiny")
	private Integer tiny;
	
	@Column(name = "simple")
	private Integer simple;
	
	@Column(name = "medium")
	private Integer medium;
	
	@Column(name = "complex")
	private Integer complex;
	
	@Column(name = "dev_share")
	private Double devShare;
	
	@Column(name = "qa_share")
	private Double qaShare;
	
	@Column(name = "template_version")
	private String templateVersion;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getHid() {
		return hid;
	}

	public void setHid(Integer hid) {
		this.hid = hid;
	}
	
	public Integer getTiny() {
		return tiny;
	}
	
	public void setTiny(Integer tiny) {
		this.tiny = tiny;
	}

	public Integer getSimple() {
		return simple;
	}

	public void setSimple(Integer simple) {
		this.simple = simple;
	}

	public Integer getMedium() {
		return medium;
	}

	public void setMedium(Integer medium) {
		this.medium = medium;
	}

	public Integer getComplex() {
		return complex;
	}

	public void setComplex(Integer complex) {
		this.complex = complex;
	}

	public String getTemplateVersion() {
		return templateVersion;
	}

	public void setTemplateVersion(String templateVersion) {
		this.templateVersion = templateVersion;
	}

	public Double getDevShare() {
		return devShare;
	}

	public void setDevShare(Double devShare) {
		this.devShare = devShare;
	}

	public Double getQaShare() {
		return qaShare;
	}

	public void setQaShare(Double qaShare) {
		this.qaShare = qaShare;
	}

	@Override
	public String toString() {
		return "EffortsEstimationMaster [id=" + id + ", hid=" + hid + ", tiny="
				+ tiny + ", simple=" + simple + ", medium=" + medium
				+ ", complex=" + complex + ", devShare=" + devShare
				+ ", qaShare=" + qaShare + ", templateVersion="
				+ templateVersion + "]";
	}

}
