package com.psl.sprint.model;

import org.springframework.web.multipart.MultipartFile;

public class EstimatedPlan {
	private int fileId;
	private int connectorId;
	private String category;
	private String categoryExternal;
	private int storyPoints;
	private double estimatedPDS;
	private double estimatedPDSExternal;
	private MultipartFile estimatedPdf;
	private MultipartFile estimatedPdfExternal;
	private String action;

	public int getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(int connectorId) {
		this.connectorId = connectorId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getStoryPoints() {
		return storyPoints;
	}

	public void setStoryPoints(int storyPoints) {
		this.storyPoints = storyPoints;
	}

	public double getEstimatedPDS() {
		return estimatedPDS;
	}

	public void setEstimatedPDS(double estimatedPDS) {
		this.estimatedPDS = estimatedPDS;
	}

	public MultipartFile getEstimatedPdf() {
		return estimatedPdf;
	}

	public void setEstimatedPdf(MultipartFile estimatedPdf) {
		this.estimatedPdf = estimatedPdf;
	}

	public int getFileId() {
		return fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getCategoryExternal() {
		return categoryExternal;
	}

	public void setCategoryExternal(String categoryExternal) {
		this.categoryExternal = categoryExternal;
	}

	public double getEstimatedPDSExternal() {
		return estimatedPDSExternal;
	}

	public void setEstimatedPDSExternal(double estimatedPDSExternal) {
		this.estimatedPDSExternal = estimatedPDSExternal;
	}

	public MultipartFile getEstimatedPdfExternal() {
		return estimatedPdfExternal;
	}

	public void setEstimatedPdfExternal(MultipartFile estimatedPdfExternal) {
		this.estimatedPdfExternal = estimatedPdfExternal;
	}

	@Override
	public String toString() {
		return "EstimatedPlan [fileId=" + fileId + ", connectorId="
				+ connectorId + ", category=" + category
				+ ", categoryExternal=" + categoryExternal + ", storyPoints="
				+ storyPoints + ", estimatedPDS=" + estimatedPDS
				+ ", estimatedPDSExternal=" + estimatedPDSExternal
				+ ", estimatedPdf=" + estimatedPdf + ", estimatedPdfExternal="
				+ estimatedPdfExternal + ", action=" + action + "]";
	}
}
