package com.psl.sprint.model;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_estimates_pdf")
public class EstimatesPDF {

	@Id
	@Column(name = "file_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "file_content", nullable = false)
	private Blob fileContent;

	@Column(name = "content_type", nullable = false)
	private String contentType;

	@Column(name = "file_name", nullable = false)
	private String fileName;
	
	@Column(name = "file_content_external", nullable = false)
	private Blob fileContentExternal;

	@Column(name = "content_type_external", nullable = false)
	private String contentTypeExternal;

	@Column(name = "file_name_external", nullable = false)
	private String fileNameExternal;

	@Column(name = "connector_id", nullable = false)
	private int connectorId;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Blob getFileContent() {
		return fileContent;
	}

	public void setFileContent(Blob fileContent) {
		this.fileContent = fileContent;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(int connectorId) {
		this.connectorId = connectorId;
	}

	public Blob getFileContentExternal() {
		return fileContentExternal;
	}

	public void setFileContentExternal(Blob fileContentExternal) {
		this.fileContentExternal = fileContentExternal;
	}

	public String getContentTypeExternal() {
		return contentTypeExternal;
	}

	public void setContentTypeExternal(String contentTypeExternal) {
		this.contentTypeExternal = contentTypeExternal;
	}

	public String getFileNameExternal() {
		return fileNameExternal;
	}

	public void setFileNameExternal(String fileNameExternal) {
		this.fileNameExternal = fileNameExternal;
	}

	@Override
	public String toString() {
		return "EstimatesPDF [id=" + id + ", fileContent=" + fileContent
				+ ", contentType=" + contentType + ", fileName=" + fileName
				+ ", fileContentExternal=" + fileContentExternal
				+ ", contentTypeExternal=" + contentTypeExternal
				+ ", fileNameExternal=" + fileNameExternal + ", connectorId="
				+ connectorId + "]";
	}
}