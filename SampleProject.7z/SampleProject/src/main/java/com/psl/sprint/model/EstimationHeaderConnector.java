package com.psl.sprint.model;

import javax.persistence.Column;

public class EstimationHeaderConnector {
	
	@Column(name = "hid")
	private Integer hid;
	
	@Column(name = "connectorId")
	private Integer connectorId;

	@Column(name = "header")
	private String header;

	@Column(name = "connectorType")
	private String connectorType;

	public Integer getHid() {
		return hid;
	}

	public void setHid(Integer hid) {
		this.hid = hid;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getConnectorType() {
		return connectorType;
	}

	public void setConnectorType(String connectorType) {
		this.connectorType = connectorType;
	}

	@Override
	public String toString() {
		return "EstimationHeaderConnector [hid=" + hid + ", connectorId="
				+ connectorId + ", header=" + header + ", connectorType="
				+ connectorType + "]";
	}

}
