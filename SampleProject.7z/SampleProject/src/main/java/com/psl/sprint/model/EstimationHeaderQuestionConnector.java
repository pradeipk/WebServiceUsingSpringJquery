package com.psl.sprint.model;

import javax.persistence.Column;

public class EstimationHeaderQuestionConnector {
	
	@Column(name = "hid")
	private Integer hid;
	
	@Column(name = "header")
	private String header;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "optionSelected")
	private String optionSelected;
	
	@Column(name="pds")
    private Double pds;
	
	public Integer getHid() {
		return hid;
	}

	public void setHid(Integer hid) {
		this.hid = hid;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOptionSelected() {
		return optionSelected;
	}

	public void setOptionSelected(String optionSelected) {
		this.optionSelected = optionSelected;
	}

	public Double getPds() {
		return pds;
	}

	public void setPds(Double pds) {
		this.pds = pds;
	}
	
	@Override
	public String toString() {
		return "EstimationHeaderQuestionConnector [hid=" + hid + ", header="
				+ header + ", description=" + description + ", optionSelected="
				+ optionSelected + ",pds="+pds+"]";
	}

}
