package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_etheaders")
public class EstimationHeaders {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "SDLCPhaseTask", nullable = false)
	private String SDLCPhaseTask;

	@Column(name = "Type", nullable = false)
	private String Type;

	@Column(name = "Template_Version", nullable = false)
	private String TemplateVersion;

	public String getTemplateVersion() {
		return TemplateVersion;
	}

	public void setTemplateVersion(String templateVersion) {
		TemplateVersion = templateVersion;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSDLCPhaseTask() {
		return SDLCPhaseTask;
	}

	public void setSDLCPhaseTask(String sDLCPhaseTask) {
		SDLCPhaseTask = sDLCPhaseTask;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

}
