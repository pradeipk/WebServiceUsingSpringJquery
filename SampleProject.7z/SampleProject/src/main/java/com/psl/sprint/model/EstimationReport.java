package com.psl.sprint.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="estimation_report")
public class EstimationReport {
    
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer id;

	
	@Column(name = "CONNECTOR_ID")
	private Integer connector_id;

	@NotEmpty
	@Column(name = "STATUS")
	private String status;

	
	@Column(name = "REMARK")
	private String remark;

	
	@Column(name = "CREATED_DATE")
	private Date createdDate;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getConnector_master_id() {
		return connector_id;
	}
	public void setConnector_id(Integer connector_id) {
		this.connector_id = connector_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "EstimationReport [id=" + id + ", connector_id=" + connector_id
				+ ", status=" + status + ", remark=" + remark
				+ ", createdDate=" + createdDate + "]";
	}

}
