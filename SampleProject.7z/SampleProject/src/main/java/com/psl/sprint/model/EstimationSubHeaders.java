package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_etsubheaders")
public class EstimationSubHeaders {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "hid")
	private Integer hid;
	
	@Column(name = "QDesc", nullable = false)
	private String QDesc;
	
	@Column(name = "ADDINFO", nullable = false)
	private String ADDINFO;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getHid() {
		return hid;
	}

	public void setHid(Integer hid) {
		this.hid = hid;
	}

	public String getQDesc() {
		return QDesc;
	}

	public void setQDesc(String qDesc) {
		QDesc = qDesc;
	}

	public String getADDINFO() {
		return ADDINFO;
	}

	public void setADDINFO(String aDDINFO) {
		ADDINFO = aDDINFO;
	}

	@Override
	public String toString() {
		return "EstimationSubHeaders [id=" + id + ", hid=" + hid + ", QDesc="
				+ QDesc + ", ADDINFO=" + ADDINFO + "]";
	}
}
