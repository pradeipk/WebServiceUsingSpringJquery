package com.psl.sprint.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.hibernate.validator.constraints.NotEmpty;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="tbl_requirement")
public class FunctionalRequrement {

	@Id
	@Column(name="REQUIREMENT_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@NotEmpty
	@Size(min=3, max=50)
	@Column(name = "UNIQUE_ID", nullable = false)
	private String uniqueId;
	
	@NotEmpty
	@Size(min=3, max=50)
	@Column(name = "REQUIREMENT", nullable = false)
	private String requirement;
	
	@NotNull
	@Column(name = "RESOURCE_PLANNED", nullable = false)
	private Integer resourceplanned;
	
	
	@Column(name = "DETAIL", nullable = false)
	private String detail;
	
	/*@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinTable(name="tbl_requirement_task", joinColumns =@JoinColumn(name="REQUIREMENT_ID"),
            inverseJoinColumns = @JoinColumn( name="TASK_ID"))
	private Set<Subtask> subtasks = new HashSet<Subtask>();*/
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)  
	@JoinColumn(name = "REQUIREMENT_ID")
	private List<TaskMatrix> taskMatrix = new ArrayList<TaskMatrix>();
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name = "CREATE_DATE", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate createdDate;
	
	@ManyToOne
	@JoinColumn(name="CONNECTOR_ID")
	private Connector connector;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public Integer getResourceplanned() {
		return resourceplanned;
	}

	public void setResourceplanned(Integer resourceplanned) {
		this.resourceplanned = resourceplanned;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public List<TaskMatrix> getTaskMatrix() {
		return taskMatrix;
	}

	public void setTaskMatrix(List<TaskMatrix> taskMatrix) {
		this.taskMatrix = taskMatrix;
	}

	public Connector getConnector() {
		return connector;
	}

	public void setConnector(Connector connector) {
		this.connector = connector;
	}	
	
}
