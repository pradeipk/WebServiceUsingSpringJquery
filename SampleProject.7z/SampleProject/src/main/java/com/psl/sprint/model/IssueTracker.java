/**
 * 
 */
package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * @author nilesh_nikam
 *
 */

@Entity
@Table(name = "tbl_issuetracker")
public class IssueTracker {
	@Id
	@Column(name = "issueID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer issueID;

	@Column(name = "issueTitle")
	private String issueTitle;
	
	@Column(name = "gitIssueLink")
	private String gitIssueLink;
	
	@Column(name = "issueDescription")
	private String issueDescription;

	@Column(name = "issueReason")
	private Integer issueReason;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "effortEstimation")
	private Integer effortEstimation;
	
	@Column(name = "isApproved")
	private Integer isApproved;
	



	// @NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "createdDate", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate createdDate;
	
	// @NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "gitIssueDate", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate gitIssueDate;

	public Integer getIssueID() {
		return issueID;
	}

	public void setIssueID(Integer issueID) {
		this.issueID = issueID;
	}

	public String getIssueTitle() {
		return issueTitle;
	}

	public void setIssueTitle(String issueTitle) {
		this.issueTitle = issueTitle;
	}

	public String getGitIssueLink() {
		return gitIssueLink;
	}

	public void setGitIssueLink(String gitIssueLink) {
		this.gitIssueLink = gitIssueLink;
	}

	public String getIssueDescription() {
		return issueDescription;
	}

	public void setIssueDescription(String issueDescription) {
		this.issueDescription = issueDescription;
	}

	public Integer getIssueReason() {
		return issueReason;
	}

	public void setIssueReason(Integer issueReason) {
		this.issueReason = issueReason;
	}

	public LocalDate getStartDate() {
		return createdDate;
	}

	public void setStartDate(LocalDate createdDate) {
		if (createdDate == null)
			this.createdDate = new LocalDate();
		else {
			this.createdDate = createdDate;
		}
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDate getGitIssueDate() {
		return gitIssueDate;
	}

	public void setGitIssueDate(LocalDate gitIssueDate) {
		this.gitIssueDate = gitIssueDate;
	}

	public Integer getEffortEstimation() {
		return effortEstimation;
	}

	public void setEffortEstimation(Integer effortEstimation) {
		this.effortEstimation = effortEstimation;
	}

	public Integer getIsApproved() {
		return isApproved;
	}

	public void setIsApproved(Integer isApproved) {
		this.isApproved = isApproved;
	}

	@Override
	public String toString() {
		return "IssueTracker [issueID=" + issueID + ", issueTitle="
				+ issueTitle + ", gitIssueLink=" + gitIssueLink
				+ ", issueDescription=" + issueDescription + ", issueReason="
				+ issueReason + ", status=" + status + ", effortEstimation="
				+ effortEstimation + ", isApproved=" + isApproved
				+ ", createdDate=" + createdDate + ", gitIssueDate="
				+ gitIssueDate + "]";
	}
	
	
}
