package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="tbl_issue_tracker_jira_mapping")
public class IssueTrackerJiraMapping {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer id;

	
	@Column(name = "ISSUETRACKER_ID")
	private Integer issuetracker_id;

	@NotEmpty
	@Column(name = "JIRA_LINK")
	private String jira_link ;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getJira_link() {
		return jira_link;
	}

	public void setJira_link(String jira_link) {
		this.jira_link = jira_link;
	}

	public Integer getIssuetracker_id() {
		return issuetracker_id;
	}

	public void setIssuetracker_id(Integer issuetracker_id) {
		this.issuetracker_id = issuetracker_id;
	}
	
	@Override
	public String toString() {
		return "IssueTrackerJiraMapping [id=" + id + ", issuetracker_id="
				+ issuetracker_id + ", jira_link=" + jira_link + "]";
	}
}
