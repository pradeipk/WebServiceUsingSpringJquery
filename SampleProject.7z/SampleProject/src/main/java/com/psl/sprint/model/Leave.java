package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_leave")
public class Leave {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LEAVE_ID")
	private Integer leaveId;

	@Column(name = "RESOURCE_ID", unique = false, nullable = false)
	private Integer resourceId;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "START_DATE", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate startDate;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "END_DATE", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate endDate;

	@Size(min = 3, max = 50)
	@Column(name = "TYPE", nullable = false, unique = false)
	private String type;

	@Column(name = "PERCENTAGE", nullable = false, unique = false)
	private Double percentage;

	@Column(name = "DESCRIPTION", nullable = false, unique = false)
	private String description;
	
	@Column(name = "ADJUST", nullable = false, unique = false)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean adjust;

	public Integer getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(Integer leaveId) {
		this.leaveId = leaveId;
	}

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Boolean getAdjust() {
		return adjust;
	}

	public void setAdjust(Boolean adjust) {
		this.adjust = adjust;
	}

	@Override
	public String toString() {
		return "Leave [leaveId=" + leaveId + ", resourceId=" + resourceId
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", type=" + type + ", percentage=" + percentage
				+ ", description=" + description + ", adjust=" + adjust + "]";
	}
}
