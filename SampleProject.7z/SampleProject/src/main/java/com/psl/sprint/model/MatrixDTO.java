package com.psl.sprint.model;


public class MatrixDTO {

	private Integer matrixId;

	private String complexity;

	private String uncertainity;

	private String dependency;

	private String impact_on_feature;

	private String impact_on_performance;
	
	private String additional_testing_required;
	
	private String taskName;
	private Integer task_id;

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getUncertainity() {
		return uncertainity;
	}

	public void setUncertainity(String uncertainity) {
		this.uncertainity = uncertainity;
	}

	public String getDependency() {
		return dependency;
	}

	public void setDependency(String dependency) {
		this.dependency = dependency;
	}

	public String getImpact_on_feature() {
		return impact_on_feature;
	}

	public void setImpact_on_feature(String impact_on_feature) {
		this.impact_on_feature = impact_on_feature;
	}

	public String getImpact_on_performance() {
		return impact_on_performance;
	}

	public void setImpact_on_performance(String impact_on_performance) {
		this.impact_on_performance = impact_on_performance;
	}

	public Integer getMatrixId() {
		return matrixId;
	}

	public void setMatrixId(Integer matrixId) {
		this.matrixId = matrixId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getAdditional_testing_required() {
		return additional_testing_required;
	}

	public void setAdditional_testing_required(String additional_testing_required) {
		this.additional_testing_required = additional_testing_required;
	}

	public Integer getTask_id() {
		return task_id;
	}

	public void setTask_id(Integer task_id) {
		this.task_id = task_id;
	}

}
