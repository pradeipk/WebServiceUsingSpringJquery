package com.psl.sprint.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_connector_notes")
public class Notes {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "connector_id", nullable = false)
	private Integer connectorId;

	@Column(name = "notes", nullable = false)
	private String notes;
	
	@Column(name = "planned_completion_date", nullable = false)
	private Date plannedCompletionDate;

	@Column(name = "actual_completion_date", nullable = false)
	private Date actualCompletionDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Date getPlannedCompletionDate() {
		return plannedCompletionDate;
	}

	public void setPlannedCompletionDate(Date plannedCompletionDate) {
		this.plannedCompletionDate = plannedCompletionDate;
	}

	public Date getActualCompletionDate() {
		return actualCompletionDate;
	}

	public void setActualCompletionDate(Date actualCompletionDate) {
		this.actualCompletionDate = actualCompletionDate;
	}

	@Override
	public String toString() {
		return "Notes [id=" + id + ", connectorId=" + connectorId + ", notes="
				+ notes + ", plannedCompletionDate=" + plannedCompletionDate
				+ ", actualCompletionDate=" + actualCompletionDate + "]";
	}
}
