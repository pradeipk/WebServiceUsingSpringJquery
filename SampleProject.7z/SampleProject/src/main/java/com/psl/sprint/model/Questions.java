package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_qs")
public class Questions {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "hid")
	private Integer hid;
	
	@Column(name = "shid")
	private Integer shid;
	
	@Column(name = "Options")
	private String Options;
	
	@Column(name = "Complexity")
	private Integer Complexity;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getHid() {
		return hid;
	}

	public void setHid(Integer hid) {
		this.hid = hid;
	}

	public Integer getShid() {
		return shid;
	}

	public void setShid(Integer shid) {
		this.shid = shid;
	}

	public String getOptions() {
		return Options;
	}

	public void setOptions(String options) {
		Options = options;
	}

	public Integer getComplexity() {
		return Complexity;
	}

	public void setComplexity(Integer complexity) {
		Complexity = complexity;
	}

	@Override
	public String toString() {
		return "Questions [id=" + id + ", hid=" + hid + ", shid=" + shid
				+ ", Options=" + Options + ", Complexity=" + Complexity + "]";
	}
}
