package com.psl.sprint.model;

import java.util.List;


public class RequirementDTO {

	private Integer requirementId;
	private String requirementName;
	private Integer resourceAssigned;
	private  String uniqueName;
	private List<MatrixDTO> matrix;

	public Integer getRequirementId() {
		return requirementId;
	}

	public void setRequirementId(Integer requirementId) {
		this.requirementId = requirementId;
	}

	public String getRequirementName() {
		return requirementName;
	}

	public void setRequirementName(String requirementName) {
		this.requirementName = requirementName;
	}

	public List<MatrixDTO> getMatrix() {
		return matrix;
	}

	public void setMatrix(List<MatrixDTO> matrix) {
		this.matrix = matrix;
	}

	public Integer getResourceAssigned() {
		return resourceAssigned;
	}

	public void setResourceAssigned(Integer resourceAssigned) {
		this.resourceAssigned = resourceAssigned;
	}

	public String getUniqueName() {
		return uniqueName;
	}

	public void setUniqueName(String uniqueName) {
		this.uniqueName = uniqueName;
	}
	
	
}
