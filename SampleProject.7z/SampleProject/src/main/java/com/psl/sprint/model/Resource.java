package com.psl.sprint.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.psl.sprint.dto.ResourceDTO;

@Entity
@Table(name = "tbl_resource")
public class Resource {

	@Id()
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RESOURCE_ID")
	private Integer resourceId;

	@Size(min = 3, max = 50)
	@Column(name = "FIRST_NAME", nullable = false, unique = false)
	private String firstName;

	@Size(min = 3, max = 50)
	@Column(name = "LAST_NAME", nullable = false, unique = false)
	private String lastName;

	@Size(min = 3, max = 50)
	@Column(name = "PASSWORD", unique = false, nullable = false)
	private String password;

	@Size(min = 3, max = 50)
	@Column(name = "USER_NAME", unique = true, nullable = true)
	private String userName;

	@Size(min = 3, max = 50)
	@Column(name = "JOB_ASSIGNED", unique = false, nullable = false)
	private String jobAssigned;
	
	@Size(min = 3, max = 50)
	@Column(name = "TEAM_LEAD", unique = false, nullable = false)
	private String teamlead;

	@Column(name = "ENABLED", unique = false, nullable = false)
	private int enabled;

	// Mapped as DATETIME (on MySQL)
	// For JSON binding use the format: "1970-01-01T00:00:00.000+0000"
	@Column(name = "CREATED_DATE", nullable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@Column(name = "CREATED_BY", nullable = true)
	private String createdBy;
	
	@Column(name = "IP", nullable = true)
	private String ip;

	@Column(name = "ip4", nullable = true)
	private String ip4;

	@Column(name = "ip6", nullable = true)
	private String ip6;
	
	@Column(name = "RM_ID")
	private Integer resourceManagerId;

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	// Mapped as DATETIME (on MySQL)
	// For JSON binding use the format: "1970-01-01T00:00:00.000+0000"
	@Column(name = "UPDATED_DATE", nullable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime updatedDate;

	@Column(name = "UPDATED_BY", nullable = true)
	private String updatedBy;

	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "RELEASE_DATE", nullable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate releaseDate;

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public DateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(DateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public void setCreatedDate(DateTime createdDate) {

		this.createdDate = createdDate;

	}

	// join column will be used to store foreign key, if you do not mention join
	// column fk will not
	// be stored but collection will be created
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "RESOURCE_ID")
	private Set<AccessLevel> accessLevels = new HashSet<AccessLevel>();

	@ManyToMany(mappedBy = "resources")
	private Set<Connector> connector = new HashSet<Connector>();

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "RESOURCE_ID")
	private List<ResourceAllocationLog> resourceAllocationList = new ArrayList<ResourceAllocationLog>();
	
	
	@OneToMany(mappedBy = "qaResource")
	private Set<ConnectorLeadMapping> qaResource;
	
	
	@OneToMany(mappedBy = "devResource")
	private Set<ConnectorLeadMapping> devResource;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getJobAssigned() {
		return jobAssigned;
	}

	public void setJobAssigned(String jobAssigned) {
		this.jobAssigned = jobAssigned;
	}

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public Set<AccessLevel> getAccessLevels() {
		return accessLevels;
	}

	public void setAccessLevels(Set<AccessLevel> accessLevels) {
		this.accessLevels = accessLevels;
	}

	public Resource() {
		super();
	}

	public Resource(ResourceDTO dto) {
		super();
		this.firstName = dto.getFirstName();
		this.lastName = dto.getLastName();
		this.jobAssigned = dto.getJobAssigned();
		this.teamlead=dto.getTeamlead();
		this.resourceId = dto.getResourceId();
		this.userName = (dto.getFirstName() + "_" + dto.getLastName())
				.toLowerCase();
		// this.setCurrent_allocation_level(0.00);
		this.setPassword((this.getFirstName()).toLowerCase() + 123);
		this.setEnabled(1);
		// this.setAccessLevels(null);

	}

	/*
	 * public Double getCurrent_allocation_level() { return
	 * current_allocation_level; }
	 * 
	 * public void setCurrent_allocation_level(Double current_allocation_level)
	 * { this.current_allocation_level = current_allocation_level; }
	 */

	public Set<Connector> getConnector() {
		return connector;
	}

	public void setConnector(Set<Connector> connector) {
		this.connector = connector;
	}

	public List<ResourceAllocationLog> getResourceAllocationList() {
		return resourceAllocationList;
	}

	public void setResourceAllocationList(
			List<ResourceAllocationLog> resourceAllocationList) {
		this.resourceAllocationList = resourceAllocationList;
	}

	public LocalDate getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(LocalDate releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getIp4() {
		return ip4;
	}

	public void setIp4(String ip4) {
		this.ip4 = ip4;
	}

	public String getIp6() {
		return ip6;
	}

	public void setIp6(String ip6) {
		this.ip6 = ip6;
	}

	public String getTeamlead() {
		return teamlead;
	}

	public void setTeamlead(String teamlead) {
		this.teamlead = teamlead;
	}

	public Set<ConnectorLeadMapping> getQaResource() {
		return qaResource;
	}

	public void setQaResource(Set<ConnectorLeadMapping> qaResource) {
		this.qaResource = qaResource;
	}

	public Set<ConnectorLeadMapping> getDevResource() {
		return devResource;
	}

	public void setDevResource(Set<ConnectorLeadMapping> devResource) {
		this.devResource = devResource;
	}

	public Integer getResourceManagerId() {
		return resourceManagerId;
	}

	public void setResourceManagerId(Integer resourceManagerId) {
		this.resourceManagerId = resourceManagerId;
	}
}
