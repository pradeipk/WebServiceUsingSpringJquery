package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_resource_allocation_history")
public class ResourceAllocationLog {

	@Id()
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ALLOCATION_ID")
	private Integer allocationId;

	// Mapped as DATE (on MySQL)
	// For JSON binding use the format: "1970-01-01" (yyyy-MM-dd)
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "START_DATE", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate startDate;

	// Mapped as DATE (on MySQL)
	// For JSON binding use the format: "1970-01-01" (yyyy-MM-dd)
	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "END_DATE", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate endDate;

	// Mapped as DATETIME (on MySQL)
	// For JSON binding use the format: "1970-01-01T00:00:00.000+0000"
	@Column(name = "CREATED_DATE", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@Column(name = "CREATED_BY", nullable = true)
	private String createdBy;

	@Column(name = "CONNECTOR_ID")
	private Integer connectorId;

	@Column(name = "CONNECTOR_NAME")
	private String connectorName;

	@Column(name = "BANDWIDTH_SHARE", nullable = false)
	private Double bandwidthShare;

	@ManyToOne
	@JoinColumn(name = "RESOURCE_ID")
	private Resource resource;

	@Column(name = "UPDATED_DATE", nullable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime updatedDate;

	@Column(name = "UPDATED_BY", nullable = true)
	private String updatedBy;

	@Column(name = "DESCRIPTION", nullable = true)
	private String description;
	
	@Column(name = "PHASE_TYPE", nullable = true)
	private String phaseType;

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public DateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(DateTime updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public ResourceAllocationLog() {
		super();
	}

	public Integer getAllocationId() {
		return allocationId;
	}

	public void setAllocationId(Integer allocationId) {
		this.allocationId = allocationId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		if (createdDate == null)
			this.createdDate = new DateTime();
		else {
			this.createdDate = createdDate;
		}
	}

	public Double getBandwidthShare() {
		return bandwidthShare;
	}

	public void setBandwidthShare(Double bandwidthShare) {
		this.bandwidthShare = bandwidthShare;
	}

	public Resource getResource() {
		return resource;
	}

	public void setResource(Resource resource) {
		this.resource = resource;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPhaseType() {
		return phaseType;
	}

	public void setPhaseType(String phaseType) {
		this.phaseType = phaseType;
	}

	@Override
	public String toString() {
		return "ResourceAllocationLog [allocationId=" + allocationId
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ ", connectorId=" + connectorId + ", connectorName="
				+ connectorName + ", bandwidthShare=" + bandwidthShare
				+ ", resource=" + resource + ", updatedDate=" + updatedDate
				+ ", updatedBy=" + updatedBy + ", description=" + description
				+ "]";
	}
}