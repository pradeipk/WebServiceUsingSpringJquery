package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "tbl_review")
public class Review {

	@Id
	@Column(name = "id_review")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer reviewId;

	@NotEmpty
	@Column(name = "review_comments", nullable = false, unique = true)
	private String reviewComments;

	@NotEmpty
	@Size(min = 1, max = 45)
	@Column(name = "review_type", nullable = false, unique = true)
	private String reviewType;

	@NotEmpty
	@Size(min = 1, max = 45)
	@Column(name = "reviewer", nullable = false, unique = true)
	private String reviewer;

	@NotEmpty
	@Size(min = 1, max = 45)
	@Column(name = "severity", nullable = false, unique = true)
	private String severity;

	@Column(name = "connectorMID")
	// @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer connectorMID;

	@Column(name = "id_review_phase")
	// @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id_review_phase;

	public Integer getReviewId() {
		return reviewId;
	}

	public void setReviewId(Integer reviewId) {
		this.reviewId = reviewId;
	}

	public String getReviewComments() {
		return reviewComments;
	}

	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public Integer getConnectorMID() {
		return connectorMID;
	}

	public void setConnectorMID(Integer connectorMID) {
		this.connectorMID = connectorMID;
	}

	public Integer getId_review_phase() {
		return id_review_phase;
	}

	public void setId_review_phase(Integer id_review_phase) {
		this.id_review_phase = id_review_phase;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", reviewComments=" + reviewComments + ", reviewType=" + reviewType
				+ ", reviewer=" + reviewer + ", severity=" + severity + ", connectorMID=" + connectorMID
				+ ", id_review_phase=" + id_review_phase + "]";
	}

}