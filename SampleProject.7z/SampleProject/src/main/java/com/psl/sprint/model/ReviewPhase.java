package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "tbl_review_phase_master")
public class ReviewPhase {

	@Id
	@Column(name = "id_review_phase")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "Review_Phase", nullable = false, unique = true)
	private String reviewPhase;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getReviewPhase() {
		return reviewPhase;
	}

	public void setReviewPhase(String reviewPhase) {
		this.reviewPhase = reviewPhase;
	}

	@Override
	public String toString() {
		return "ReviewPhase [id=" + id + ", reviewPhase=" + reviewPhase + "]";
	}

	@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}

}