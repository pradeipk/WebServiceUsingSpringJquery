package com.psl.sprint.model;

public class ReviewUI {

	private Integer reviewId;
	private String reviewComments;
	private String reviewType;
	private String reviewer;
	private Integer connectorMID;
	private String connectorName;
	private Integer id_review_phase;
	private String Review_Phase;
	private String severity;

	public Integer getReviewId() {
		return reviewId;
	}

	public void setReviewId(Integer reviewId) {
		this.reviewId = reviewId;
	}

	public String getReviewComments() {
		return reviewComments;
	}

	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	public String getReviewType() {
		return reviewType;
	}

	public void setReviewType(String reviewType) {
		this.reviewType = reviewType;
	}

	public String getReviewer() {
		return reviewer;
	}

	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}

	public Integer getConnectorMID() {
		return connectorMID;
	}

	public void setConnectorMID(Integer connectorMID) {
		this.connectorMID = connectorMID;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public Integer getId_review_phase() {
		return id_review_phase;
	}

	public void setId_review_phase(Integer id_review_phase) {
		this.id_review_phase = id_review_phase;
	}

	public String getReviewPhase() {
		return Review_Phase;
	}

	public void setReviewPhase(String reviewPhase) {
		this.Review_Phase = reviewPhase;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	@Override
	public String toString() {
		return "ReviewUI [reviewId=" + reviewId + ", reviewComments=" + reviewComments + ", reviewType=" + reviewType
				+ ", reviewer=" + reviewer + ", connectorMID=" + connectorMID + ", connectorName=" + connectorName
				+ ", id_review_phase=" + id_review_phase + ", Review_Phase=" + Review_Phase + ", severity=" + severity
				+ "]";
	}

}