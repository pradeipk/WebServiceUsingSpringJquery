package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_sprint_items")
public class SprintItem {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "sprint_id")
	private Integer sprintId;

	@Column(name = "connector_id")
	private Integer connectorId;

	@Column(name = "hid")
	private Integer hId;

	@Column(name = "percentage_completion")
	private Double percentageCompletion;

	@Column(name = "comment")
	private String comment;

	
	 @OneToOne//(cascade = CascadeType.ALL)
	    @JoinColumn(name = "lead_mapping",referencedColumnName="id")
	 private ConnectorLeadMapping user;
	
	 @OneToOne
	   @JoinColumn(name = "created_by",referencedColumnName="RESOURCE_ID")
		 private Resource resource;
	   
	   
	public Resource getResource() {
		return resource;
	}



	public void setResource(Resource resource) {
		this.resource = resource;
	}



	public ConnectorLeadMapping getUser() {
		return user;
	}



	public void setUser(ConnectorLeadMapping user) {
		this.user = user;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSprintId() {
		return sprintId;
	}

	public void setSprintId(Integer sprintId) {
		this.sprintId = sprintId;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public Integer gethId() {
		return hId;
	}

	public void sethId(Integer hId) {
		this.hId = hId;
	}

	public Double getPercentageCompletion() {
		return percentageCompletion;
	}

	public void setPercentageCompletion(Double percentageCompletion) {
		this.percentageCompletion = percentageCompletion;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "SprintItem [id=" + id + ", sprintId=" + sprintId
				+ ", connectorId=" + connectorId + ", hId=" + hId
				+ ", percentageCompletion=" + percentageCompletion
				+ ", comment=" + comment + "]";
	}
}
