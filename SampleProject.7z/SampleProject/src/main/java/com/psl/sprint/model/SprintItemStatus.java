package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;

@Entity
@Table(name="tbl_sprint_items_status")
public class SprintItemStatus {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "sprint_item_id")
	private Integer sprintItemId;
	
	
	@Column(name = "sprint_item_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate sprintItemDate;
	
	@Column(name = "status")
	private String status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSprintItemId() {
		return sprintItemId;
	}

	public void setSprintItemId(Integer sprintItemId) {
		this.sprintItemId = sprintItemId;
	}

	public LocalDate getSprintItemDate() {
		return sprintItemDate;
	}

	public void setSprintItemDate(LocalDate sprintItemDate) {
		this.sprintItemDate = sprintItemDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "SprintItemStatus [id=" + id + ", sprintItemId=" + sprintItemId
				+ ", sprintItemDate=" + sprintItemDate + ", status=" + status
				+ "]";
	}
}
