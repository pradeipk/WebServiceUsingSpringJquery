package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
@Entity
@Table(name="tbl_sprint_lead_mapping",uniqueConstraints={ @UniqueConstraint (columnNames = {"sprint_id", "connector_lead"})
	})

public class SprintLeadMapping {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	// @Column(name = "sprint_id")
	   // private int sprintId;

	    @Column(name = "connector_lead")
	    private int connectorLead;
	
	@ManyToOne
@JoinColumn(name = "sprint_id",referencedColumnName="id")
	//@JoinColumn(name = "sprint_id", referencedColumnName="id",nullable = false)
  private SprintMaster sprintMaster;
	
	 @OneToOne
	   @JoinColumn(name = "created_by",referencedColumnName="RESOURCE_ID")
		 private Resource resource;

	public SprintLeadMapping()
	{
		
	}

	public SprintLeadMapping(int connectorLead,SprintMaster sprintMaster,Resource resource )
	{
		this.connectorLead=connectorLead;
		this.sprintMaster=sprintMaster;
		this.resource=resource;
		
	}
	

	public Resource getResource() {
		return resource;
	}

	public void setResource(Resource resource) {
		this.resource = resource;
	}

	public int getConnectorLead() {
		return connectorLead;
	}

	public void setConnectorLead(int connectorLead) {
		this.connectorLead = connectorLead;
	}

	public SprintMaster getSprintMaster() {
		return sprintMaster;
	}

	public void setSprintMaster(SprintMaster sprintMaster) {
		this.sprintMaster = sprintMaster;
	}
	
	
}
