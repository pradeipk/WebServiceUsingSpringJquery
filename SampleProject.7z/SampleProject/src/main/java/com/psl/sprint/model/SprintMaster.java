package com.psl.sprint.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="tbl_sprintmaster")
public class SprintMaster {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "sprint_no")
	private Integer sprintNo;
	
	 
	@Column(name = "frozoned")
	private Integer freezed;
	
	@OneToMany(mappedBy="sprintMaster",cascade=CascadeType.ALL)
	private Set<SprintLeadMapping>  sprintLeadMapping;
	
	public Integer getFreezed() {
		return freezed;
	}

	public void setFreezed(Integer freezed) {
		this.freezed = freezed;
	}

	@Column(name = "connector_master_id")
	private Integer connectorMasterId;
	
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	@Column(name = "start_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate startDate;
	
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	@Column(name = "end_date")
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate endDate;



	
	 @OneToOne
	   @JoinColumn(name = "created_by",referencedColumnName="RESOURCE_ID")
		 private Resource resource;
	   
	
	public Set<SprintLeadMapping> getSprintLeadMapping() {
		return sprintLeadMapping;
	}

	public void setSprintLeadMapping(Set<SprintLeadMapping> sprintLeadMapping) {
		this.sprintLeadMapping = sprintLeadMapping;
	}



	public Resource getResource() {
		return resource;
	}

	public void setResource(Resource resource) {
		this.resource = resource;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSprintNo() {
		return sprintNo;
	}

	public void setSprintNo(Integer sprintNo) {
		this.sprintNo = sprintNo;
	}

	public Integer getConnectorMasterId() {
		return connectorMasterId;
	}

	public void setConnectorMasterId(Integer connectorMasterId) {
		this.connectorMasterId = connectorMasterId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}




	public Set<SprintLeadMapping> getSprintLeadId() {
		return sprintLeadMapping;
	}

	public void setSprintLeadId(Set<SprintLeadMapping> sprintLeadId) {
		this.sprintLeadMapping = sprintLeadId;
	}

	@Override
	public String toString() {
		return "SprintMaster [id=" + id + ", sprintNo=" + sprintNo
				+ ", connectorMasterId=" + connectorMasterId + ", startDate="
				+ startDate + ", endDate=" + endDate + "]";
	}
}