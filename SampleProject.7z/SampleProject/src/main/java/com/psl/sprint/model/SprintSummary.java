package com.psl.sprint.model;

import java.sql.Date;

import javax.persistence.Column;

public class SprintSummary {
	
	@Column(name = "Id")
	private Integer id;
	
	@Column(name = "ConnectorId")
	private Integer connectorId;
	
	@Column(name = "ConnectorName")
	private String connectorName;
	
	@Column(name = "ConnectorType")
	private Integer connectorType;
	
	@Column(name = "Hid")
	private Integer hid;
	
	@Column(name = "SprintNo")
	private Integer sprintNo;
	
	@Column(name = "SDLCPhaseTask")
	private String SDLCPhaseTask;
	
	@Column(name = "StartDate")
	private Date startDate;
	
	@Column(name = "EndDate")
	private Date endDate;
	
	@Column(name = "StoryPoints")
	private Double storyPoints;
	
	@Column(name = "PercentageCompletion")
	private Double percentageCompletion;
	
	@Column(name = "ConnectorParentId")
	private Integer connectorParentId;
	
	
	private Integer CreateBy;
	
	private Integer leadMapping;

	public Integer getLeadMapping() {
		return leadMapping;
	}

	public void setLeadMapping(Integer leadMapping) {
		this.leadMapping = leadMapping;
	}

	public Integer getCreateBy() {
		return CreateBy;
	}

	public void setCreateBy(Integer createBy) {
		CreateBy = createBy;
	}
	
	private Double efforts;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public Integer getConnectorType() {
		return connectorType;
	}

	public void setConnectorType(Integer connectorType) {
		this.connectorType = connectorType;
	}

	public Integer getHid() {
		return hid;
	}

	public void setHid(Integer hid) {
		this.hid = hid;
	}

	public Integer getSprintNo() {
		return sprintNo;
	}

	public String getSDLCPhaseTask() {
		return SDLCPhaseTask;
	}

	public void setSDLCPhaseTask(String sDLCPhaseTask) {
		SDLCPhaseTask = sDLCPhaseTask;
	}

	public void setSprintNo(Integer sprintNo) {
		this.sprintNo = sprintNo;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Double getStoryPoints() {
		return storyPoints;
	}

	public void setStoryPoints(Double storyPoints) {
		this.storyPoints = storyPoints;
	}

	public Double getPercentageCompletion() {
		return percentageCompletion;
	}

	public void setPercentageCompletion(Double percentageCompletion) {
		this.percentageCompletion = percentageCompletion;
	}

	public Integer getConnectorParentId() {
		return connectorParentId;
	}

	public void setConnectorParentId(Integer connectorParentId) {
		this.connectorParentId = connectorParentId;
	}

	public Double getEfforts() {
		return efforts;
	}

	public void setEfforts(Double efforts) {
		this.efforts = efforts;
	}

	@Override
	public String toString() {
		return "SprintSummary [id=" + id + ", connectorId=" + connectorId
				+ ", connectorName=" + connectorName + ", connectorType="
				+ connectorType + ", hid=" + hid + ", sprintNo=" + sprintNo
				+ ", SDLCPhaseTask=" + SDLCPhaseTask + ", startDate="
				+ startDate + ", endDate=" + endDate + ", storyPoints="
				+ storyPoints + ", percentageCompletion="
				+ percentageCompletion + ", connectorParentId="
				+ connectorParentId + ", efforts=" + efforts + "]";
	}

	
}
