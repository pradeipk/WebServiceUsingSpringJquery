package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "tbl_subtask")
public class Subtask {

	@Id
	@Column(name = "SUBTASK_ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int taskId;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "SUBTASK", nullable = false, unique = true)
	private String subtask;

	@Column(name = "CYCLE", nullable = false)
	private String cycle;

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public String getCycle() {
		return cycle;
	}

	public void setCycle(String cycle) {
		this.cycle = cycle;
	}

	public void setSubtask(String subtask) {
		this.subtask = subtask;
	}

	public String getSubtask() {
		return subtask;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + taskId;
		result = prime * result + ((subtask == null) ? 0 : subtask.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Subtask))
			return false;
		Subtask other = (Subtask) obj;
		if (taskId != other.taskId)
			return false;
		if (subtask == null) {
			if (other.subtask != null)
				return false;
		} else if (!subtask.equals(other.subtask))
			return false;
		return true;
	}
/**/

	/*
	 * @Override public String toString() { return "Employee [id=" + id +
	 * ", name=" + name + ", joiningDate=" + joiningDate + ", salary=" + salary
	 * + ", ssn=" + ssn + "]"; }
	 */

}
