package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "tbl_task")
public class Task {

	@Id
	@Column(name = "task_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "task_date", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate taskDate;

	@Column(name = "connector_id", nullable = false)
	private Integer connectorId;

	@Column(name = "phase", nullable = false)
	private String phase;

	@Column(name = "hours_spent", nullable = false)
	private Double hoursSpent;

	@Column(name = "description", nullable = false)
	private String description;
	
	@Column(name = "resource_id", nullable = false)
	private Integer resourceId;
	
	@Column(name = "tcs_Created", nullable = false)
	private Integer tcsCreated;
	
	@Column(name = "tcs_Exec", nullable = false)
	private Integer tcsExec;

	@Column(name = "created_date", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate createdDate;

	@Column(name = "created_by", nullable = false)
	private String createdBy;

	@Column(name = "modified_date", nullable = false)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDate modifiedDate;

	@Column(name = "modified_by", nullable = false)
	private String modifiedBy;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getTaskDate() {
		return taskDate;
	}

	public void setTaskDate(LocalDate taskDate) {
		this.taskDate = taskDate;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public Double getHoursSpent() {
		return hoursSpent;
	}

	public void setHoursSpent(Double hoursSpent) {
		this.hoursSpent = hoursSpent;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDate getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(LocalDate modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public Integer getTcsCreated() {
		return tcsCreated;
	}

	public void setTcsCreated(Integer tcsCreated) {
		this.tcsCreated = tcsCreated;
	}

	public Integer getTcsExec() {
		return tcsExec;
	}

	public void setTcsExec(Integer tcsExec) {
		this.tcsExec = tcsExec;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", taskDate=" + taskDate + ", connectorId="
				+ connectorId + ", phase=" + phase + ", hoursSpent="
				+ hoursSpent + ", description=" + description + ", resourceId="
				+ resourceId + ", tcsCreated=" + tcsCreated + ", tcsExec="
				+ tcsExec + ", createdDate=" + createdDate + ", createdBy="
				+ createdBy + ", modifiedDate=" + modifiedDate
				+ ", modifiedBy=" + modifiedBy + "]";
	}
}