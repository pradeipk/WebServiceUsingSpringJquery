package com.psl.sprint.model;

import java.sql.Date;

import javax.persistence.Column;

public class TaskEffortsByConnector {

	@Column(name = "ResourceId", nullable = true)
	private Integer resourceId;

	@Column(name = "ResourceName", nullable = true)
	private String resourceName;

	@Column(name = "ConnectorId", nullable = true)
	private Integer connectorId;

	@Column(name = "ConnectorName", nullable = true)
	private String connectorName;

	@Column(name = "TaskDate", nullable = true)
	private Date taskDate;
	
	@Column(name = "NoOfHours", nullable = true)
	private Double noOfHours;
	
	@Column(name = "Phase", nullable = true)
	private String phase;

	@Column(name = "Description", nullable = true)
	private String description;
	
	@Column(name = "tcs_Created", nullable = true)
	private Integer tcsCreated;
	
	@Column(name = "tcs_Exec", nullable = true)
	private Integer tcsExecuted;


	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public Date getTaskDate() {
		return taskDate;
	}

	public void setTaskDate(Date taskDate) {
		this.taskDate = taskDate;
	}

	public Double getNoOfHours() {
		return noOfHours;
	}

	public void setNoOfHours(Double noOfHours) {
		this.noOfHours = noOfHours;
	}
	
	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		if (description == null) 
			this.description = "";
		else
		this.description = description;
	}
	
	public Integer getTcsCreated() {
		return tcsCreated;
	}

	public void setTcsCreated(Integer tcsCreated) {
		this.tcsCreated = tcsCreated;
	}

	public Integer getTcsExecuted() {
		return tcsExecuted;
	}

	public void setTcsExecuted(Integer tcsExecuted) {
		this.tcsExecuted = tcsExecuted;
	}

	

	@Override
	public String toString() {
		return "TaskEffortsByConnector [resourceId=" + resourceId
				+ ", resourceName=" + resourceName + ", connectorId="
				+ connectorId + ", connectorName=" + connectorName
				+ ", taskDate=" + taskDate + ", noOfHours=" + noOfHours
				+ ", phase=" + phase + ", description=" + description 
				+ ", tcsCreated=" + tcsCreated + ", tcsExecuted=" + tcsExecuted +"]";
	}

}