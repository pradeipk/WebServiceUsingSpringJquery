package com.psl.sprint.model;

import java.sql.Date;

import javax.persistence.Column;

public class TaskEffortsByConnectorAndPhase {

	@Column(name = "ConnectorId", nullable = true)
	private Integer connectorId;

	@Column(name = "ConnectorName", nullable = true)
	private String connectorName;

	@Column(name = "ResourceId", nullable = true)
	private Integer resourceId;

	@Column(name = "FirstName", nullable = true)
	private String firstName;

	@Column(name = "LastName", nullable = true)
	private String lastName;

	@Column(name = "TaskDate", nullable = true)
	private Date taskDate;

	@Column(name = "HoursSpent", nullable = true)
	private Double hoursSpent;
	
	@Column(name = "Description", nullable = true)
	private String description;

	public Integer getConnectorId() {
		return connectorId;
	}

	public void setConnectorId(Integer connectorId) {
		this.connectorId = connectorId;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getTaskDate() {
		return taskDate;
	}

	public void setTaskDate(Date taskDate) {
		this.taskDate = taskDate;
	}

	public Double getHoursSpent() {
		return hoursSpent;
	}

	public void setHoursSpent(Double hoursSpent) {
		this.hoursSpent = hoursSpent;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}