package com.psl.sprint.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "tbl_task_matrix")
public class TaskMatrix {

	@Id
	@Column(name = "MATRIX_ID", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int matrixId;

	@NotEmpty
	@Column(name = "COMPLEXITY", nullable = false)
	@Size(min = 3, max = 50)
	private String complexity;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "UNCERTAINITY", nullable = false)
	private String uncertainity;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "DEPENDENCY", nullable = false)
	private String dependency;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "IMPACT_ON_FEATURE", nullable = false)
	private String impact_on_feature;

	@NotEmpty
	@Size(min = 3, max = 50)
	@Column(name = "IMPACT_ON_PERFORMANCE", nullable = false)
	private String impact_on_performance;
	
	@NotEmpty
	@Size(min = 2, max = 50)
	@Column(name = "ADDITIONAL_TESTING_REQUIRED", nullable = false)
	private String additional_testing_required;	

	@Column(name = "STORY_POINT", nullable = false)
	private Integer story_point;

	@Column(name = "TASK_ID", nullable = false)	
	private Integer task_id;
	
	@ManyToOne
	@JoinColumn(name="REQUIREMENT_ID")
	private FunctionalRequrement requirement;
	
	@Column(name = "TASK_NAME", nullable = false)
	private String taskName;
	
	public Integer getTask_id() {
		return task_id;
	}

	public void setTask_id(Integer task_id) {
		this.task_id = task_id;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getUncertainity() {
		return uncertainity;
	}

	public void setUncertainity(String uncertainity) {
		this.uncertainity = uncertainity;
	}

	public String getDependency() {
		return dependency;
	}

	public void setDependency(String dependency) {
		this.dependency = dependency;
	}

	public String getImpact_on_feature() {
		return impact_on_feature;
	}

	public void setImpact_on_feature(String impact_on_feature) {
		this.impact_on_feature = impact_on_feature;
	}

	public String getImpact_on_performance() {
		return impact_on_performance;
	}

	public void setImpact_on_performance(String impact_on_performance) {
		this.impact_on_performance = impact_on_performance;
	}

	public Integer getStory_point() {
		return story_point;
	}

	public void setStory_point(Integer story_point) {
		this.story_point = story_point;
	}

	public int getMatrixId() {
		return matrixId;
	}

	public void setMatrixId(int matrixId) {
		this.matrixId = matrixId;
	}

	public String getAdditional_testing_required() {
		return additional_testing_required;
	}

	public void setAdditional_testing_required(String additional_testing_required) {
		this.additional_testing_required = additional_testing_required;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public FunctionalRequrement getRequirement() {
		return requirement;
	}

	public void setRequirement(FunctionalRequrement requirement) {
		this.requirement = requirement;
	}

	/*
	 * @Override public String toString() { return "Employee [id=" + id +
	 * ", name=" + name + ", joiningDate=" + joiningDate + ", salary=" + salary
	 * + ", ssn=" + ssn + "]"; }
	 */
	
	
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + matrixId;
		result = prime * result + ((complexity == null) ? 0 : complexity.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof TaskMatrix))
			return false;
		TaskMatrix other = (TaskMatrix) obj;
		if (matrixId != other.matrixId)
			return false;
		if (complexity == null) {
			if (other.complexity != null)
				return false;
		} else if (!complexity.equals(other.complexity))
			return false;
		return true;
	}*/

}
