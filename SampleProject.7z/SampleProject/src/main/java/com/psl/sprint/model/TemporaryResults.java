package com.psl.sprint.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_results")
public class TemporaryResults {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "connector_id")
	private Integer connector_id;

	@Column(name = "connector_name")
	private String connector_name;
	
	@Column(name = "resource_id")
	private Integer resource_id;

	@Column(name = "bandwidth_share")
	private Double bandwidth_share;
	
	@Column(name = "work_date")
	private Date work_date;
	
	@Column(name = "adjust_day")
	private Double adjust_day;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getConnector_id() {
		return connector_id;
	}

	public void setConnector_id(Integer connector_id) {
		this.connector_id = connector_id;
	}

	public String getConnector_name() {
		return connector_name;
	}

	public void setConnector_name(String connector_name) {
		this.connector_name = connector_name;
	}

	public Integer getResource_id() {
		return resource_id;
	}

	public void setResource_id(Integer resource_id) {
		this.resource_id = resource_id;
	}

	public Double getBandwidth_share() {
		return bandwidth_share;
	}

	public void setBandwidth_share(Double bandwidth_share) {
		this.bandwidth_share = bandwidth_share;
	}

	public Date getWork_date() {
		return work_date;
	}

	public void setWork_date(Date work_date) {
		this.work_date = work_date;
	}

	public Double getAdjust_day() {
		return adjust_day;
	}

	public void setAdjust_day(Double adjust_day) {
		this.adjust_day = adjust_day;
	}

	@Override
	public String toString() {
		return "TemporaryResults [id=" + id + ", connector_id=" + connector_id
				+ ", connector_name=" + connector_name + ", resource_id="
				+ resource_id + ", bandwidth_share=" + bandwidth_share
				+ ", work_date=" + work_date + ", adjust_day=" + adjust_day
				+ "]";
	}
	
}