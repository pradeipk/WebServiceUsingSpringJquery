/**
 * 
 */
package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.AssignTask;
import com.psl.sprint.model.Subtask;

/**
 * @author pradeep_patel
 *
 */
public interface AssignTaskService {
	
	public AssignTask findById(int id) throws Exception;

	public void saveAssignTask(AssignTask assignTask)throws Exception;

	public void updateAssignTask(AssignTask assignTask)throws Exception;

	public void deleteAssignTask(String ssn)throws Exception;

	public List<Subtask> findAllAssignTask()throws Exception;

	public List<AssignTask> findAssignTaskByConnectorId(Integer connectorId)throws Exception;

}
