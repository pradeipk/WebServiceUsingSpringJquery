/**
 * 
 */
package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.AssignTaskDao;
import com.psl.sprint.model.AssignTask;
import com.psl.sprint.model.Subtask;

/**
 * @author pradeep_patel
 * 
 */
@Service("assigntaskService")
@Transactional
public class AssignTaskServiceImpl implements AssignTaskService {

	@Autowired
	private AssignTaskDao dao;

	public AssignTask findById(int id) {
		return null;
	}

	public void saveAssignTask(AssignTask assignTask) throws Exception {
		dao.saveAssignTask(assignTask);
		
	}

	public void updateAssignTask(AssignTask assignTask) {
		
	}

	public void deleteAssignTask(String ssn) {
		
	}

	public List<Subtask> findAllAssignTask() {
		return null;
	}

	public List<AssignTask> findAssignTaskByConnectorId(Integer connectorId) throws Exception {
		return dao.findAllAssignTasksByConnectorId(connectorId);
	}	

}
