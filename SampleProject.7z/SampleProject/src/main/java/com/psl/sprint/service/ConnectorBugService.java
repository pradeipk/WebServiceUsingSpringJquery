package com.psl.sprint.service;

import com.psl.sprint.model.ConnectorBug;


public interface ConnectorBugService extends GenericService {
	public void delete(Integer connectorId) throws Exception;
	public ConnectorBug findByConnector(Integer connectorId) throws Exception;
}
