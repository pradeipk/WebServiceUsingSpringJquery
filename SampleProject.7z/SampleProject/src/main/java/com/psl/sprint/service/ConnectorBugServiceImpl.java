package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.ConnectorBugDao;
import com.psl.sprint.model.ConnectorBug;
import com.psl.sprint.util.SprintConstants;

@Service("connectorBugService")
@Transactional(rollbackFor = { Exception.class })
public class ConnectorBugServiceImpl extends SprintConstants implements ConnectorBugService {

	@Autowired
	ConnectorBugDao connectorBugDao;

	@Override
	public Object findById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		connectorBugDao.saveEntity(object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		connectorBugDao.deleteEntity(object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Integer connectorId) throws Exception {
		connectorBugDao.delete(connectorId);
	}

	@Override
	public ConnectorBug findByConnector(Integer connectorId) throws Exception {
		return connectorBugDao.findByConnector(connectorId);	
	}
}