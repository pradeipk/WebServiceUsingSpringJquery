package com.psl.sprint.service;

public interface ConnectorComplexityService extends GenericService {
	public void deleteAllByConnectorId(Integer connectorId) throws Exception;
}
