package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.ConnectorComplexityDao;

@Service("connectorComplexService")
@Transactional(rollbackFor = Exception.class)
public class ConnectorComplexityServiceImpl implements ConnectorComplexityService {

	@Autowired
	private ConnectorComplexityDao connectorComplexityDao;

	@Override
	public Object findById(Integer id) throws Exception {
		return connectorComplexityDao.findById(id);
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		connectorComplexityDao.saveEntity(object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		connectorComplexityDao.updateEntity(object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		connectorComplexityDao.deleteEntity(object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteAllByConnectorId(Integer connectorId) throws Exception {
		// TODO Auto-generated method stub
	}
}
