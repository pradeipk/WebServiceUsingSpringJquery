package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.ConnectorEstimationMappingDao;
import com.psl.sprint.model.ConnectorEstimationMapping;
import com.psl.sprint.model.EstimationHeaderConnector;
import com.psl.sprint.model.EstimationHeaderQuestionConnector;

@Service("connectorEstimationMappingService")
@Transactional(rollbackFor = Exception.class)
public class ConnectorEstimationMappingServiceImpl implements
		ConnectorEstimationMappingService {
	
	@Autowired
	private ConnectorEstimationMappingDao connectorEstimationMappingDao;

	@Override
	public List<ConnectorEstimationMapping> findConnectorEstimationMappingByConnectorId(
			Integer connectorId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object findById(Integer id) throws Exception {
		return null;
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		connectorEstimationMappingDao.saveEntity(object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteByConnectorId(Integer connectorId) throws Exception {
		connectorEstimationMappingDao.deleteByConnectorId(connectorId);
	}

	@Override
	public List<EstimationHeaderConnector> findEstimationHeaderConnectorByConnectorIdAndType(
			Integer connectorId, String connectorType) throws Exception {
		return connectorEstimationMappingDao.findEstimationHeaderConnectorByConnectorIdAndType(connectorId, connectorType);
	}

	@Override
	public List<EstimationHeaderQuestionConnector> findEstimationHeaderQuestionConnectorByConnectorId(
			Integer connectorId) throws Exception {
		return connectorEstimationMappingDao.findEstimationHeaderQuestionConnectorByConnectorId(connectorId);
	}

	@Override
	public List<EstimationHeaderQuestionConnector> findEstimationHeaderQuestionConnectorByConnectorIdAndType(
			Integer connectorId, String connectorType) throws Exception {
		return connectorEstimationMappingDao.findEstimationHeaderQuestionConnectorByConnectorIdAndType(connectorId, connectorType);
	}


}