package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.ConnectorIssueDao;
import com.psl.sprint.model.ConnectorIssue;
import com.psl.sprint.model.ConnectorIssueList;
import com.psl.sprint.util.SprintConstants;

@Service("connectorIssueService")
@Transactional(rollbackFor = Exception.class)
public class ConnectorIssueServiceImpl extends SprintConstants implements
		ConnectorIssueService {

	@Autowired
	private ConnectorIssueDao connectorIssueDao;

	@Override
	public ConnectorIssue findById(Integer id) throws Exception {
		return connectorIssueDao.findById(id);
	}

	@Override
	public void saveConnector(ConnectorIssue connectorIssue) throws Exception {
		connectorIssueDao.saveConnector(connectorIssue);
	}

	@Override
	public void updateConnector(ConnectorIssue connectorIssue) throws Exception {
		connectorIssueDao.updateConnector(connectorIssue);
	}

	@Override
	public List<ConnectorIssueList> findAllConnectorParentId(Integer connectorParentId, Integer issueType)
			throws Exception {
		return connectorIssueDao.findAllConnectorParentId(connectorParentId, issueType);
	}
}