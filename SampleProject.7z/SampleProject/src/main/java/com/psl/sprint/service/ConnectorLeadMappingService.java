package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.ConnectorLeadMapping;
import com.psl.sprint.model.Resource;

public interface ConnectorLeadMappingService {

	public void saveEntity(ConnectorLeadMapping connectorLeadMapping)
			throws Exception;

	public List<ConnectorLeadMapping> findMapping() throws Exception;

	public List<ConnectorLeadMapping> findMappingForRecource(
			Integer resourceId, String jobAssigned, boolean isjobAssigned)
			throws Exception;

	public List<ConnectorLeadMapping> findByConnectorIdAndUser(
			Integer connectorMasterId, Integer resourceId) throws Exception;

	public ConnectorLeadMapping findById(Integer id) throws Exception;

	// added by NN
	public List<Resource> findLeadsByRole(String roleType,
			Integer connectorMasterID) throws Exception;

	public List<ConnectorLeadMapping> findMappingForRecource(
			Integer resourceId, String jobAssigned, boolean b, Boolean isQa)
			throws Exception;
}
