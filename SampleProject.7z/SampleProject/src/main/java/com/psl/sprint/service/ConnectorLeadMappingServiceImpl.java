package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.psl.sprint.dao.ConnectorLeadMappingDao;
import com.psl.sprint.dao.GenericDao;
import com.psl.sprint.model.ConnectorLeadMapping;
import com.psl.sprint.model.Resource;

@Service("connectorLeadMappingService")
@Transactional(rollbackFor = Exception.class)
public class ConnectorLeadMappingServiceImpl implements
		ConnectorLeadMappingService {

	@Autowired
	private ConnectorLeadMappingDao connectorLeadMappingDao;

	@Override
	public void saveEntity(ConnectorLeadMapping connectorLeadMapping)
			throws Exception {
		connectorLeadMappingDao.saveEntity(connectorLeadMapping);

	}

	@Override
	public List<ConnectorLeadMapping> findMapping() throws Exception {
		return connectorLeadMappingDao.findMapping();
	}

	@Override
	public List<ConnectorLeadMapping> findMappingForRecource(
			Integer resourceId, String jobAssigned, boolean isjobAssigned)
			throws Exception {
		// TODO Auto-generated method stub
		return connectorLeadMappingDao.findMappingForRecource(resourceId,
				jobAssigned, isjobAssigned);
	}

	@Override
	public List<ConnectorLeadMapping> findByConnectorIdAndUser(
			Integer connectorMasterId, Integer resourceId) throws Exception {
		// TODO Auto-generated method stub
		return connectorLeadMappingDao.findByConnectorIdAndUser(
				connectorMasterId, resourceId);
	}

	@Override
	public ConnectorLeadMapping findById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return (ConnectorLeadMapping) connectorLeadMappingDao.findById(id);
	}

	@Override
	public List<Resource> findLeadsByRole(String roleType,
			Integer connectorMasterID) throws Exception {

		return connectorLeadMappingDao.findLeadsByRole(roleType,
				connectorMasterID);
	}

	@Override
	public List<ConnectorLeadMapping> findMappingForRecource(
			Integer resourceId, String jobAssigned, boolean isjobAssigned,
			Boolean isQaResource) throws Exception {
		// TODO Auto-generated method stub
		return connectorLeadMappingDao.findMappingForRecource(resourceId,
				jobAssigned, isjobAssigned, isQaResource);

	}

}
