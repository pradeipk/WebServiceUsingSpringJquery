package com.psl.sprint.service;

import java.util.List;
import java.util.Map;

import com.psl.sprint.model.ConnectorMaster;



public interface ConnectorMasterService extends GenericService {

	public List<ConnectorMaster> findAllConnector(Map<String, Object> filter)
			throws Exception;
	
	
}

