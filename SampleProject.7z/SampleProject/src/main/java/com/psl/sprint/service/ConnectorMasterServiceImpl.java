package com.psl.sprint.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.ConnectorMasterDao;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.util.SprintConstants;

@Service("connectorMasterService")
@Transactional(rollbackFor = { Exception.class })
public class ConnectorMasterServiceImpl extends SprintConstants implements ConnectorMasterService {

	@Autowired
	ConnectorMasterDao connectorMasterDao;

	@Override
	public Object findById(Integer id) throws Exception {
		return connectorMasterDao.findById(id);
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		connectorMasterDao.saveEntity(object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		connectorMasterDao.updateEntity(object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<?> findAll() throws Exception {
		return connectorMasterDao.findAll();
	}
	
	@Override
	public List<ConnectorMaster> findAllConnector(Map<String, Object> filter)
			throws Exception {
		return connectorMasterDao.findAllConnector(filter);	

	}		


}