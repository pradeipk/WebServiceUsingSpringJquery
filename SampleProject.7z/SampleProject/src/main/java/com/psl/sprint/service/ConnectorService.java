package com.psl.sprint.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.psl.sprint.dto.PlanDTO;
import com.psl.sprint.dto.ResourceDTO;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.model.EstimatesPDF;
import com.psl.sprint.model.FunctionalRequrement;
import com.psl.sprint.model.RequirementDTO;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.Review;
import com.psl.sprint.model.ReviewPhase;
import com.psl.sprint.model.ReviewUI;

public interface ConnectorService {

	public void saveConnector(Connector connector) throws Exception;

	public void updateConnector(Connector connector) throws Exception;

	public void updateConnector(Connector connector,
			RequirementDTO requirementDTO) throws Exception;

	public List<Connector> findAllConnector(Map<String, Object> filter)
			throws Exception;

	public List<Connector> findByConnectorName(String connector)
			throws Exception;

	public Set<FunctionalRequrement> findAllRequirements(String connector)
			throws Exception;

	public List<PlanDTO> findAllPlans(String connector) throws Exception;

	public List<ResourceDTO> findAllResources(String connector)
			throws Exception;

	public void editAllocation(Integer allocationId, Integer resourceId)
			throws Exception;

	public Connector findById(Integer id) throws Exception;

	public List<ResourceDTO> findAllResourcesWithDateFlag(String connector)
			throws Exception;

	public List<Resource> findAllResourcesForTheConnector(String connector)
			throws Exception;

	public EstimatesPDF findByConnectorId(Integer connectorId) throws Exception;

	public void save(EstimatesPDF estimatesPDF) throws Exception;

	public void update(EstimatesPDF estimatesPDF) throws Exception;

	public EstimatesPDF findByConnectorId(int connectorId) throws Exception;

	public List<EstimatesPDF> findAll() throws Exception;
	
	public EstimatesPDF findByFileName(String fileName, String fieldName) throws Exception ;
	
	public List<Connector> findAllByConnectorParentId(Integer connectorParentId)
			throws Exception;

	public List<Integer> findAllConnectorMasters(Map<String, Object> filter) throws Exception;

	public List<Connector> findAllConnectorsWithNameLike()
			throws Exception;
	
	public Double getTotalPDSUtilized(String connectorName) throws Exception;
	
	public List<Connector> findAllConnectors() throws Exception;
	
	public List<Integer> findMasterIds(List<Integer> connectorIds) throws Exception;
	
	public List<ReviewPhase> getAllReviewPhases() throws Exception;

	public void saveReviewPhase(ReviewPhase phase) throws Exception;

	public ReviewPhase findReviewPhaseByID(Integer id) throws Exception;

	public ConnectorMaster findByIdConnMaster(Integer id) throws Exception;

	public void saveReview(Review review) throws Exception;
	
	public List<ConnectorMaster> findAllConnectorMaster() throws Exception;
	
	public List<Integer> findConnectorsByMasterId(Integer masterId) throws Exception;
	
	public List<ReviewUI> getAllReviews() throws Exception;
	
	public List<ReviewUI> getReview() throws Exception;
	
	public List<ReviewUI> getReviewForConnector(Integer connectorMID) throws Exception;
	
	public Review findReviewById(Integer reviewId) throws Exception;
	
	public void updateReview(Review review) throws Exception;
	
	public void deleteReview(Integer reviewId) throws Exception;	
	
	
}