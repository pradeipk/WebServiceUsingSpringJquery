package com.psl.sprint.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.ConnectorDao;
import com.psl.sprint.dao.ConnectorMasterDao;
import com.psl.sprint.dao.EstimatesPDFDao;
import com.psl.sprint.dao.FunctionalRequirementDao;
import com.psl.sprint.dao.MasterDao;
import com.psl.sprint.dao.ResourceAllocationReportDao;
import com.psl.sprint.dao.ReviewDao;
import com.psl.sprint.dao.ReviewPhaseDao;
import com.psl.sprint.dto.PlanDTO;
import com.psl.sprint.dto.ResourceDTO;
import com.psl.sprint.exception.MultipleRecordExists;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.ConnectorMaster;
import com.psl.sprint.model.EstimatesPDF;
import com.psl.sprint.model.FunctionalRequrement;
import com.psl.sprint.model.Leave;
import com.psl.sprint.model.MatrixDTO;
import com.psl.sprint.model.RequirementDTO;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.model.Review;
import com.psl.sprint.model.ReviewPhase;
import com.psl.sprint.model.ReviewUI;
import com.psl.sprint.model.TaskMatrix;
import com.psl.sprint.util.SprintConstants;
import com.psl.sprint.util.SprintEngine;

@Service("connectorService")
@Transactional(rollbackFor = Exception.class)
public class ConnectorServiceImpl extends SprintConstants implements
		ConnectorService {

	@Autowired
	private ConnectorDao connectorDao;
	
	@Autowired
	private ReviewPhaseDao reviewPhaseDao;
	
	@Autowired
	private ConnectorMasterDao connectorMasterDao;
	
	@Autowired
	private ReviewDao reviewDao;

	@Autowired
	private ResourceAllocationReportDao allocationDao;

	@Autowired
	private MasterDao masterDao;

	@Autowired
	private LeaveService leaveService;

	@Autowired
	private FunctionalRequirementDao frDao;

	@Autowired
	private EstimatesPDFDao estimatesPdfDao;

	public void saveConnector(Connector connector) throws Exception {
		connectorDao.saveConnector(connector);
	}

	public List<Connector> findAllConnector(Map<String, Object> filter)
			throws Exception {
		return connectorDao.findAllConnector(filter);
	}

	public List<Connector> findByConnectorName(String connector)
			throws Exception {
		return connectorDao.findAllByConnectorName(connector);
	}

	/**
	 * This method update connector detail and this method also add requirements
	 * and task
	 */
	public void updateConnector(Connector connector,
			RequirementDTO requirementDTO) throws Exception {

		try {

			if (requirementDTO != null) {
				Connector connector0 = connectorDao.findAllByConnectorName(
						connector.getName()).get(0);
				Set<FunctionalRequrement> requirements = connector0
						.getRequrements();

				String uniquerequirementName = requirementDTO.getUniqueName()
						+ connector0.getName();
				FunctionalRequrement requirement = frDao
						.findByUniqueName(uniquerequirementName);
				List<FunctionalRequrement> frList = frDao
						.findByRequirementNameAndConnectorName(
								requirementDTO.getRequirementName(), connector0);
				/*
				 * Check if reqirement exists during creation
				 */
				if (requirement != null || !frList.isEmpty()) {
					throw new MultipleRecordExists("Requirement with name :"
							+ requirementDTO.getUniqueName() + " or "
							+ requirementDTO.getRequirementName()
							+ " already exists for this connector");
				} else {
					requirement = new FunctionalRequrement();
				}

				/*
				 * create new requirement
				 */
				requirement.setRequirement(requirementDTO.getRequirementName());
				requirement.setCreatedDate(new LocalDate());
				requirement.setResourceplanned(2);
				requirement.setUniqueId(uniquerequirementName);
				requirement.setDetail("No details");

				if (requirements == null) {
					requirements = new HashSet<FunctionalRequrement>();
				}
				List<MatrixDTO> matrixList = requirementDTO.getMatrix();
				TaskMatrix matrix = null;
				/*
				 * Matrix DTO represents one task details Sub Task Is a master
				 * table do not make any entry on it;
				 */
				List<TaskMatrix> tm = new ArrayList<TaskMatrix>();
				for (MatrixDTO matrixDTO : matrixList) {
					// only that is having task name in it , i.e which was
					// selected
					if (matrixDTO.getTaskName() != null) {
						matrix = new TaskMatrix();
						matrix.setTaskName(matrixDTO.getTaskName());
						matrix.setComplexity(matrixDTO.getComplexity());
						matrix.setDependency(matrixDTO.getDependency());
						matrix.setImpact_on_feature(matrixDTO
								.getImpact_on_feature());
						matrix.setImpact_on_performance(matrixDTO
								.getImpact_on_performance());
						matrix.setUncertainity(matrixDTO.getUncertainity());
						matrix.setAdditional_testing_required(matrixDTO
								.getAdditional_testing_required());
						matrix.setTask_id(matrixDTO.getTask_id());
						Integer storyPoint = SprintEngine
								.calculateStoryPoint_acf(matrix);
						matrix.setStory_point(storyPoint);
						/*
						 * adding task to matrix
						 */
						tm.add(matrix);
					}

				}
				// for new requirement there shouldn't be any matrix
				requirement.setTaskMatrix(tm);
				requirements.add(requirement);
				// adding requiremnt to connector
				connector0.setRequrements(requirements);
				connectorDao.updateConnector(connector0);
			} else {
				connectorDao.updateConnector(connector);
			}
		} catch (Exception e) {
			e.getMessage();
			throw e;
		}
	}

	public List<PlanDTO> findAllPlans(String connector) throws Exception {

		Connector connector0 = connectorDao.findAllByConnectorName(connector)
				.get(0);

		Set<FunctionalRequrement> requrements = connector0.getRequrements();

		PlanDTO dto = null;
		List<PlanDTO> dtoList = new ArrayList<PlanDTO>();

		for (FunctionalRequrement functionalRequrement : requrements) {
			Integer storypoint = 0;
			dto = new PlanDTO();
			for (TaskMatrix matrix : functionalRequrement.getTaskMatrix()) {
				storypoint = storypoint + matrix.getStory_point();
			}
			dto.setRequirement(functionalRequrement.getRequirement());
			dto.setRequirementId(functionalRequrement.getUniqueId());
			dto.setId(functionalRequrement.getId());
			dto.setStorypoint(storypoint);
			dtoList.add(dto);
		}
		return dtoList;

	}

	public Set<FunctionalRequrement> findAllRequirements(String connector)
			throws Exception {
		Connector connector0 = connectorDao.findAllByConnectorName(connector)
				.get(0);
		return connector0.getRequrements();

	}

	// Never remove a resource from connector even it bein assigned by mistake
	public List<ResourceDTO> findAllResources(String connector)
			throws Exception {
		Connector connector0 = connectorDao.findAllByConnectorName(connector)
				.get(0);
		Set<Resource> resources = connector0.getResources();
		List<ResourceDTO> resources1 = new ArrayList<ResourceDTO>();
		ResourceDTO res_dto = null;

		// why we are doing this ?, since fetch type is lazy so any getcall on
		// connector should be
		// done in transactional method of service class;

		for (Resource resource : resources) {

			// todays date is less than end date
			for (ResourceAllocationLog allocation : resource
					.getResourceAllocationList()) {
				if (connector.equalsIgnoreCase(allocation.getConnectorName())) {
					res_dto = new ResourceDTO();
					res_dto.setName(resource.getFirstName() + " "
							+ resource.getLastName());
					res_dto.setResourceId(resource.getResourceId());
					// if( new
					// DateTime().isBefore(allocation.getEndDate().toDateTimeAtCurrentTime()))
					// {
					res_dto.setStartDate(allocation.getStartDate());
					res_dto.setEndDate(allocation.getEndDate());
					res_dto.setCurrent_level(allocation.getBandwidthShare());
					res_dto.setAllocationId(allocation.getAllocationId());

					resources1.add(res_dto);
				}
			}
		}

		return resources1;

	}

	public List<Resource> findAllResourcesForTheConnector(String connector)
			throws Exception {
		Connector connector0 = connectorDao.findAllByConnectorName(connector)
				.get(0);
		Resource resource = null;
		List<Resource> r = new ArrayList<Resource>();
		for (Resource iterable_element : connector0.getResources()) {
			resource = new Resource();

			resource.setFirstName(iterable_element.getFirstName());
			resource.setResourceId(iterable_element.getResourceId());
			r.add(iterable_element);

		}
		return r;
	}

	/**
	 * 
	 */
	public List<ResourceDTO> findAllResourcesWithDateFlag(String connector)
			throws Exception {
		Connector connector0 = connectorDao.findAllByConnectorName(connector)
				.get(0);
		Set<Resource> resources = connector0.getResources();
		List<ResourceDTO> resources1 = new ArrayList<ResourceDTO>();
		ResourceDTO res_dto = null;

		// why we are doing this ?, since fetch type is lazy so any getcall on
		// connector should be
		// done in transactional method of service class;
		masterDao.findUniqueRecordByName(FREEZE_TIME);
		LocalDate d = new LocalDate();// intialize your date to any date
		LocalDate dateBefore = new LocalDate(d.minusDays(Integer.parseInt(masterDao
				.findUniqueRecordByName(FREEZE_TIME).getValue())));
		/* Loop over all resources who worked for this connector */
		for (Resource resource : resources) {
			if (resource.getJobAssigned().equals("Lead") || resource.getJobAssigned().equals("Others"))
				continue;
			Map<LocalDate, Double> leaveList = new HashMap<LocalDate, Double>();
			Map<LocalDate, Object> adjust = new HashMap<LocalDate, Object>();
			Map<LocalDate, Double> othersList = new HashMap<LocalDate, Double>();
			List<Leave> leaves = leaveService.findByResourceID(resource
					.getResourceId());
			for (Leave leave : leaves) {
				int difference = Days.daysBetween(leave.getStartDate(),
						leave.getEndDate()).getDays();
				LocalDate temp = leave.getStartDate();
				for (int ii = 0; ii <= difference; ii++) {
					if (!(temp.getDayOfWeek() == 6 || temp.getDayOfWeek() == 7)) {
						if (leave.getAdjust() == null)
							adjust.put(temp, null);
						else 
							adjust.put(temp, leave.getAdjust());
						
						if (leave.getType().equals("SELF")
								&& leave.getPercentage() == 1d) {
							leaveList.put(temp, leave.getPercentage());
						} else {
							if (othersList.containsKey(temp)) {
								othersList.put(temp, othersList.get(temp)
										+ leave.getPercentage());
							} else {
								othersList.put(temp, leave.getPercentage());
							}
						}
					}
					temp = temp.plusDays(1);
				}
			}
			/*
			 * todays date is less than end date
			 */
			LocalDate s_date = null;
			LocalDate e_date = null;
			/* Get Allocation History for this resource and loop over */
			for (ResourceAllocationLog allocation : resource
					.getResourceAllocationList()) {
				/*
				 * only those record which are for specified resource and
				 * connector Resource.getAllocation will fetch all its child
				 * irrespective of connector
				 */
				boolean isNotAWeekendAllocation = true;
				boolean isSameDate = allocation.getStartDate().equals(
						allocation.getEndDate());
				if (isSameDate
						&& (6 == allocation.getStartDate().getDayOfWeek() || 7 == allocation
								.getStartDate().getDayOfWeek())) {
					isNotAWeekendAllocation = false;
				}

				if (connector.equalsIgnoreCase(allocation.getConnectorName())
						&& isNotAWeekendAllocation) {
					s_date = allocation.getStartDate();
					e_date = allocation.getEndDate();
					res_dto = new ResourceDTO();
					res_dto.setName(resource.getFirstName() + " "
							+ resource.getLastName());
					res_dto.setFirstName(resource.getFirstName());
					res_dto.setLastName(resource.getLastName());
					res_dto.setResourceId(resource.getResourceId());
					res_dto.setStartDate(allocation.getStartDate());
					res_dto.setEndDate(allocation.getEndDate());
					res_dto.setCurrent_level(allocation.getBandwidthShare() * 100);
					res_dto.setAllocationId(allocation.getAllocationId());
					res_dto.setDescription(allocation.getDescription());
					res_dto.setJobAssigned(resource.getJobAssigned());
					int weekends = 0;
					double leaveXclusions = 0d;
					double othersXclusions = 0d;
					/* Check if there are leaves or holidays in between */
					while (s_date.isBefore(e_date) || s_date.equals(e_date)) {
						if (leaveList.containsKey(s_date)) {
							if (!(s_date.getDayOfWeek() == 6 || s_date
									.getDayOfWeek() == 7)) {
								if (adjust.containsKey(s_date) && adjust.get(s_date) == null)
									leaveXclusions += leaveList.get(s_date);
								else if (adjust.containsKey(s_date) && ((Boolean)adjust.get(s_date)).booleanValue())
									leaveXclusions += leaveList.get(s_date);
							}
						} else if (othersList.containsKey(s_date)) {
							if (!(s_date.getDayOfWeek() == 6 || s_date
									.getDayOfWeek() == 7)) {
								if (adjust.containsKey(s_date) && adjust.get(s_date) == null)
									leaveXclusions += othersList.get(s_date);
								else if (adjust.containsKey(s_date) && ((Boolean)adjust.get(s_date)).booleanValue())
									leaveXclusions += othersList.get(s_date);
							}
						}
						int d0 = s_date.getDayOfWeek();
						if (d0 == 6 || d0 == 7) {
							weekends++;
						}
						s_date = s_date.plusDays(1);
					}
					double totalDays = Days.daysBetween(
							allocation.getStartDate(), allocation.getEndDate())
							.getDays() + 1;
					totalDays = (totalDays - weekends)
							* allocation.getBandwidthShare();
					if (allocation.getBandwidthShare() < 1) 
						totalDays = totalDays - (leaveXclusions * allocation.getBandwidthShare());
					else 
						totalDays = totalDays - leaveXclusions;
					totalDays = totalDays
							- (othersXclusions * allocation.getBandwidthShare());
					res_dto.setPDs(new BigDecimal(totalDays).setScale(2,
							BigDecimal.ROUND_HALF_UP).doubleValue());
					res_dto.setExclusion(new BigDecimal(
							(othersXclusions * allocation.getBandwidthShare())
									+ leaveXclusions).setScale(2,
							BigDecimal.ROUND_HALF_UP).doubleValue());
					if (allocation.getEndDate().isBefore(dateBefore)) {
						res_dto.setAllow_editing(false);
					}
					resources1.add(res_dto);
				}
			}
		}
		Collections.sort(resources1);
		return resources1;

	}

	@Override
	public Connector findById(Integer id) throws Exception {
		return connectorDao.findById(id);
	}

	@Override
	public EstimatesPDF findByConnectorId(Integer connectorId) throws Exception {
		return estimatesPdfDao.findByConnectorId(connectorId);
	}

	@Override
	public void save(EstimatesPDF estimatesPDF) throws Exception {
		estimatesPdfDao.save(estimatesPDF);
	}

	@Override
	public void update(EstimatesPDF estimatesPDF) throws Exception {
		estimatesPdfDao.update(estimatesPDF);
	}

	@Override
	public EstimatesPDF findByConnectorId(int connectorId) throws Exception {
		return estimatesPdfDao.findByConnectorId(connectorId);
	}

	@Override
	public void updateConnector(Connector connector) throws Exception {
		connectorDao.updateConnector(connector);
	}

	@Override
	public List<EstimatesPDF> findAll() throws Exception {
		return estimatesPdfDao.findAll();
	}

	@Override
	public EstimatesPDF findByFileName(String fileName, String fieldName)
			throws Exception {
		return estimatesPdfDao.findByFileName(fileName, fieldName);
	}

	@Override
	public void editAllocation(Integer allocationId, Integer resourceId)
			throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Connector> findAllByConnectorParentId(Integer connectorParentId)
			throws Exception {
		return connectorDao.findAllByConnectorParentId(connectorParentId);
	}
	
	@Override
	public List<Connector> findAllConnectorsWithNameLike()
			throws Exception {
		return connectorDao.findAllConnectorsWithNameLike();
	}

	
	@Override
	public List<Integer> findAllConnectorMasters(Map<String, Object> filter)
			throws Exception {
		return connectorDao.findAllConnectorMasters(filter);
	}

	@Override
	public Double getTotalPDSUtilized(String connectorName) throws Exception {
		return connectorDao.getTotalPDSUtilized(connectorName);
	}

	@Override
	public List<Connector> findAllConnectors() throws Exception {
		return connectorDao.findAllConnectors();
		
	}
	
	@Override
	public List<Integer> findMasterIds(List<Integer> connectorIds) throws Exception {
		return connectorDao.findMasterIds(connectorIds);
		
	}

	//--------------
	@Override
	public List<ReviewPhase> getAllReviewPhases() throws Exception {
		return reviewPhaseDao.getAllReviewPhases();
	}

	@Override
	public void saveReviewPhase(ReviewPhase phase) throws Exception {
		reviewPhaseDao.saveReviewPhase(phase);
	}

	@Override
	public ReviewPhase findReviewPhaseByID(Integer id) throws Exception {
		return reviewPhaseDao.findReviewPhaseByID(id);
	}

	@Override
	public ConnectorMaster findByIdConnMaster(Integer id) throws Exception {
		return connectorMasterDao.findByIdConnMaster(id);
	}

	@Override
	public void saveReview(Review review) throws Exception {
		reviewDao.saveReview(review);
	}

	@Override
	public List<ConnectorMaster> findAllConnectorMaster() throws Exception {
		return connectorMasterDao.findAllConnectorMaster();		
	}

	@Override
	public List<ReviewUI> getAllReviews() throws Exception {
		return reviewDao.getAllReviews();
	}	
	
	@Override
	public List<Integer> findConnectorsByMasterId(Integer masterId) throws Exception{
		return connectorDao.findConnectorsByMasterId(masterId);
	}

	@Override
	public List<ReviewUI> getReview() throws Exception {
		return reviewDao.getReview();
	}

	@Override
	public List<ReviewUI> getReviewForConnector(Integer connectorMID)
			throws Exception {
		return reviewDao.getReviewForConnector(connectorMID);		
	}

	@Override
	public Review findReviewById(Integer reviewId) throws Exception {
		return reviewDao.findReviewById(reviewId);
	}

	@Override
	public void updateReview(Review review) throws Exception {
		reviewDao.updateReview(review);
	}

	@Override
	public void deleteReview(Integer reviewId) throws Exception {
		reviewDao.deleteReview(reviewId);
	}
}