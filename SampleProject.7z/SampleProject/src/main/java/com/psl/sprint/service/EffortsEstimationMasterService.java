package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.EffortsEstimationMaster;

public interface EffortsEstimationMasterService extends GenericService {
	public List<EffortsEstimationMaster> findByVersionAndType(String version, String connectorType) throws Exception;
}
