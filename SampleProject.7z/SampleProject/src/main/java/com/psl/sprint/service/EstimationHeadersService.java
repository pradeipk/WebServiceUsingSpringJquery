package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.EstimationHeaders;

public interface EstimationHeadersService extends GenericService {

	public List<EstimationHeaders> findByType(String connectorType, String version) throws Exception;
	
}
