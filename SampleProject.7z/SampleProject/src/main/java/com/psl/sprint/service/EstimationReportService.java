package com.psl.sprint.service;


 public interface EstimationReportService extends GenericService {

 }
