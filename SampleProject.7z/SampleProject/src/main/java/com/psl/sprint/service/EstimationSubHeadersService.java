package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.EstimationSubHeaders;

public interface EstimationSubHeadersService extends GenericService {
	public List<EstimationSubHeaders> findByHeaderId(Integer hid) throws Exception;
}
