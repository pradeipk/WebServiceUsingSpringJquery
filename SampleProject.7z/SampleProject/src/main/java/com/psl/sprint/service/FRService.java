package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.FunctionalRequrement;
import com.psl.sprint.model.MatrixDTO;
import com.psl.sprint.model.RequirementDTO;

public interface FRService {

	public FunctionalRequrement findById(int id) throws Exception;

	public void saveFirstRequrement(FunctionalRequrement requirement) throws Exception;

	public void updateFirstRequrement(RequirementDTO requirement) throws Exception;

	public void deleteFirstRequrement(String requirementName) throws Exception;

	public List<FunctionalRequrement> findAllFirstRequrement() throws Exception;

	public List<MatrixDTO> findAllTasksForARequirement(Integer id) throws Exception;

}
