package com.psl.sprint.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.FRDao;
import com.psl.sprint.dao.TaskMatrixDao;
import com.psl.sprint.exception.MandatoryFieldMissingException;
import com.psl.sprint.model.FunctionalRequrement;
import com.psl.sprint.model.MatrixDTO;
import com.psl.sprint.model.RequirementDTO;
import com.psl.sprint.model.TaskMatrix;
import com.psl.sprint.util.SprintEngine;

@Service("frService")
@Transactional(rollbackFor = Exception.class)
public class FRServiceImpl implements FRService {

	@Autowired
	private FRDao dao;

	@Autowired
	private TaskMatrixDao matrixDao;

	public FunctionalRequrement findById(int id) throws Exception {
		return dao.findById(id);
	}

	public void saveFirstRequrement(FunctionalRequrement requrement) throws Exception {
		dao.saveFR(requrement);
	}

	public List<FunctionalRequrement> findAllFirstRequrement() throws Exception {
		return dao.findAllRequirements();
	}

	public List<MatrixDTO> findAllTasksForARequirement(Integer id) throws Exception {

		FunctionalRequrement functionalRequrement = dao.findById(id);
		MatrixDTO dto = null;
		List<MatrixDTO> list = new ArrayList<MatrixDTO>();
		for (TaskMatrix matrix : functionalRequrement.getTaskMatrix()) {
			dto = new MatrixDTO();
			dto.setTaskName(matrix.getTaskName());
			dto.setTask_id(matrix.getTask_id());
			dto.setMatrixId(matrix.getMatrixId());			
			dto.setTaskName(matrix.getTaskName());
			dto.setComplexity(matrix.getComplexity());
			dto.setDependency(matrix.getDependency());
			dto.setImpact_on_feature(matrix.getImpact_on_feature());
			dto.setImpact_on_performance(matrix.getImpact_on_performance());
			dto.setUncertainity(matrix.getUncertainity());
			dto.setAdditional_testing_required(matrix.getAdditional_testing_required());
			dto.setTask_id(matrix.getTask_id());			
			list.add(dto);
		}

		return list;
	}

	@Override
	public void updateFirstRequrement(RequirementDTO requirementDTO) throws Exception {

		try {

			FunctionalRequrement functionalRequrement = dao.findById(requirementDTO.getRequirementId());

			if (functionalRequrement == null) {
				throw new MandatoryFieldMissingException("NO record Found with this ID:"
						+ requirementDTO.getRequirementId());
			}

			functionalRequrement.setRequirement(requirementDTO.getRequirementName());
			String temp = requirementDTO.getUniqueName().replace(functionalRequrement.getConnector().getName(), "");
			functionalRequrement.setUniqueId(temp + functionalRequrement.getConnector().getName());

			TaskMatrix matrix = null;
			for (MatrixDTO matrixDTO : requirementDTO.getMatrix()) {
				/*
				 * if task name is not null this means it was selected;
				 */
				if (matrixDTO.getTaskName() != null) {
					matrix = matrixDao.findById(matrixDTO.getMatrixId());
					matrix.setTaskName(matrixDTO.getTaskName());
					matrix.setComplexity(matrixDTO.getComplexity());
					matrix.setDependency(matrixDTO.getDependency());
					matrix.setImpact_on_feature(matrixDTO.getImpact_on_feature());
					matrix.setImpact_on_performance(matrixDTO.getImpact_on_performance());
					matrix.setUncertainity(matrixDTO.getUncertainity());
					matrix.setAdditional_testing_required(matrixDTO.getAdditional_testing_required());
					matrix.setTask_id(matrixDTO.getTask_id());
					Integer storyPoint = SprintEngine.calculateStoryPoint_acf(matrix);
					matrix.setStory_point(storyPoint);
					/*
					 * adding task to matrix
					 */
					functionalRequrement.getTaskMatrix().add(matrix);
				} else {
					matrix = matrixDao.findById(matrixDTO.getMatrixId());
					functionalRequrement.getTaskMatrix().remove(matrix);
				}

				functionalRequrement.setTaskMatrix(functionalRequrement.getTaskMatrix());
			}

			dao.updateFR(functionalRequrement);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	@Override
	public void deleteFirstRequrement(String requirementName) throws Exception {

	}

}
