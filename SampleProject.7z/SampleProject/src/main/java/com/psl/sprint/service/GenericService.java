package com.psl.sprint.service;

import java.util.List;

public interface GenericService {
	
	public Object findById(Integer id) throws Exception;

	public Object findByName(Object object) throws Exception;

	public void saveEntity(Object object) throws Exception;

	public void updateEntity(Object object) throws Exception;

	public void deleteEntity(Object object) throws Exception;

	public List<?> findAll() throws Exception;

}
