package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.IssueTrackerJiraMapping;

public interface IssueTrackerJiraMappingService {
	
	public void saveIssueTrackerJiraMapping(IssueTrackerJiraMapping issueTrackerJiraMapping) throws Exception;

	public List<IssueTrackerJiraMapping> findAll() throws Exception;
}
