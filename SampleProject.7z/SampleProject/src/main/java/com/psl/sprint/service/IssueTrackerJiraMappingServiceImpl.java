package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.IssueTrackerJiraMappingDao;
import com.psl.sprint.model.IssueTrackerJiraMapping;

@Service("issueTrackerJiraMappingService")
@Transactional
public class IssueTrackerJiraMappingServiceImpl implements IssueTrackerJiraMappingService{
	
	@Autowired
	private IssueTrackerJiraMappingDao issueTrackerJiraMappingDao;

	@Override
	public void saveIssueTrackerJiraMapping(
			IssueTrackerJiraMapping issueTrackerJiraMapping) throws Exception {
		issueTrackerJiraMappingDao.save(issueTrackerJiraMapping);	
	}

	@Override
	public List<IssueTrackerJiraMapping> findAll() throws Exception {
		return (List<IssueTrackerJiraMapping>) issueTrackerJiraMappingDao.findAll();
		
	}

}
