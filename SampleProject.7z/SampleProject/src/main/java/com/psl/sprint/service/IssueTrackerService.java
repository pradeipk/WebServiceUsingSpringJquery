package com.psl.sprint.service;

import java.util.List;
import java.util.Map;

import com.psl.sprint.model.IssueTracker;


public interface IssueTrackerService {

	public IssueTracker findById(Integer id) throws Exception;

	public void saveIssue(IssueTracker issueTracker) throws Exception;

	public void updateIssue(IssueTracker issueTracker) throws Exception;

	public List<IssueTracker> findAllIssues(Map<String, Object> filter)
			throws Exception;
}