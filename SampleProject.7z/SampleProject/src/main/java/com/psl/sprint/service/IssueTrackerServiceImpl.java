package com.psl.sprint.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.IssueTrackerDao;
import com.psl.sprint.model.IssueTracker;
import com.psl.sprint.util.SprintConstants;

@Service("issueTrackerService")
@Transactional(rollbackFor = Exception.class)
public class IssueTrackerServiceImpl extends SprintConstants implements
		IssueTrackerService {

	@Autowired
	private IssueTrackerDao issueTrackerDao;

	@Override
	public IssueTracker findById(Integer id) throws Exception {
		return issueTrackerDao.findById(id);	
	}

	@Override
	public void saveIssue(IssueTracker issueTracker) throws Exception {
		issueTrackerDao.saveIssue(issueTracker);
		
	}

	@Override
	public void updateIssue(IssueTracker issueTracker) throws Exception {
		issueTrackerDao.updateIssue(issueTracker);
		
	}

	public List<IssueTracker> findAllIssues(Map<String, Object> filter)
			throws Exception {
		return issueTrackerDao.findAllIssues(filter);

	}

}