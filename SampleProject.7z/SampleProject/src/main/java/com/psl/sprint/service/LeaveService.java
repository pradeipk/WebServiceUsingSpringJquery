package com.psl.sprint.service;

import java.util.List;

import org.joda.time.LocalDate;

import com.psl.sprint.model.Leave;

public interface LeaveService extends GenericService {

	public List<Leave> findByResourceID(int id) throws Exception;

	public Boolean isPublicLeave(LocalDate date) throws Exception;
}
