package com.psl.sprint.service;

import java.util.List;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.LeaveDao;
import com.psl.sprint.model.Leave;
import com.psl.sprint.util.SprintConstants;

@Service("leaveService")
@Transactional(rollbackFor = { Exception.class })
public class LeaveServiceImpl extends SprintConstants implements LeaveService {

	@Autowired
	LeaveDao leaveDao;
	
	@Override
	public Object findById(Integer id) throws Exception {
		return leaveDao.findById(id);
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		leaveDao.saveEntity(object);
		
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		leaveDao.updateEntity(object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		leaveDao.deleteEntity(object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Leave> findByResourceID(int id) throws Exception {
		List<Leave> leaves = leaveDao.findByResourceId(id);		
		return leaves;
		
	}

	@Override
	public Boolean isPublicLeave(LocalDate date) throws Exception {
		Leave leave = leaveDao.isPublicLeave(date);
		if (leave == null) return false;
		else return true;
	}
}
