package com.psl.sprint.service;

import com.psl.sprint.model.MasterTable;

public interface MasterService extends GenericService{

	MasterTable findUniqueRecordByName(String fREEZE_TIME) throws Exception;

}
