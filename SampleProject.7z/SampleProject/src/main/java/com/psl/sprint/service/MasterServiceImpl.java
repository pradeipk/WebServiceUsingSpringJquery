package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.MasterDao;
import com.psl.sprint.model.MasterTable;

@Service("masterServiceImpl")
@Transactional
public class MasterServiceImpl implements MasterService{
	
	@Autowired
	private MasterDao masterDao;

	@Override
	public Object findById(Integer id) throws Exception {
		return null;
	}

	@Override
	public Object findByName(Object object) throws Exception {
		return null;
		
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MasterTable findUniqueRecordByName(String fREEZE_TIME) throws Exception{
		try {
			return masterDao.findUniqueRecordByName(fREEZE_TIME);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}
