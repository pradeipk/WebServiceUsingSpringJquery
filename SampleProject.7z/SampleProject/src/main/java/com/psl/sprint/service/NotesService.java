package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.ConnectorPlannedCompletion;
import com.psl.sprint.model.Notes;


public interface NotesService extends GenericService {
	public Notes findByConnectorId(Integer connectorId) throws Exception;
	public List<ConnectorPlannedCompletion> findPlannedConnectorByDateOrMonth(String fromDate, String toDate, String monthYear, String comparisonType) throws Exception;
}
