package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.NotesDao;
import com.psl.sprint.model.ConnectorPlannedCompletion;
import com.psl.sprint.model.Notes;
import com.psl.sprint.util.SprintConstants;

@Service("notesService")
@Transactional(rollbackFor = { Exception.class })
public class NotesServiceImpl extends SprintConstants implements NotesService {

	@Autowired
	NotesDao notesDao;

	@Override
	public Object findById(Integer id) throws Exception {
		return notesDao.findById(id);
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		notesDao.saveEntity(object);

	}

	@Override
	public void updateEntity(Object object) throws Exception {
		notesDao.updateEntity(object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		notesDao.deleteEntity(object);
	}

	@Override
	public List<Notes> findAll() throws Exception {
		return (List<Notes>)notesDao.findAll();
	}

	@Override
	public Notes findByConnectorId(Integer connectorId) throws Exception {
		return notesDao.findByConnectorId(connectorId);
	}

	@Override
	public List<ConnectorPlannedCompletion> findPlannedConnectorByDateOrMonth(
			String fromDate, String toDate, String monthYear, String comparisonType)
			throws Exception {
		return notesDao.findPlannedConnectorByDateOrMonth(fromDate, toDate, monthYear, comparisonType);
	}
}
