package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.Questions;

public interface QuestionsService extends GenericService {
	public List<Questions> findByHeaderIdAndSubHeaderId(Integer hid, Integer shid) throws Exception;
}
