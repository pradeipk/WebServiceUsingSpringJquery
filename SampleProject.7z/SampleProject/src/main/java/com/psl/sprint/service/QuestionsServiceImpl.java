package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.QuestionsDao;
import com.psl.sprint.model.Questions;

@Service("questionsService")
@Transactional(rollbackFor = Exception.class)
public class QuestionsServiceImpl implements QuestionsService {

	@Autowired
	private QuestionsDao questionsDao;
	
	@Override
	public Object findById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Questions> findByHeaderIdAndSubHeaderId(Integer hid,
			Integer shid) throws Exception {
		return questionsDao.findByHeaderIdAndSubHeaderId(hid, shid);
	}

}
