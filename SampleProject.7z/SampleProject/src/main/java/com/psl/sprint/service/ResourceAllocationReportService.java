package com.psl.sprint.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.psl.sprint.dto.ReportDTO;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.model.TemporaryResults;

public interface ResourceAllocationReportService {

	public HashMap<String, Object> downloadResourceAllocationReport(
			ReportDTO reportDTO) throws Exception;

	public ResourceAllocationLog findById(Integer id) throws Exception;

	public void updateAllocationLog(ResourceAllocationLog allocationLog)
			throws Exception;

	public HashMap<String, Object> getResourceAllocationReport(
			ReportDTO reportDTO) throws Exception;

	public List<ReportDTO> getResourceUnallocationReport(ReportDTO reportDTO)
			throws Exception;

	public Map<Integer, Object> findAvailableResource(int resourceId,
			String startDate, String endDate) throws Exception;

	public List<Connector> findAll() throws Exception;

	public List<ReportDTO> getProjectWorkLog(int connectorId) throws Exception;

	public Double findMinimaOfAllAllocationsForAResourceForAConnectorForADateRange(
			String connectorName, int resourceId, String startDate,
			String endDate) throws Exception;

	public List<ResourceAllocationLog> findByUser(Resource resource, String date)
			throws Exception;

	public List<TemporaryResults> findByStartDateAndEndDate(String startDate,
			String endDate, String connectorName) throws Exception;

	public List<ResourceAllocationLog> findByUserStartDate(
			Resource subResource, String date) throws Exception;

}
