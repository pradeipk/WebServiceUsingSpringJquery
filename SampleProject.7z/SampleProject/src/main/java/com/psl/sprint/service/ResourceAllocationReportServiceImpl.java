package com.psl.sprint.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;
import org.joda.time.LocalDate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.ConnectorDao;
import com.psl.sprint.dao.LeaveDao;
import com.psl.sprint.dao.ResourceAllocationReportDao;
import com.psl.sprint.dao.TemporaryResultsDao;
import com.psl.sprint.dao.UserDao;
import com.psl.sprint.dto.ReportDTO;
import com.psl.sprint.model.AllocationDTO;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.model.TemporaryResults;
import com.psl.sprint.util.GeneralUtility;

@Service("resourceAllocationReportService")
@Transactional
public class ResourceAllocationReportServiceImpl implements
		ResourceAllocationReportService {

	@Autowired
	private ResourceAllocationReportDao resourceAllocationReportDao;

	@Autowired
	private UserDao userDao;

	@Autowired
	private ConnectorDao connectorDao;

	@Autowired
	private TemporaryResultsDao temporaryResultsDao;

	@Autowired
	private LeaveDao leaveDao;

	@Override
	public ResourceAllocationLog findById(Integer id) throws Exception {
		return resourceAllocationReportDao.findById(id);
	}

	@Override
	public void updateAllocationLog(ResourceAllocationLog allocationLog)
			throws Exception {

	}

	@Override
	public HashMap<String, Object> getResourceAllocationReport(
			ReportDTO reportDTO) throws Exception {

		String monthYear = reportDTO.getMonthYear();
		String startDate = reportDTO.getStartDate();
		String endDate = reportDTO.getEndDate();
		HashMap<String, Object> dataMap = new LinkedHashMap<String, Object>();
		int[] resourceIds = ArrayUtils.removeElement(
				reportDTO.getResourceIds(), 0);
		for (int i = 0; i < resourceIds.length; i++) {

			Resource resource = (Resource) userDao.findById(resourceIds[i]);

			if (reportDTO.getDuration().equals("monthlyradio")) {

				String[] monthYearArray = monthYear.split("-");
				startDate = monthYear + "-01";
				endDate = GeneralUtility.getLastDayOfMonth(
						Integer.parseInt(monthYearArray[1]),
						Integer.parseInt(monthYearArray[0]));

				List<ReportDTO> resourceAllocationData = resourceAllocationReportDao
						.getResourceAllocationData(resource.getResourceId(),
								startDate, endDate);
				List<ReportDTO> resourceAllocationGroupData = groupData(
						resourceAllocationData, resource);

				dataMap.put(
						resource.getResourceId() + "/" + resource.getUserName(),
						resourceAllocationGroupData);

			} else {

				List<ReportDTO> resourceAllocationData = resourceAllocationReportDao
						.getResourceAllocationData(resource.getResourceId(),
								startDate, endDate);
				List<ReportDTO> resourceAllocationGroupData = groupData(
						resourceAllocationData, resource);
				// dataMap.put(resource.getResourceId() + "/" +
				// resource.getUserName(),GeneralUtility.addAllocationRow(resourceAllocationGroupData,
				// "ALLOCATION"));
				dataMap.put(
						resource.getResourceId() + "/" + resource.getUserName(),
						resourceAllocationGroupData);
			}
		}
		return dataMap;
	}

	private List<ReportDTO> groupUnallocatedData(
			List<ReportDTO> resourceAllocationData, Resource resource) {

		List<ReportDTO> reportDTOList = groupSimilarUnallocatedData(
				resourceAllocationData, resource);

		List<ReportDTO> finalReportDTOList = new ArrayList<ReportDTO>();
		for (Iterator iterator = reportDTOList.iterator(); iterator.hasNext();) {
			ReportDTO reportDTO = (ReportDTO) iterator.next();
			finalReportDTOList.add(reportDTO);
			/*
			 * if (!reportDTO.getConnector().contains("/")) {
			 * finalReportDTOList.add(reportDTO); } else {
			 * 
			 * String[] connectorNameArray =
			 * reportDTO.getConnector().split("/"); String[] bandwidthArray =
			 * reportDTO.getBandwidthConcat().split("/");
			 * 
			 * for (int i = 0; i < connectorNameArray.length; i++) { ReportDTO
			 * currentReportDTO = new ReportDTO();
			 * BeanUtils.copyProperties(reportDTO, currentReportDTO);
			 * currentReportDTO.setConnector(connectorNameArray[i]);
			 * currentReportDTO.setBandwidthConcat(bandwidthArray[i]);
			 * finalReportDTOList.add(currentReportDTO); } }
			 */

		}
		return finalReportDTOList;
	}

	private List<ReportDTO> groupSimilarUnallocatedData(
			List<ReportDTO> resourceAllocationData, Resource resource) {
		List<ReportDTO> finalReportDTOList = new ArrayList<ReportDTO>();
		ReportDTO prevReportDTO = null;

		for (Iterator iterator = resourceAllocationData.iterator(); iterator
				.hasNext();) {
			ReportDTO currentReportDTO = (ReportDTO) iterator.next();

			if (currentReportDTO.getConnector() == null) {
				currentReportDTO.setConnector("Unallocated");
			}
			if (currentReportDTO.getUserName() == null) {
				currentReportDTO.setUserName(resource.getUserName());
			}

			// check if first record
			if (finalReportDTOList.size() == 0 && prevReportDTO == null) {

				prevReportDTO = currentReportDTO;
				prevReportDTO.setStartDate(currentReportDTO.getWorkdate());
				prevReportDTO.setEndDate(currentReportDTO.getWorkdate());

			} else {

				if (prevReportDTO.getBandwidth() == currentReportDTO
						.getBandwidth()
						&& GeneralUtility.getNextDate(
								prevReportDTO.getEndDate()).equals(
								currentReportDTO.getWorkdate())

				) {

					prevReportDTO.setEndDate(currentReportDTO.getWorkdate());

				} else {

					// move prevDTO to final list as connector name or bandwidth
					// changed
					finalReportDTOList.add(prevReportDTO);

					// assign new reportDTO to prev
					prevReportDTO = currentReportDTO;
					prevReportDTO.setStartDate(currentReportDTO.getWorkdate());
					prevReportDTO.setEndDate(currentReportDTO.getWorkdate());

				}
			}
		}

		if (prevReportDTO != null) {
			finalReportDTOList.add(prevReportDTO);
		}

		return finalReportDTOList;
	}

	private List<ReportDTO> groupData(List<ReportDTO> resourceAllocationData,
			Resource resource) {
		List<ReportDTO> reportDTOList = groupSimilarData(
				resourceAllocationData, resource);

		List<ReportDTO> finalReportDTOList = new ArrayList<ReportDTO>();
		for (Iterator iterator = reportDTOList.iterator(); iterator.hasNext();) {
			ReportDTO reportDTO = (ReportDTO) iterator.next();
			if (!reportDTO.getConnector().contains("/")) {
				finalReportDTOList.add(reportDTO);

			} else {

				String[] connectorNameArray = reportDTO.getConnector().split(
						"/");
				String[] bandwidthArray = reportDTO.getBandwidthConcat().split(
						"/");

				for (int i = 0; i < connectorNameArray.length; i++) {
					ReportDTO currentReportDTO = new ReportDTO();
					BeanUtils.copyProperties(reportDTO, currentReportDTO);
					currentReportDTO.setConnector(connectorNameArray[i]);
					currentReportDTO.setBandwidthConcat(bandwidthArray[i]);
					finalReportDTOList.add(currentReportDTO);
				}
			}

			/*
			 * Additonal check to add remaining unallocated for a same day
			 */
			if (!(reportDTO.getConnector().equals("Leave")
					|| (reportDTO.getType() != null && reportDTO.getType()
							.contains("TRAN")) || (reportDTO.getType() != null && reportDTO
					.getType().contains("MEET")))
					&& reportDTO.getUnallocated() > 0
					&& !(reportDTO.getConnector().equals("Unallocated"))) {
				ReportDTO currentReportDTO = new ReportDTO();
				BeanUtils.copyProperties(reportDTO, currentReportDTO);
				currentReportDTO.setConnector("Unallocated");
				currentReportDTO
						.setBandwidth(currentReportDTO.getUnallocated());
				currentReportDTO.setBandwidthConcat(currentReportDTO
						.getUnallocated() + "");
				finalReportDTOList.add(currentReportDTO);
			}

		}
		return finalReportDTOList;

	}

	private List<ReportDTO> groupSimilarData(
			List<ReportDTO> resourceAllocationData, Resource resource) {

		List<ReportDTO> finalReportDTOList = new ArrayList<ReportDTO>();
		ReportDTO prevReportDTO = null;
		for (Iterator iterator = resourceAllocationData.iterator(); iterator
				.hasNext();) {
			ReportDTO currentReportDTO = (ReportDTO) iterator.next();
			if (currentReportDTO.getConnector() == null) {
				currentReportDTO.setConnector("Unallocated");
			}
			if (currentReportDTO.getBandwidthConcat() == null) {
				currentReportDTO.setBandwidthConcat("0");
			}
			if (currentReportDTO.getUserName() == null) {
				currentReportDTO.setUserName(resource.getUserName());
			}
			// check if first record
			if (finalReportDTOList.size() == 0 && prevReportDTO == null) {

				prevReportDTO = currentReportDTO;
				prevReportDTO.setStartDate(currentReportDTO.getWorkdate());
				prevReportDTO.setEndDate(currentReportDTO.getWorkdate());

			} else {

				if (prevReportDTO.getConnector().equals(
						currentReportDTO.getConnector())
						&& prevReportDTO.getBandwidthConcat().equals(
								currentReportDTO.getBandwidthConcat())) {

					prevReportDTO.setEndDate(currentReportDTO.getWorkdate());

				} else {

					// move prevDTO to final list as connector name or bandwidth
					// changed
					finalReportDTOList.add(prevReportDTO);

					// assign new reportDTO to prev
					prevReportDTO = currentReportDTO;
					prevReportDTO.setStartDate(currentReportDTO.getWorkdate());
					prevReportDTO.setEndDate(currentReportDTO.getWorkdate());

				}
			}
		}
		finalReportDTOList.add(prevReportDTO);
		return finalReportDTOList;

	}

	@Override
	public HashMap<String, Object> downloadResourceAllocationReport(
			ReportDTO reportDTO) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ReportDTO> getResourceUnallocationReport(ReportDTO reportDTO)
			throws Exception {

		String monthYear = reportDTO.getMonthYear();
		String startDate = reportDTO.getStartDate();
		String endDate = reportDTO.getEndDate();

		List<ReportDTO> resourceUnallocationFinalList = new ArrayList<ReportDTO>();

		List<Resource> resourceIds = (List<Resource>) userDao.findAll(true,
				null);

		for (int i = 0; i < resourceIds.size(); i++) {

			Resource resource = resourceIds.get(i);

			if (reportDTO.getDuration().equals("monthlyradio")) {

				String[] monthYearArray = monthYear.split("-");
				startDate = monthYear + "-01";
				endDate = GeneralUtility.getLastDayOfMonth(
						Integer.parseInt(monthYearArray[1]),
						Integer.parseInt(monthYearArray[0]));

				List<ReportDTO> reportDTOs = resourceAllocationReportDao
						.getResourceUnallocationData(resource.getResourceId(),
								startDate, endDate);
				List<ReportDTO> resourceUnallocationGroupwiseData = groupUnallocatedData(
						reportDTOs, resource);
				resourceUnallocationFinalList.addAll(GeneralUtility
						.addAllocationRow(resourceUnallocationGroupwiseData,
								"UNALLOCATION"));

			} else {

				List<ReportDTO> reportDTOs = resourceAllocationReportDao
						.getResourceUnallocationData(resource.getResourceId(),
								startDate, endDate);
				List<ReportDTO> resourceUnallocationGroupwiseData = groupUnallocatedData(
						reportDTOs, resource);
				resourceUnallocationFinalList.addAll(GeneralUtility
						.addAllocationRow(resourceUnallocationGroupwiseData,
								"UNALLOCATION"));

			}
		}

		return resourceUnallocationFinalList;
	}

	/**
	 * This method return allocations for specific date range for an resource ,
	 * this method will filter out records which have allocations=100%
	 */
	@Override
	public Map<Integer, Object> findAvailableResource(int resourceId,
			String startDate, String endDate) throws Exception {

		try {
			Resource resource = (Resource) userDao.findById(resourceId);
			AllocationDTO allocations = null;
			List<ReportDTO> reports = resourceAllocationReportDao
					.getResourceAllocationDataForAssignWork(resourceId,
							startDate, endDate);
			List<AllocationDTO> allocationDTOList = new ArrayList<AllocationDTO>();
			Map<Integer, Object> maxBandwidthAndResources = new HashMap<Integer, Object>();
			ReportDTO reportDTO = null;
			// maxallocation is the collection of allocation he holds for a
			// range of date ;
			Set<Double> maxAllocatons = new HashSet<Double>();
			// Check this logic if data is coming wrong ; this was put for
			// unallocated resource
			// error;
			if (reports == null || reports.isEmpty()) {
				maxAllocatons.add(1.0);
			}
			if (reports != null && !reports.isEmpty() && reports.size() == 1) {
				reportDTO = reports.get(0);
				allocations = new AllocationDTO();
				allocations.setResourceName(resource.getFirstName());
				allocations.setAllocation_share(reportDTO.getBandwidth() * 100);
				allocations
						.setAvaliable_bandwith(reportDTO.getUnallocated() * 100);
				allocations.setEndDate(new LocalDate(reportDTO.getWorkdate()));
				if (reportDTO.getConnector() != null
						&& !reportDTO.getConnector().isEmpty()) {
					allocations.setConnector_name(reportDTO.getConnector());
				} else {
					allocations.setConnector_name("None");
				}
				allocations
						.setStartDate(new LocalDate(reportDTO.getWorkdate()));
				allocations.setResourceId(resourceId);
				maxAllocatons.add(reportDTO.getBandwidth());
				if (!allocations.getAvaliable_bandwith().equals(0.0d)) {
					allocationDTOList.add(allocations);
				}

			} else {
				Double tempAllocation = null;
				Double tempAllocation_next = null;
				ReportDTO nextReport = null;
				boolean lastRecord = false;
				String s_d = null;
				LocalDate s_day = null;
				LocalDate e_day = null;
				for (int k = 0; k < reports.size(); k++) {
					reportDTO = reports.get(k);
					maxAllocatons.add(reportDTO.getBandwidth());
					tempAllocation = reportDTO.getBandwidth();
					try {
						nextReport = reports.get(k + 1);
						tempAllocation_next = nextReport.getBandwidth();
					} catch (IndexOutOfBoundsException e) {
						lastRecord = true;
					}

					if (!tempAllocation.equals(tempAllocation_next)
							|| lastRecord) {
						allocations = new AllocationDTO();
						allocations.setResourceName(resource.getFirstName());
						allocations.setAllocation_share(reportDTO
								.getBandwidth() * 100);
						allocations.setAvaliable_bandwith(reportDTO
								.getUnallocated() * 100);
						allocations.setEndDate(new LocalDate(reportDTO
								.getWorkdate()));
						if (reportDTO.getConnector() != null
								&& !reportDTO.getConnector().isEmpty()) {
							allocations.setConnector_name(reportDTO
									.getConnector());
						} else {
							allocations.setConnector_name("None");
						}
						allocations.setStartDate(s_d == null ? new LocalDate(
								reportDTO.getWorkdate()) : new LocalDate(s_d));
						s_d = null;
						allocations.setResourceId(resourceId);
						s_day = allocations.getStartDate();
						e_day = allocations.getEndDate();

						/*
						 * if s date and e date are same and it is sat or
						 * sunday, if s day and e day are adjacent and its sat
						 * or sun , if available allocation is 0; exclude this
						 * records
						 */
						if (!allocations.getAvaliable_bandwith().equals(0.0d)
								&& !(s_day.getDayOfWeek() == 6 && e_day
										.equals(allocations.getStartDate()
												.plusDays(1)))
								&& !(s_day.equals(e_day) && (s_day
										.getDayOfWeek() == 6 || s_day
										.getDayOfWeek() == 7))) {

							allocationDTOList.add(allocations);
						}
					} else {
						if (s_d == null) {
							s_d = reportDTO.getWorkdate();
						}
						tempAllocation = reportDTO.getBandwidth();
					}
				}

			}
			if (!maxAllocatons.isEmpty()) {
				maxBandwidthAndResources.put(resourceId,
						Collections.max(maxAllocatons));
			}
			maxBandwidthAndResources.put(-resourceId, allocationDTOList);
			return maxBandwidthAndResources;
		} catch (Exception e) {
			throw e;
		}

	}

	@Override
	public List<Connector> findAll() throws Exception {

		List<Connector> connectorList = connectorDao.findAllConnector(null);
		return connectorList;

	}

	@Override
	public List<ReportDTO> getProjectWorkLog(int connectorId) throws Exception {

		List<ReportDTO> projectResourceAllocationList = resourceAllocationReportDao
				.getResourceAllocationForProject(connectorId);
		return projectResourceAllocationList;

	}

	@Override
	public Double findMinimaOfAllAllocationsForAResourceForAConnectorForADateRange(
			String connectorName, int resourceId, String startDate,
			String endDate) throws Exception {
		Map<String, Object> map = resourceAllocationReportDao
				.findMinimaOfAllAllocationsForAResourceForAConnectorForADateRange(
						connectorName, resourceId, startDate, endDate);
		return (Double) map.get("minAllocation");
	}

	@Override
	public List<ResourceAllocationLog> findByUser(Resource resource, String date)
			throws Exception {
		return resourceAllocationReportDao.findByUser(resource, date);
	}

	@Override
	public List<TemporaryResults> findByStartDateAndEndDate(String startDate,
			String endDate, String connectorName) throws Exception {
		return resourceAllocationReportDao.findByStartDateAndEndDate(startDate,
				endDate, connectorName);
	}

	@Override
	public List<ResourceAllocationLog> findByUserStartDate(
			Resource subResource, String date) throws Exception {
		// TODO Auto-generated method stub
		return resourceAllocationReportDao.findByUserStartDate(subResource,
				date);
	}
}
