package com.psl.sprint.service;

import java.util.List;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.SprintItemsDao;
import com.psl.sprint.model.SprintItem;
import com.psl.sprint.model.SprintSummary;

@Service("sprintItemsService")
@Transactional(rollbackFor = Exception.class)
public class SprintItemServiceImpl implements SprintItemService {

	@Autowired
	private SprintItemsDao sprintItemsDao;

	@Override
	public Object findById(Integer id) throws Exception {
		return sprintItemsDao.findById(id);
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		sprintItemsDao.saveEntity(object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		sprintItemsDao.updateEntity(object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		sprintItemsDao.deleteEntity(object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SprintItem> findBySprintMasterId(Integer sprintMasterId)
			throws Exception {
		return sprintItemsDao.findBySprintMasterId(sprintMasterId);
	}

	@Override
	public Double getTotalPercentageCompletionByConnectorIdAndHid(
			Integer connectorId, Integer hid) throws Exception {
		return sprintItemsDao.getTotalPercentageCompletionByConnectorIdAndHid(
				connectorId, hid);
	}

	@Override
	public List<SprintSummary> getSprintSummary(Integer[] connectorIds)
			throws Exception {
		return sprintItemsDao.getSprintSummary(connectorIds);
	}

	@Override
	public Object findByConnectorId(Integer connectorId) throws Exception {
		return sprintItemsDao.findByConnectorId(connectorId);
	}

	@Override
	public List<SprintSummary> getConnectorStoryPointsSprintWise(
			String startDate, String endDate) throws Exception {
		return sprintItemsDao.getConnectorStoryPointsSprintWise(startDate,
				endDate);
	}

	@Override
	public List<SprintItem> findByConnectorIdAndHidByOwner(Integer connectorId,
			Integer hid, Integer sprintId) throws Exception {
		// TODO Auto-generated method stub
		return sprintItemsDao.findByConnectorIdAndHidByOwner(connectorId, hid,
				sprintId);
	}

	@Override
	public List<SprintItem> findByConnectorIdAndHid(Integer connectorId,
			Integer hid) throws Exception {
		// TODO Auto-generated method stub
		return sprintItemsDao.findByConnectorIdAndHid(connectorId, hid);
	}

	@Override
	public SprintItem findBySprintidnadHid(Integer id, Integer hid)
			throws Exception {
		// TODO Auto-generated method stub
		return sprintItemsDao.findBySprintidnadHid(id, hid);
	}

	@Override
	public List<SprintSummary> getSprintSummary(LocalDate startDate,
			LocalDate endDate, String createdby) throws Exception {
		// TODO Auto-generated method stub
		return sprintItemsDao.getSprintSummary(startDate, endDate, createdby);
	}

	@Override
	public List<SprintSummary> getSprintSummaryByIds(String connectorIds)
			throws Exception {
		// TODO Auto-generated method stub
		return sprintItemsDao.getSprintSummaryByIds(connectorIds);
	}

	@Override
	public List<SprintSummary> getSprintSummary(Integer sprintId)
			throws Exception {
		return sprintItemsDao.getSprintSummary(sprintId);
	}
}
