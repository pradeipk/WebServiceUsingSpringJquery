package com.psl.sprint.service;

import com.psl.sprint.model.SprintItemStatus;

public interface SprintItemStatusService extends GenericService {
	public SprintItemStatus findBySprintItemId(Integer sprintItemId) throws Exception;
}
