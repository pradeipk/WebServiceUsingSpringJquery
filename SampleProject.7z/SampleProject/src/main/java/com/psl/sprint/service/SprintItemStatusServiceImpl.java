package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.SprintItemStatusDao;
import com.psl.sprint.model.SprintItemStatus;

@Service("sprintItemStatusService")
@Transactional(rollbackFor = Exception.class)
public class SprintItemStatusServiceImpl implements SprintItemStatusService {

	@Autowired
	private SprintItemStatusDao sprintItemStatusDao;
	
	@Override
	public Object findById(Integer id) throws Exception {
		return sprintItemStatusDao.findById(id);
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		sprintItemStatusDao.saveEntity(object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		sprintItemStatusDao.updateEntity(object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		sprintItemStatusDao.deleteEntity(object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SprintItemStatus findBySprintItemId(Integer sprintItemId)
			throws Exception {
		return sprintItemStatusDao.findBySprintItemId(sprintItemId);
	}

}
