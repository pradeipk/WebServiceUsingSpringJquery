package com.psl.sprint.service;

import java.util.List;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.SprintMasterDao;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.SprintMaster;
import com.psl.sprint.model.SprintSummary;

@Service("sprintMasterService")
@Transactional(rollbackFor = Exception.class)
public class SprintMasterServiceImpl implements SprintMasterService {

	@Autowired
	private SprintMasterDao sprintMasterDao;

	@Override
	public Object findById(Integer id) throws Exception {
		return sprintMasterDao.findById(id);
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		sprintMasterDao.saveEntity(object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		sprintMasterDao.updateEntity(object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		sprintMasterDao.deleteEntity(object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SprintMaster> findByConnectorMasterId(Integer connectorMasterId)
			throws Exception {
		return sprintMasterDao.findByConnectorMasterId(connectorMasterId);
	}

	@Override
	public SprintMaster findByStartDateEndDateAndConnectorId(String startDate,
			String endDate, Integer connectorId) throws Exception {
		return sprintMasterDao.findByStartDateEndDateAndConnectorId(startDate,
				endDate, connectorId);
	}

	@Override
	public List<Object[]> getSprintrecource(String ids) throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getSprintrecource(ids);
	}

	@Override
	public SprintMaster findBynonForzenById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.findBynonForzenById(id);
	}

	@Override
	public int saveSprintMasterRecords(SprintMaster sprintMasterRow)
			throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.saveSprintMasterRecords(sprintMasterRow);
	}

	@Override
	public void deleteMapping(Integer id) throws Exception {
		// TODO Auto-generated method stub
		sprintMasterDao.deleteMapping(id);
	}

	@Override
	public List<SprintMaster> getFrozenedSprint() throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getFrozenedSprint();
	}

	@Override
	public List<Object[]> getReportForAlertUser(LocalDate startDate,
			LocalDate endDate) throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getReportForAlertUser(startDate, endDate);
	}

	@Override
	public List<SprintMaster> getNonFrozenSprints(LocalDate today)
			throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getNonFrozenSprints(today);
	}

	@Override
	public List<SprintMaster> findByStartDateEndDateAndowner(
			LocalDate startDate, LocalDate endDate, Integer[] ids)
			throws Exception {
		return sprintMasterDao.findByStartDateEndDateAndConnectorId(startDate,
				endDate, ids);

	}

	@Override
	public List<SprintSummary> getFrozenedSprintbyIds(String ids)
			throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getFrozenedSprintbyIds(ids);
	}

	@Override
	public List<SprintSummary> getallfrozonedSprintsbyGroup() throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getallfrozonedSprintsbyGroup();
	}

	@Override
	public List<SprintMaster> getExistingSprintsForUser(Integer resourceId,
			Integer isfreezed) throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getExistingSprintsForUser(resourceId, isfreezed);
	}

	@Override
	public SprintMaster getLastSprintDateForUser(Integer resourceId,
			int isfreezed, boolean isEndate) throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getLastSprintDateForUser(resourceId, isfreezed,
				isEndate);
	}

	@Override
	public List<SprintMaster> getMasterSprintsforUser(Integer creadedBy,
			int isfrozen, int rowLimit) throws Exception {
		// TODO Auto-generated method stub
		return sprintMasterDao.getMasterSprintsforUser(creadedBy, isfrozen,
				rowLimit);

	}
}
