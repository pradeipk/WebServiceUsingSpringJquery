package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.StoryPointsEstimationMaster;

public interface StoryPointsEstimationMasterService  extends GenericService {
	public List<StoryPointsEstimationMaster> findByVersionAndType(String version, String connectorType) throws Exception;
}
