package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.StoryPointsEstimationMasterDao;
import com.psl.sprint.model.StoryPointsEstimationMaster;

@Service("storyPointsEstimationMasterService")
@Transactional(rollbackFor = Exception.class)
public class StoryPointsEstimationMasterServiceImpl implements
		StoryPointsEstimationMasterService {

	@Autowired
	private StoryPointsEstimationMasterDao storyPointsEstimationMasterDao;
	
	@Override
	public Object findById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object findByName(Object object) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<StoryPointsEstimationMaster> findByVersionAndType(String version, String connectorType)
			throws Exception {
		return storyPointsEstimationMasterDao.findByVersionAndType(version, connectorType);
	}

}
