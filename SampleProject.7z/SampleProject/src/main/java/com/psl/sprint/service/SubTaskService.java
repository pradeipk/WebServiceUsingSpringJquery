package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.Subtask;

public interface SubTaskService {

	public Subtask findById(int id) throws Exception;

	public void saveSubtask(Subtask subtask) throws Exception;

	public void updateSubtask(Subtask subtask) throws Exception;

	public void deleteSubtask(Integer id) throws Exception;

	public List<Subtask> findAllSubtask() throws Exception;

	public Subtask findSubtaskByConnectorName(String ssn) throws Exception;

	public Subtask findByName(String subtask) throws Exception;

}
