package com.psl.sprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.SubTaskDao;
import com.psl.sprint.model.Subtask;

@Service("stroyPointService")
@Transactional
public class SubTaskServiceImpl implements SubTaskService {

	@Autowired
	private SubTaskDao dao;

	public Subtask findById(int id) throws Exception {
		return dao.findById(id);
	}

	public void saveSubtask(Subtask subtask) throws Exception {

		dao.saveSubtask(subtask);
	}

	public void updateSubtask(Subtask subtask) throws Exception {
		dao.updateSubtask(subtask);
	}

	public void deleteSubtask(Integer id) throws Exception {
		dao.deleteSubtask(id);
	}

	public List<Subtask> findAllSubtask() throws Exception {
		return dao.findAllSubtask();
	}

	public Subtask findSubtaskByConnectorName(String ssn) {
		return null;
	}

	@Override
	public Subtask findByName(String subtask) throws Exception {
		return dao.findByName(subtask);
		
	}
	
	
}
