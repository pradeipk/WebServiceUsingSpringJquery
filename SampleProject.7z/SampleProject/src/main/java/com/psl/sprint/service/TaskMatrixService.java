package com.psl.sprint.service;

import java.util.List;

import com.psl.sprint.model.TaskMatrix;

public interface TaskMatrixService {

	public TaskMatrix findById(int id) throws Exception;

	public void saveSubtaskMatrix(TaskMatrix subtask) throws Exception;

	public void updateSubtaskMatrix(TaskMatrix subtask) throws Exception;

	public void deleteSubtaskMatrix(Integer id) throws Exception;

	public List<TaskMatrix> findAllSubtaskMatrix() throws Exception;

	public TaskMatrix findSubtaskByRequirementIDAndTaskID(Integer requirementId, Integer taskId) throws Exception;

}
