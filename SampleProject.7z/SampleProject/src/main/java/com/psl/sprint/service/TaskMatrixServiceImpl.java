package com.psl.sprint.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.psl.sprint.dao.TaskMatrixDao;
import com.psl.sprint.model.TaskMatrix;

@Service("taskMatrixServiceImpl")
@Transactional(rollbackOn=Exception.class)
public class TaskMatrixServiceImpl implements TaskMatrixService{

	@Autowired
	private TaskMatrixDao matrixDao;
	
	@Override
	public TaskMatrix findById(int id) throws Exception {
		return matrixDao.findById(id);
	}

	@Override
	public void saveSubtaskMatrix(TaskMatrix subtask) throws Exception {
		matrixDao.saveSubtaskMatrix(subtask);
	}

	@Override
	public void updateSubtaskMatrix(TaskMatrix subtask) throws Exception {
		
	}

	@Override
	public void deleteSubtaskMatrix(Integer id) throws Exception {
		
	}

	@Override
	public List<TaskMatrix> findAllSubtaskMatrix() throws Exception {
		return null;
	}

	@Override
	public TaskMatrix findSubtaskByRequirementIDAndTaskID(Integer requirementId, Integer taskId) throws Exception {
		return matrixDao.findSubtaskByRequirementIDAndTaskID(requirementId, taskId);
	}

	

}
