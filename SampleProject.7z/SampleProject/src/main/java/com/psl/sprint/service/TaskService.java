package com.psl.sprint.service;

import java.util.List;

import org.joda.time.LocalDate;

import com.psl.sprint.model.Task;
import com.psl.sprint.model.TaskEffortsByConnector;
import com.psl.sprint.model.TaskEffortsByConnectorAndPhase;

public interface TaskService extends GenericService {

	public abstract List<TaskEffortsByConnectorAndPhase> getEffortsByConnectorAndPhase(
			Integer connectorId, String phase) throws Exception;

	public abstract List<Task> getEffortsForAllConnectors(String job)
			throws Exception;

	public abstract List<Task> getEffortsByConnector(Integer connectorId,
			String job) throws Exception;

	public List<TaskEffortsByConnector> getEffortsByDateAndOrConnector(
			String startDate, String endDate, Integer connectorId,
			Integer resourceId) throws Exception;

	public List<TaskEffortsByConnector> getEffortsByDateAndPhase(
			String startDate, String endDate, String phaseName,
			String monthYear, String comparisonType) throws Exception;

	public Object getEffortsByConnectorIdAndDate(Integer connectorIds,
			String startDate, String endDate) throws Exception;

	public abstract List<Task> findByidAndDate(Integer subresourceId,
			LocalDate toDate, LocalDate fromDate) throws Exception;

}