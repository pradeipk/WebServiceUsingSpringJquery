package com.psl.sprint.service;

import java.util.List;

import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.TaskDao;
import com.psl.sprint.model.Task;
import com.psl.sprint.model.TaskEffortsByConnector;
import com.psl.sprint.model.TaskEffortsByConnectorAndPhase;
import com.psl.sprint.util.SprintConstants;

@Service("taskService")
@Transactional(rollbackFor = { Exception.class })
public class TaskServiceImpl extends SprintConstants implements TaskService {

	@Autowired
	private TaskDao taskDao;

	@Override
	public Object findById(Integer id) throws Exception {
		return taskDao.findById(id);
	}

	@Override
	public Object findByName(Object object) throws Exception {
		return taskDao.findByName(object);
	}

	@Override
	public void saveEntity(Object object) throws Exception {
		taskDao.saveEntity(object);
	}

	@Override
	public void updateEntity(Object object) throws Exception {
		taskDao.updateEntity(object);
	}

	@Override
	public void deleteEntity(Object object) throws Exception {
		taskDao.deleteEntity(object);
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TaskEffortsByConnectorAndPhase> getEffortsByConnectorAndPhase(
			Integer connectorId, String phase) throws Exception {
		return taskDao.getEffortsByConnectorAndPhase(connectorId, phase);
	}

	@Override
	public List<Task> getEffortsForAllConnectors(String job) throws Exception {
		return taskDao.getEffortsForAllConnectors(job);
	}

	@Override
	public List<Task> getEffortsByConnector(Integer connectorId, String job)
			throws Exception {
		return taskDao.getEffortsByConnector(connectorId, job);
	}

	@Override
	public List<TaskEffortsByConnector> getEffortsByDateAndOrConnector(
			String startDate, String endDate, Integer connectorId,
			Integer resourceId) throws Exception {
		return taskDao.getEffortsByDateAndOrConnector(startDate, endDate,
				connectorId, resourceId);
	}

	@Override
	public List<TaskEffortsByConnector> getEffortsByDateAndPhase(
			String startDate, String endDate, String phaseName,
			String monthYear, String comparisonType) throws Exception {
		return taskDao.getEffortsByDateAndPhase(startDate, endDate, phaseName,
				monthYear, comparisonType);
	}

	@Override
	public Object getEffortsByConnectorIdAndDate(Integer connectorIds,
			String startDate, String endDate) throws Exception {
		return taskDao.getEffortsByConnectorIdAndDate(connectorIds, startDate,
				endDate);
	}

	@Override
	public List<Task> findByidAndDate(Integer subresourceId, LocalDate toDate,
			LocalDate fromDate) throws Exception {
		// TODO Auto-generated method stub
		return taskDao.findByidAndDate(subresourceId, toDate, fromDate);
	}
}
