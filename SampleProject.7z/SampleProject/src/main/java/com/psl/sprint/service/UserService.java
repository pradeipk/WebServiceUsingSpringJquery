package com.psl.sprint.service;

import java.util.List;

import org.joda.time.LocalDate;

import com.psl.sprint.dto.ResourceDTO;
import com.psl.sprint.dto.ResourceWrapper;
import com.psl.sprint.model.AllocationDTO;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;

public interface UserService extends GenericService {

	public void updateUsers(ResourceWrapper resources) throws Exception;

	public List<AllocationDTO> findUserWithAllocations(Integer id)
			throws Exception;

	public List<AllocationDTO> findUserWithAllocationsForSpecificDateRange(
			LocalDate startDate, LocalDate endDate) throws Exception;

	public void updateUserWithAllocation(Resource resource) throws Exception;

	public List<ResourceDTO> getAllResourceNames() throws Exception;

	public void updateUserWithModifiedAllocation(ResourceAllocationLog log)
			throws Exception;

	public List<?> findAll(boolean edit, Integer rmID) throws Exception;

	public Resource findByIP(String hostname) throws Exception;

	public List<Resource> findAllLeadsAndDuals() throws Exception;

	public Resource findResourceByID(Integer id) throws Exception;

	public List<Resource> findResourcesBYRmId(Integer id) throws Exception;
}
