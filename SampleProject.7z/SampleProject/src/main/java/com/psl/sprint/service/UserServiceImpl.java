package com.psl.sprint.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.sprint.dao.ConnectorDao;
import com.psl.sprint.dao.ResourceAllocationReportDao;
import com.psl.sprint.dao.UserDao;
import com.psl.sprint.dao.UserRoleDao;
import com.psl.sprint.dto.ResourceDTO;
import com.psl.sprint.dto.ResourceWrapper;
import com.psl.sprint.exception.MandatoryFieldMissingException;
import com.psl.sprint.exception.MultipleRecordExists;
import com.psl.sprint.exception.RecordAllReadyExistsException;
import com.psl.sprint.model.AccessLevel;
import com.psl.sprint.model.AllocationDTO;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.Resource;
import com.psl.sprint.model.ResourceAllocationLog;
import com.psl.sprint.util.SprintConstants;

@Service("userService")
@Transactional(rollbackFor = { Exception.class })
public class UserServiceImpl extends SprintConstants implements UserService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private ConnectorDao connectorDao;

	@Autowired
	private UserRoleDao roleDao;

	@Autowired
	private ResourceAllocationReportDao reportDao;

	@Override
	public Object findByName(Object object) throws Exception {
		return userDao.findByName(object);
	}

	/**
	 * 
	 * */
	@Override
	@SuppressWarnings("unused")
	public void saveEntity(Object resourceDTO) throws Exception,
			RecordAllReadyExistsException {
		try {
			Resource resource_new = new Resource((ResourceDTO) resourceDTO);
			// check if user exists
			if (userDao.findByName(resource_new.getUserName()).size() >= 1) {
				throw new RecordAllReadyExistsException(
						RESOURCE_ALL_READY_EXISTS);
			}
			resource_new.setPassword((resource_new.getFirstName())
					.toLowerCase() + 123);
			resource_new.setCreatedDate(new DateTime());
			resource_new.setCreatedBy((String) SecurityContextHolder
					.getContext().getAuthentication().getPrincipal());
			resource_new.setUpdatedDate(new DateTime());
			resource_new.setUpdatedBy((String) SecurityContextHolder
					.getContext().getAuthentication().getPrincipal());
			resource_new.setReleaseDate(new LocalDate(2016, 12, 31));
			// when the resource is created do not associate any connector with
			// it .
			userDao.saveEntity(resource_new);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/**
	 * 
	 * */
	@Override
	public void updateEntity(Object object) throws Exception {
		try {
			boolean user_name_matches = true;
			ResourceDTO dto = (ResourceDTO) object;
			Integer resource_id = dto.getResourceId();
			Resource resource_old = (Resource) userDao.findById(resource_id);

			if (!resource_old.getFirstName().equalsIgnoreCase(
					dto.getFirstName())
					|| !resource_old.getLastName().equalsIgnoreCase(
							dto.getLastName())) {

				throw new Exception(
						"First Name and Last name can not be changed");
			}

			Integer intial_connector_id = 1;// resource_old.getConnector().getId();

			String initialUserName = resource_old.getUserName();
			resource_old.setFirstName(dto.getFirstName());
			resource_old.setLastName(dto.getLastName());
			resource_old.setJobAssigned(dto.getJobAssigned());
			resource_old.setUserName((dto.getFirstName() + "_" + dto
					.getLastName()).toLowerCase());

			resource_old.setUpdatedDate(new DateTime());
			resource_old.setUpdatedBy((String) SecurityContextHolder
					.getContext().getAuthentication().getPrincipal());
			resource_old.setReleaseDate(dto.getReleaseDate());
			// check if user name is has been changed,if it is then match fails
			if (!resource_old.getUserName().equalsIgnoreCase(initialUserName)) {
				user_name_matches = false;
			}

			List<Resource> resources = (List<Resource>) userDao
					.findByName(resource_old.getUserName());
			// user name has been changed and it found a match as well ,oh !
			// then its a problem let
			// us make end user know this
			if (!resources.isEmpty() && !user_name_matches) {

				throw new RecordAllReadyExistsException(
						RESOURCE_ALL_READY_EXISTS);
			}

			resource_old.getAccessLevels().clear();

			AccessLevel accessLevel = null;
			Set<AccessLevel> accessLevelList = new HashSet<AccessLevel>();
			Set<String> accessLevels = ((ResourceDTO) object).getAccessLevels();
			if (accessLevels != null) {
				for (String level : accessLevels) {
					accessLevel = new AccessLevel();
					accessLevel.setUserName(resource_old.getUserName());
					accessLevel.setAccessLevel(level);
					accessLevelList.add(accessLevel);

				}
			}

			// update the resource
			resource_old.setAccessLevels(accessLevelList);
			userDao.updateEntity(resource_old);

			// update the connector ,in some case connectors are not applicable
			// to resource, i.e
			// managers own multiple connectors
			List<Connector> connectors = connectorDao
					.findAllByConnectorName(dto.getConnectorAssigned());
			Set<Resource> resources0 = null;
			if (!connectors.isEmpty()) {
				Connector connector = connectors.get(0);
				if (connectors.size() > 1) {
					throw new MultipleRecordExists(
							"Multiple connectors exists with name");
				}

				resources0 = connector.getResources();
				if (resources0 == null) {
					resources0 = new HashSet<Resource>();
				}
				resources.add((Resource) userDao.findById(resource_old
						.getResourceId()));
				connector.setResources(resources0);
				connectorDao.updateConnector(connector);
				// release a resource from connector
			} else if (Arrays.asList(release).contains(
					dto.getConnectorAssigned())) {
				Connector connector = connectorDao
						.findById(intial_connector_id);
				resources0 = connector.getResources();
				for (Resource resource : resources0) {
					if (resource_id.equals(resource.getResourceId())) {
						resources0.remove(resource);
						connector.setResources(resources0);
						connectorDao.updateConnector(connector);
						break;
					}
				}

			}
			roleDao.deleteNonReferencedRoles();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * 
	 * */
	@Override
	public void deleteEntity(Object object) throws Exception {

	}

	/**
	 * 
	 * */
	@Override
	@SuppressWarnings("unchecked")
	public List<?> findAll(boolean edit, Integer rmID) throws Exception {
		ResourceDTO dto = null;
		List<ResourceDTO> resourcesdtos = new ArrayList<ResourceDTO>();
		List<Resource> resources;
		resources = (List<Resource>) userDao.findAll(edit, rmID);

		for (Resource resource : resources) {
			Set<String> levels = new HashSet<String>();
			for (AccessLevel accessLevel : resource.getAccessLevels()) {
				levels.add(accessLevel.getAccessLevel());
			}
			if (levels.isEmpty()) {
				levels.add("Minimum");
			}
			dto = new ResourceDTO();
			dto.setFirstName(resource.getFirstName());
			dto.setLastName(resource.getLastName());
			dto.setName(resource.getFirstName() + " " + resource.getLastName());
			dto.setJobAssigned(resource.getJobAssigned());
			dto.setAccessLevels(levels);
			dto.setResourceId(resource.getResourceId());
			dto.setReleaseDate(resource.getReleaseDate());
			Set<Connector> connectors = resource.getConnector();
			String connector_name = null;
			for (Connector connector0 : connectors) {
				if (connector_name == null) {
					connector_name = connector0.getName();
				} else {
					connector_name += ",";
					connector_name += connector0.getName();
				}
			}

			if (connector_name != null) {
				dto.setConnectorAssigned(connector_name);
			} else {
				dto.setConnectorAssigned(CONNECTOR_NOT_ASSIGNED);
			}
			resourcesdtos.add(dto);
		}
		// Collections.sort(resourcesdtos);
		return resourcesdtos;

	}

	/**
	 * While updating user update the user log table
	 * */

	@Override
	public void updateUsers(ResourceWrapper resources) throws Exception {
		try {
			Connector connector = connectorDao.findAllByConnectorName(
					resources.getConnector()).get(0);
			Set<Resource> existing_resources = connector.getResources();
			Resource existing_resource = null;
			ResourceAllocationLog allocation_log = new ResourceAllocationLog();
			for (ResourceDTO resource : resources.getResourceDTOs()) {
				if (resource.getFirstName() != null) {
					existing_resource = (Resource) userDao.findById(resource
							.getResourceId());
					/*
					 * existing_resource.setCurrent_allocation_level(
					 * existing_resource. getCurrent_allocation_level() +
					 * resource.getNew_allocations());
					 */
					allocation_log.setConnectorId(connector.getId());
					allocation_log.setConnectorName(connector.getName());
					allocation_log.setCreatedDate(new DateTime());
					allocation_log.setCreatedBy((String) SecurityContextHolder
							.getContext().getAuthentication().getPrincipal());
					allocation_log.setUpdatedDate(new DateTime());
					allocation_log.setUpdatedBy((String) SecurityContextHolder
							.getContext().getAuthentication().getPrincipal());
					allocation_log.setStartDate(resource.getStartDate());
					allocation_log.setEndDate(resource.getEndDate());
					allocation_log.setBandwidthShare(resource
							.getNew_allocations());
					existing_resource.getResourceAllocationList().add(
							allocation_log);
					existing_resources.add(existing_resource);
				}
			}
			connector.setResources(existing_resources);
			connectorDao.updateConnector(connector);
		} catch (Exception e) {
			throw new Exception(
					"Something went wrong while adding resources to connector-"
							+ resources.getConnector());
		}
	}

	@Override
	public List<AllocationDTO> findUserWithAllocations(Integer id)
			throws Exception {
		AllocationDTO allocationDTO = new AllocationDTO();
		List<AllocationDTO> allocations_for_a_resource = new ArrayList<AllocationDTO>();
		Resource resource = (Resource) userDao.findById(id);
		// pull all allocation log for a resource for all connector
		for (ResourceAllocationLog allocations : resource
				.getResourceAllocationList()) {
			allocationDTO.setConnector_name(allocations.getConnectorName());
			allocationDTO.setStartDate(allocations.getStartDate());
			allocationDTO.setEndDate(allocations.getEndDate());
			allocationDTO.setAllocation_share(allocations.getBandwidthShare());
			allocationDTO.setResourceName(resource.getFirstName());
			allocations_for_a_resource.add(allocationDTO);
		}
		return allocations_for_a_resource;

	}

	@Override
	public List<AllocationDTO> findUserWithAllocationsForSpecificDateRange(
			LocalDate startDate, LocalDate endDate) throws Exception {

		List<Resource> resources = (List<Resource>) userDao.findAll();
		// Filter Resources
		List<ResourceAllocationLog> log = null;
		for (Resource resource : resources) {
			log = resource.getResourceAllocationList();

			filterResource(log, startDate, endDate);

		}

		return null;
	}

	private void filterResource(List<ResourceAllocationLog> log,
			LocalDate startDate, LocalDate endDate) {

		// count all allocations within range

		for (ResourceAllocationLog resourceAllocationLog : log) {

			resourceAllocationLog.getBandwidthShare();
		}

	}

	/**
	 * Updating Resource will take care of its log , after updating resource
	 * update connector it will create new entry in connector_resource table
	 * 
	 */

	@Override
	public void updateUserWithAllocation(Resource resource) throws Exception {
		try {

			if (resource == null
					|| resource.getResourceAllocationList() == null
					|| resource.getResourceAllocationList().isEmpty()) {
				throw new MandatoryFieldMissingException(
						"Not a valid record to insert");
			}

			Resource resource_existing = (Resource) userDao.findById(resource
					.getResourceId());
			Integer connector_id = resource.getResourceAllocationList().get(0)
					.getConnectorId();
			resource_existing.getResourceAllocationList().add(
					resource.getResourceAllocationList().get(0));
			userDao.updateEntity(resource_existing);
			Resource updated_resource = (Resource) userDao
					.findById(resource_existing.getResourceId());
			Connector connector = connectorDao.findById(connector_id);
			connector.getResources().add(updated_resource);
			connectorDao.updateConnector(connector);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.psl.sprint.service.UserService#updateUserWithModifiedAllocation(com
	 * .psl.sprint.model. Resource) Modifiying allocation , allocation should
	 * exist, check for an id
	 */
	@Override
	public void updateUserWithModifiedAllocation(ResourceAllocationLog log)
			throws Exception {
		try {

			if (log == null || log.getConnectorId() == null
					|| log.getStartDate() == null || log.getEndDate() == null) {
				throw new MandatoryFieldMissingException(
						"Not a valid record to insert");
			}

			ResourceAllocationLog existing_log = reportDao.findById(log
					.getAllocationId());
			if (!existing_log.getConnectorId().equals(log.getConnectorId())
					|| !existing_log.getResource().getResourceId()
							.equals(log.getResource().getResourceId())) {
				throw new MandatoryFieldMissingException(
						"DataMismatch: Allocation history data mismatch while you modify it");
			}

			// minima of its own allocation Plus Overall Availablity;
			// Double min =
			// reportDao.findMinimaOfAllAllocationsForAResourceForAConnectorForADateRange(existing_log.getConnectorName(),
			// existing_log.getResource().getResourceId(),
			// log.getStartDate().toString(),
			// log.getEndDate().toString());
			// find Total Availibilty say t;
			// t+min;
			// log.getAllocationSahre <= t+min;

			existing_log.setStartDate(log.getStartDate());
			existing_log.setEndDate(log.getEndDate());
			existing_log.setUpdatedDate(new DateTime());
			existing_log.setDescription(log.getDescription());
			existing_log.setUpdatedBy((String) SecurityContextHolder
					.getContext().getAuthentication().getPrincipal());

			if (log.getBandwidthShare() > 1) {
				existing_log.setBandwidthShare(log.getBandwidthShare() / 100.0);
			} else {
				existing_log.setBandwidthShare(log.getBandwidthShare());
			}

			Resource resource_existing = (Resource) userDao
					.findById(existing_log.getResource().getResourceId());
			/*
			 * while updating the logs if it if 0.0 remove that log
			 */
			if (existing_log.getBandwidthShare().equals(0.0d)) {
				resource_existing.getResourceAllocationList().remove(
						existing_log);
			} else {
				resource_existing.getResourceAllocationList().add(existing_log);
			}

			userDao.updateEntity(resource_existing);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Override
	public List<ResourceDTO> getAllResourceNames() throws Exception {
		List<ResourceDTO> resourceList = userDao.getAllResources();
		return resourceList;
	}

	@Override
	public List<?> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object findById(Integer id) throws Exception {
		ResourceDTO dto = new ResourceDTO((Resource) userDao.findById(id));

		return dto;
	}

	@Override
	public Resource findByIP(String hostname) throws Exception {
		return userDao.findByIP(hostname);
	}

	@Override
	public List<Resource> findAllLeadsAndDuals() throws Exception {
		return userDao.findAllLeadsAndDualLeads();
	}

	@Override
	public Resource findResourceByID(Integer id) throws Exception {

		return userDao.findResourceById(id);
	}

	@Override
	public List<Resource> findResourcesBYRmId(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return userDao.findResourcesBYRmId(id);
	}
}
