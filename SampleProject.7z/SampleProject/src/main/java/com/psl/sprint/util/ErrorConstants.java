package com.psl.sprint.util;

public interface ErrorConstants {
	
	public static final String MANDATORY_FIELD_MISSING_ERROR = "Some mandatory fields were missing:";
	public static final String RESOURCE_ALL_READY_EXISTS = "Resource with this name already exists:";
	public static final String RECORD_DOES_NOT_EXISTS = "Record for specifed query does not exists";
	public static final String MULTIPLE_RECORD_EXISTS = "More than one record exists for this query";
}
