package com.psl.sprint.util;

import java.text.DateFormatSymbols;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.psl.sprint.dto.ReportDTO;

public class ExcelBuilder extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		response.setContentType("application/vnd.ms-excel");
		response.setHeader("Content-Disposition",
				"attachment;filename=resource-allocation-report.xls");

		HSSFCellStyle hollidayCellStyle = getHSSFCellStyleForHolliday(workbook);
		HSSFCellStyle workingDayCellStyle = getHSSFCellStyleForWorkingDay(workbook);

		// get data model which is passed by the Spring container
		@SuppressWarnings("unchecked")
		HashMap<String, Object> resourceAllocationReportMap = (HashMap<String, Object>) model
				.get("resourceAllocationReport");

		for (Map.Entry<String, Object> entry : resourceAllocationReportMap
				.entrySet()) {
			String monthReportKey = entry.getKey();

			Map<String, List<ReportDTO>> resourceDataMap = (HashMap<String, List<ReportDTO>>) entry
					.getValue();

			// create a new Excel sheet

			String monthString = new DateFormatSymbols().getMonths()[Integer
					.parseInt(monthReportKey.split("/")[0]) - 1];

			HSSFSheet sheet = workbook.createSheet(monthString + "-"
					+ monthReportKey.split("/")[1]);

			int rowIndex = 0;
			for (Map.Entry<String, List<ReportDTO>> resourceWiseData : resourceDataMap
					.entrySet()) {
				String resourceName = resourceWiseData.getKey();
				List<ReportDTO> reportDTOList = (List<ReportDTO>) resourceWiseData
						.getValue();

				if (rowIndex == 0) {
					HSSFRow header = sheet.createRow(rowIndex);
					HSSFCell headerCell = header.createCell((short) 0);
					headerCell.setCellValue("");
					headerCell.setCellStyle(workingDayCellStyle);
					for (int i = 0; i < reportDTOList.size(); i++) {
						String day[] = reportDTOList.get(i).getWorkdate().split("-");
						HSSFCell hssfCell = header.createCell((short) (i + 1));
						hssfCell.setCellStyle(workingDayCellStyle);
						hssfCell.setCellValue(day[1] + "-" + day[2]);
					}
					rowIndex++;
				}

				HSSFRow aRow = sheet.createRow(rowIndex++);
				HSSFCell resourceNameCell = aRow.createCell((short) 0);
				resourceNameCell.setCellStyle(workingDayCellStyle);
				resourceNameCell.setCellValue(resourceName);

				for (int i = 0; i < reportDTOList.size(); i++) {
					ReportDTO reportDTO = reportDTOList.get(i);

					HSSFCell hssfCell = aRow.createCell((short) (i + 1));

						hssfCell.setCellStyle(workingDayCellStyle);
						hssfCell.setCellValue(reportDTOList.get(i)
								.getConnector());
					
				}
			}
		}
	}

	private HSSFCellStyle getHSSFCellStyleForHolliday(HSSFWorkbook workbook) {
		HSSFCellStyle style = workbook.createCellStyle();
		style.setFillForegroundColor(HSSFColor.LIME.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		return style;
	}

	private HSSFCellStyle getHSSFCellStyleForWorkingDay(HSSFWorkbook workbook) {
		HSSFCellStyle style = workbook.createCellStyle();
		style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		style.setBorderTop(HSSFCellStyle.BORDER_THIN);
		style.setBorderRight(HSSFCellStyle.BORDER_THIN);
		style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		return style;
	}

}