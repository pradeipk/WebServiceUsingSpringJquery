package com.psl.sprint.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.joda.time.LocalDate;
import org.springframework.beans.BeanUtils;

import com.psl.sprint.dto.ReportDTO;
import com.psl.sprint.model.Connector;
import com.psl.sprint.model.FunctionalRequrement;
import com.psl.sprint.model.Subtask;

public class GeneralUtility {

	public static List<String> listAllConnectors(List<Connector> connectors,Map<String, Integer> connmap) {

		List<String> connectorsList = new ArrayList<String>();

		for (Connector connector : connectors) {
			connectorsList.add(connector.getName());
			connmap.put(connector.getName(), connector.getId());
		}
		return connectorsList;
	}

	public static List<String> listAllRequirements(
			List<FunctionalRequrement> requrements,Map<String, Integer> reqmap) {
		
		List<String> requrementsList = new ArrayList<String>();
		String req = null;
		for (FunctionalRequrement requrement : requrements) {
			 req = requrement.getRequirement();
			requrementsList.add(req);
			reqmap.put(req, requrement.getId());
		}
		return requrementsList;
	}
	
	public static List<String> listAllTask(
			List<Subtask> subtasks ,Map<String, Integer> taskmap) {
		
		List<String> taskList = new ArrayList<String>();
		String req = null;
		for (Subtask task : subtasks) {
			 req = task.getSubtask();
			 taskList.add(req);
			taskmap.put(req, task.getTaskId());
		}
		return taskList;
	}

	// month : 1-12
	public static String getLastDayOfMonth(int month, int year) {
	    LocalDate lastDayOfMonth = new LocalDate(year, month, 1).dayOfMonth().withMaximumValue();
	    return lastDayOfMonth.toString("yyyy-MM-dd");
	}
	
	public static String getNextDate(String curDate) {
        String nextDate = "";
        try {
            Calendar today = Calendar.getInstance();
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Date date = format.parse(curDate);
            today.setTime(date);
            today.add(Calendar.DAY_OF_YEAR, 1);
            nextDate = format.format(today.getTime());
        } catch (Exception e) {
            return nextDate;
        }
        return nextDate;
    }

	public static List<ReportDTO> addAllocationRow(List<ReportDTO> resourceAllocationGroupData,String type) {


		List<ReportDTO> reportDTOList = new ArrayList<ReportDTO>();
		
		ReportDTO prevReportDTO = null;
		ReportDTO newRowReportDTO = null;
		for (Iterator iterator = resourceAllocationGroupData.iterator(); iterator.hasNext();) {
			
			ReportDTO reportDTO = (ReportDTO) iterator.next();
			
			
			if(reportDTOList.size()==0){
				prevReportDTO = reportDTO;
				reportDTOList.add(reportDTO);
			}else{
				if(type.equals("ALLOCATION") && prevReportDTO.getStartDate().equals(reportDTO.getStartDate()) && 
						prevReportDTO.getEndDate().equals(reportDTO.getEndDate())){
				
					if(newRowReportDTO == null){
						newRowReportDTO = new ReportDTO();
						BeanUtils.copyProperties(reportDTO, newRowReportDTO);
						newRowReportDTO.setConnector("Unallocated");
						
						newRowReportDTO.setBandwidthConcat(1-(Double.parseDouble(prevReportDTO.getBandwidthConcat())+Double.parseDouble(reportDTO.getBandwidthConcat()))+"");
					}else{
						
						newRowReportDTO.setBandwidthConcat(1-(Double.parseDouble(newRowReportDTO.getBandwidthConcat())+Double.parseDouble(reportDTO.getBandwidthConcat()))+"");
					}
					reportDTOList.add(reportDTO);
					
				}else if(type.equals("ALLOCATION") ){
					
					
					
					
				}else if(type.equals("UNALLOCATION") && prevReportDTO.getStartDate().equals(reportDTO.getStartDate()) 
						&& prevReportDTO.getEndDate().equals(reportDTO.getEndDate())
						&& prevReportDTO.getUserName().equals(reportDTO.getUserName())
						){
				
					if(newRowReportDTO == null){
						newRowReportDTO = new ReportDTO();
						BeanUtils.copyProperties(reportDTO, newRowReportDTO);
						newRowReportDTO.setConnector("Unallocated");
						newRowReportDTO.setBandwidthConcat(1-(Double.parseDouble(prevReportDTO.getBandwidthConcat())+Double.parseDouble(reportDTO.getBandwidthConcat()))+"");
					}else{
						
						newRowReportDTO.setBandwidthConcat(1-(Double.parseDouble(newRowReportDTO.getBandwidthConcat())+Double.parseDouble(reportDTO.getBandwidthConcat()))+"");
					}
					
					reportDTOList.add(reportDTO);
					
				}else{
					if(newRowReportDTO != null){
						ReportDTO reportDTO2 = new ReportDTO();
						BeanUtils.copyProperties(newRowReportDTO, reportDTO2);
						
						reportDTOList.add(reportDTO2);
						newRowReportDTO = null;
						
					}
					reportDTOList.add(reportDTO);			
				}
				
			}
		}
		return reportDTOList;
		
	}
}
