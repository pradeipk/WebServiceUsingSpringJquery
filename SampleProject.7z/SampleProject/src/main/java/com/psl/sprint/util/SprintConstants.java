package com.psl.sprint.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SprintConstants implements ErrorConstants {

	public static final String NILESH_HOST_IP = "10.222.242.26";
	public static final String NILESH_HOST_IP4 = "ngl05931.persistent.co.in";
	public static final String NILESH_HOST_IP6 = "fe80::25fe:9d4a:6fe:dc06%12";

	public static final String PRANAB_HOST = "127.0.0.1";
	public static final String PRANAB_HOST_IP = "10.222.244.88";
	public static final String PRANAB_HOST_IP4 = "ngl05157.persistent.co.in";
	public static final String PRANAB_HOST_IP6 = "0:0:0:0:0:0:0:1";

	public static final String BRAJMOHAN_HOST_IP = "10.222.242.83";
	public static final String BRAJMOHAN_HOST_IP4 = "ngl05155.persistent.co.in";
	public static final String BRAJMOHAN_HOST_IP6 = "fe80::e8cf:a113:e444:e25e%12";
	// public static final String BRAJMOHAN_HOST_IP4 = "0:0:0:0:0:0:0:1";

	public static final String DEEPALI_HOST_IP = "10.88.251.38";
	public static final String DEEPALI_HOST_IP4 = "ptl05731.persistent.co.in";
	public static final String DEEPALI_HOST_IP6 = "fe80::a196:3f4a:6222:1315%12";

	public static final String MAITHILI_HOST_IP = "10.222.78.40";
	public static final String MAITHILI_HOST_IP4 = "psngi3028.persistent.co.in";
	public static final String MAITHILI_HOST_IP6 = "fe80::f9e2:b269:ae33:8397%14";
	// public static final String DEEPALI_HOST="127.0.0.1";

	public static String HIGH = "High";
	public static String MEDIUM = "Medium";
	public static String LOW = "Low";
	public static String NA = "NA";

	public static String SPRINT_NOT_STARTED = "Sprint not started";
	public static String SPRINT_IN_PROGRESS = "Sprint in progress";
	public static String SPRINT_CLOSED = "Sprint closed";
	
	public static String[] reviewer = { "Vinod", "Adeline", "Pranab" };
	public static String[] reviewType = { "Peer Review", "Lead Review", "SME Review"};
	public final static String[] severity = {"Minor", "Major", "Cosmetic"};

	public static String ONE_TO_TWO = "1 TO 2";
	public static String THREE_TO_FIVE = "3 TO 5";
	public static String SIX_TO_EIGHT = "6 TO 8";
	public static String NINE_TO_ELEVEN = "9 TO 11";
	public static String TWELVE_TO_FIFTEEN = "12 TO 15";

	public static String ASSIGN_CONNECTOR_LATER = "~ Assign Later ~";
	public static String ASSIGNMENT_NOT_APPLICABLE = "~ Not Applicable ~";
	public static String RELEASE_FROM_ASSIGNMENT = "~ Release ~";
	public static String CONNECTOR_NOT_ASSIGNED = "~ None ~";

	public static String DEVELOPMENT = "Development";
	public static String TESTING = "Testing";
	public static String SME = "SME";
	public static String MANAGEMENT = "Management";

	public static String CYCLE_DEV = "Dev";
	public static String CYCLE_QA = "Qa";
	public static String CYCLE_OTHERS = "Others";
	public static Integer SPRINT_BASELINE = 120;
	public static Integer SPRINT_DURATION = 2;
	public static Integer MASTER_ACCESS_RES_ID_1 = 31; //Nilesh
	public static Integer MASTER_ACCESS_RES_ID_2 = 33; // Deepali
	// public static Integer MARGIN_TIME = 5;
	// public static Integer FREEZE_TIME_VAL = 5;
	public static String FREEZE_TIME = "freeze_time";

	public static Integer[] resource_assigned = { 1, 2, 3, 4, 5 };
	public static String[] sme = { "Vinod", "Adeline", "Pranab" };

	public static String[] lead = { "Brajmohan", "Deepali" };

	public static String[] release = { ASSIGN_CONNECTOR_LATER,
			ASSIGNMENT_NOT_APPLICABLE, RELEASE_FROM_ASSIGNMENT,
			CONNECTOR_NOT_ASSIGNED };
	public static String[] roles = { DEVELOPMENT, TESTING, SME, MANAGEMENT };
	public static String[] teamlead={"Brajmohan","Deepali","Bhavna","Sonia"};
	public static String[] accessLevel = { "ROLE_ADMIN", "ROLE_LEAD",
			"ROLE_DEV" };
	public static String[] status = { SPRINT_NOT_STARTED, SPRINT_IN_PROGRESS,
			SPRINT_CLOSED };
	public static String[] complexity = { HIGH, MEDIUM, LOW, NA };
	public static String[] featuresImpacted = { ONE_TO_TWO, THREE_TO_FIVE,
			SIX_TO_EIGHT, NINE_TO_ELEVEN, TWELVE_TO_FIFTEEN };
	public static String[] cycle = { CYCLE_DEV, CYCLE_QA, CYCLE_OTHERS };
	public static String OPEN = "Open";
	public static String CLOSE = "Close";
	public static String[] visibilty = { CLOSE, OPEN };

	public static Double[] d_25 = { 0.25 };
	public static Double[] d_50 = { 0.25, 0.50 };
	public static Double[] d_75 = { 0.25, 0.50, 0.75 };
	public static Double[] d_1 = { 0.25, 0.50, 0.75, 1.00 };

	public static Double[] d_0 = { 0.0 };

	public static Double[] d_250 = { 25.0 };
	public static Double[] d_500 = { 50.0, 25.0 };
	public static Double[] d_750 = { 75.0, 50.0, 25.0 };
	public static Double[] d_100 = { 100.0, 75.0, 50.0, 25.0 };

	public static Double[] d0_250 = { 25.0, 0.0 };
	public static Double[] d0_500 = { 50.0, 25.0, 0.0 };
	public static Double[] d0_750 = { 75.0, 50.0, 25.0, 0.0 };
	public static Double[] d0_100 = { 100.0, 75.0, 50.0, 25.0, 0.0 };

	public static Map<String, Integer> generalMap = new ConcurrentHashMap<String, Integer>();
	public static Map<Double, Double[]> allocation = new ConcurrentHashMap<Double, Double[]>();
	public static Map<Double, Double[]> allocation_for_edit = new ConcurrentHashMap<Double, Double[]>();

	/*
	 * public static final String[] PHASE_TYPE = { "Analysis",
	 * "High Level Design POC", "Development (Including UT)", "FVT Mocha",
	 * "FVT Postman", "On Boarding", "Integration Testing Mocha",
	 * "Integration Testing Postman", "Documentation", "Others" };
	 */

	public static final String[] PHASE_TYPE = { "Analysis",
			"High Level Design POC", "Prerequisite - Instance Configuration",
			"Development (Including UT)", "FVT Mocha", "On Boarding",
			"Integration Testing (Mocha) - TEST CASE CREATION",
			"Integration Testing (Mocha) - TEST CASE EXECUTION",
			"AppConnect Testing (After Connector On-Boarding)",
			"Documentation", "Others" };
	
	/*
	 * Issue status
	 */
	
	public static final String[] ISSUE_STATUS = { "Open", "Close", "Deferred"};

	public static final String[] EXCLUSION_TYPE = { "Leave", "Training",
			"Meeting" };

	public static final String[] EXCLUSION_PERCENTAGE = { "0.25", "0.50",
			"0.75", "1.00" };

	static {
		generalMap.put(HIGH, 3);
		generalMap.put(MEDIUM, 2);
		generalMap.put(LOW, 1);
		generalMap.put(NA, 1);

		generalMap.put(ONE_TO_TWO, 2);
		generalMap.put(THREE_TO_FIVE, 3);
		generalMap.put(SIX_TO_EIGHT, 5);
		generalMap.put(NINE_TO_ELEVEN, 8);
		generalMap.put(TWELVE_TO_FIFTEEN, 13);

		allocation.put(0.25, d_25);
		allocation.put(0.50, d_50);
		allocation.put(0.75, d_75);
		allocation.put(1.0, d_1);
		allocation.put(0.0, d_0);

		// allocate 100 means he has 4 option
		allocation.put(25.0, d_250);
		allocation.put(50.0, d_500);
		allocation.put(75.0, d_750);
		allocation.put(100.0, d_100);

		allocation_for_edit.put(25.0, d0_250);
		allocation_for_edit.put(50.0, d0_500);
		allocation_for_edit.put(75.0, d0_750);
		allocation_for_edit.put(100.0, d0_100);

	}

	/*
	 * Jira integration details
	 */
	public static final String JIRA_USERNAME = "pranab_bhatta";
	public static final String JIRA_PASSWORD = "pranab123";
	public static final String COMPONENT_GET_URL = "https://psljira.persistent.co.in/rest/api/2/project/ICI/components";
	public static final String RESOLUTION_GET_URL = "https://psljira.persistent.co.in/rest/api/2/search?";
	public static final String JQL_QUERY = "project = ICI AND issuetype in (Bug, Improvement) AND component = \"%s\" AND (resolution = Fixed OR resolution = \"Not a Bug\" OR resolution = Invalid OR resolution = Duplicate)";
	public static final String USER_AGENT = "SprintPlanner/1.0";
	public static final String JQL_QUERY_FOR_L3SUPPORT="component=L3_Support_Loopback";

	public static final String TEMPLATE_VERSION = "3.0";
	
	/*
	 * Initial PD's Constant;
	 */
	
	public static Map<String, Integer> INITALS_PDS = new ConcurrentHashMap<String, Integer>();
	
	static {
		INITALS_PDS.put("Action", 20);
		INITALS_PDS.put("Trigger", 5);
		INITALS_PDS.put("Webhooks", 5);
	}

}
