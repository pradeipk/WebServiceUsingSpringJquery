package com.psl.sprint.util;

import com.psl.sprint.model.FunctionalRequrement;
import com.psl.sprint.model.TaskMatrix;

public class SprintEngine extends SprintConstants {

	public Integer calculateStroyPoint(FunctionalRequrement functionalRequrement) {

		return null;
	}

	public static Integer calulateComplexityFactor(TaskMatrix matrix) {

		int cf = (generalMap.get(matrix.getImpact_on_feature())
				+ generalMap.get(matrix.getComplexity())
				+ generalMap.get(matrix.getImpact_on_performance())
				+ generalMap.get(matrix.getUncertainity()) + generalMap
				.get(matrix.getDependency())) / 5;
		return cf;

	}

	public static Integer calculateStoryPoint_bcf(TaskMatrix matrix) {
		return generalMap.get(matrix.getImpact_on_feature());
	}

	public static Integer calculateStoryPoint_acf(TaskMatrix matrix) {
		Integer sp = generalMap.get(matrix.getImpact_on_feature())
				* calulateComplexityFactor(matrix);
		return sp;
	}

	public static float standardStoryPointPerSprint(int resource,
			Integer sprintDuration) {
		Integer duration = null;
		if (resource == 0) {
			resource = 2;
		}
		if (sprintDuration == 0) {
			duration = SPRINT_DURATION;
		}
		float SSP_per_sprint = (SPRINT_BASELINE * resource) / duration;
		return SSP_per_sprint;

	}

	public static float calculateSprint(int aggregateStoryPoint, int resource,
			int sprintDuration) {

		return aggregateStoryPoint
				/ standardStoryPointPerSprint(resource, sprintDuration);
	}
}
