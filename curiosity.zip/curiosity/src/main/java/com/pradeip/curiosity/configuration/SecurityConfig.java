package com.pradeip.curiosity.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.JdbcUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	//@Autowired
	//private DataSource dataSource;

	// TO authenticate from Database
	/*
	 * @Autowired public void configAuthentication(AuthenticationManagerBuilder
	 * auth) throws Exception {
	 * 
	 * JdbcUserDetailsManagerConfigurer<AuthenticationManagerBuilder>
	 * authoritiesByUsernameQuery = auth .jdbcAuthentication()
	 * .dataSource(dataSource) .usersByUsernameQuery(
	 * "select USER_NAME, PASSWORD, ENABLED from tbl_resource where USER_NAME=?"
	 * ) .authoritiesByUsernameQuery(
	 * "select USER_NAME, ACCESS_LEVEL from tbl_access_level where USER_NAME=?"
	 * ); }
	 */

	@Override
	protected void configure(AuthenticationManagerBuilder auth)
			throws Exception {
		auth.inMemoryAuthentication().withUser("admin").password("admin")
				.roles("USER");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
				.authorizeRequests()
				.antMatchers("/login*").anonymous()
				.anyRequest().authenticated()
				.and()
				.formLogin()
				.loginPage("/login.html")
				.defaultSuccessUrl("/homepage.html")
				.failureUrl("/login.html?error=true")
				.and()
				.logout()
				.logoutSuccessUrl("/login.html");
	}
}