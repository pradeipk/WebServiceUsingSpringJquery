package com.pradeip.curiosity.controller;

public interface BaseController {

}
