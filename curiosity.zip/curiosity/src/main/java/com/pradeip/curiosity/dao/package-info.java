/**
 * 
 */
/**
 * @author pradeep_patel
 *
 */
package com.pradeip.curiosity.dao;