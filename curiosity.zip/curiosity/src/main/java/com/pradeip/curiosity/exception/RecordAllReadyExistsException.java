package com.pradeip.curiosity.exception;

public class RecordAllReadyExistsException extends Exception {

	public RecordAllReadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RecordAllReadyExistsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RecordAllReadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RecordAllReadyExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
